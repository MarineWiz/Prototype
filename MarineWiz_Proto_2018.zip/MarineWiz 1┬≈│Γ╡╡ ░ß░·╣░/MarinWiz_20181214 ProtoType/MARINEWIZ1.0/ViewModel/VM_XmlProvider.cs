﻿using MARINEWIZ1._0.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MARINEWIZ1._0.ViewModel
{
    public class VM_XmlProvider
    {
        public System.Windows.Data.XmlDataProvider XmlData { get; set; }

        public VM_XmlProvider(string path)
        {
            if (path.Equals("init"))
                return;
            
            XmlData = new System.Windows.Data.XmlDataProvider();
            XmlData.Source = new Uri(@path);
            // XmlData.Source = new Uri(@"C:\Users\Toz\Documents\SDK Sample.xml");
            XmlData.XPath = "Node";
        }
    }
}
