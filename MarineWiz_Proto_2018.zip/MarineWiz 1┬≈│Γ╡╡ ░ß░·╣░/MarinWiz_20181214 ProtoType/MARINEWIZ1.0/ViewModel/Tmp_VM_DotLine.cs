﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Xml;

namespace MARINEWIZ1._0.ViewModel
{
    /// <summary>
    /// 
    /// </summary>
    public class Tmp_VM_DotLine : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        List<KeyValuePair<string, int>> ParsingDataList = new List<KeyValuePair<string, int>>();
        
        /// <summary>
        /// 
        /// </summary>
        public Tmp_VM_DotLine()
        {
            
        }

        /// <summary>
        /// 
        /// </summary>
        public List<KeyValuePair<string, int>> DataProperty
        {
            get { return ParsingDataList; }
            set
            {
                ParsingDataList = value;
                OnPropertyChanged("DataProperty");
            }
        }

        private void OnPropertyChanged(string info)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if(handler != null)
            {
                handler(this, new PropertyChangedEventArgs(info));
            }
        }

        public List<KeyValuePair<string, int>> DoReaderXmlDataAsync(Stream stream)
        {
            GetXmlDatabyAbsolutePath(stream);

            return ParsingDataList;
        }
        async Task GetXmlDatabyAbsolutePath(Stream stream)
        {
            XmlReaderSettings settings = new XmlReaderSettings();
            settings.Async = true;

            using (XmlReader reader = XmlReader.Create(stream, settings))
            {
                while(await reader.ReadAsync())
                {
                    switch (reader.NodeType)
                    {
                        case XmlNodeType.Element:

                            if (reader.GetAttribute("value") == string.Empty)
                                continue;
                            else
                                //MessageBox.Show(reader.GetAttribute("value"));
                                ParsingDataList.Add(new KeyValuePair<string, int>(reader.GetAttribute("name"), int.Parse(reader.GetAttribute("value"))));

                            break;
                        case XmlNodeType.Text:
                            //
                            break;

                        case XmlNodeType.EndElement:
                            //
                            break;

                        default:
                            
                            break;
                    }
                }
            }
        }
        
    }
}
