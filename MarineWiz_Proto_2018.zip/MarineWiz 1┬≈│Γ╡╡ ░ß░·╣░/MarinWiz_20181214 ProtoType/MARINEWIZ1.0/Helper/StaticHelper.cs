﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MARINEWIZ1._0.Helper
{
    static public class StaticHelper
    {
        /// <summary>
        /// Static으로 사용되는 변수들을 모아놓은 Class
        /// 뒤늦게 추가되거나 갑작스레 추가된것이 많아 변수명 정리를 실시해야함
        /// </summary>
        /// 

        static public string builderPath = string.Empty;
        static public string ProjectPath = string.Empty;
        static public string CodePath = string.Empty;
        static public string XamlPath = string.Empty;
        static public string Projectname = string.Empty;
        static public string CurrentFileDataPath = string.Empty;
        static public bool StartSwt = false;

        // Temp Variable
        static public string TempString = string.Empty;
    }
}
