﻿using MahApps.Metro.Controls;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace MARINEWIZ1._0.Helper
{

    /// <summary>
    /// IO 관련 총괄 Class
    /// </summary>
    public class IOHelper
    // 프로젝트 및 작업창 Load, Save => .xaml
    // .cs file 생성
    {
        public IOHelper()
        {

        }

        public bool Func_SaveMainWindow()
        {
            try
            {
                MetroWindow mainWindow = Application.Current.Windows.OfType<MetroWindow>().SingleOrDefault(w => w.IsActive);
                Canvas cavnas = UIHelper.FindChild<Canvas>(mainWindow, "maincanvas");

                //Canvas canvas = UIHelper.FindChild<Canvas>(Application.Current.MainWindow, "maincanvas");

                SaveFileDialog sfd = new SaveFileDialog();
                sfd.FileName = "New Xaml";
                sfd.DefaultExt = ".xaml";
                sfd.Filter = "Xaml Document (.xaml)|*.xaml";

                Nullable<bool> result = sfd.ShowDialog();
                if (result == true)
                {
                    string fileName = sfd.FileName;
                    ExportToXaml(cavnas, fileName);
                }
                return true;
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
                return false;
            }
        }

        public bool MakeProjectDir()
        {

            string ProjectPath = Path.Combine(StaticHelper.ProjectPath, StaticHelper.Projectname);
            Directory.CreateDirectory(ProjectPath);

            string binDir = Path.Combine(ProjectPath, "bin");
            string sourceDir = Path.Combine(ProjectPath, "codes");
            string xamlDir = Path.Combine(ProjectPath, "xamls");
            string resourceDir = Path.Combine(ProjectPath, "resources");

            Directory.CreateDirectory(binDir);
            Directory.CreateDirectory(sourceDir);
            StaticHelper.ProjectPath = sourceDir;
            Directory.CreateDirectory(xamlDir);
            Directory.CreateDirectory(resourceDir);

            MakeDefaultClassFile(sourceDir, "Button");
            MakeDefaultClassFile(sourceDir, "RadioButton");
            MakeDefaultClassFile(sourceDir, "DockPanel");
            MakeDefaultClassFile(sourceDir, "StackPanel");
            MakeDefaultClassFile(sourceDir, "WrapPanel");
            MakeDefaultClassFile(sourceDir, "TabControl");
            // TODO : 나머지 Component 추가


            return true;
        }

        public void MakeDefaultClassFile(string filePath, string UIType)
        {
            try
            {
                

                switch (UIType)
                {
                    case "Button":
                        FileStream fs = null;
                        StreamWriter sw = null;

                        fs = new FileStream(filePath + @"\Button.cs", FileMode.OpenOrCreate, FileAccess.Write);
                        sw = new StreamWriter(fs, Encoding.UTF8);

                        sw.WriteLine(@"#region 어셈블리 PresentationFramework, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35");
                        sw.WriteLine(@"// C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.6.1\PresentationFramework.dll");
                        sw.WriteLine(@"#endregion");
                        sw.WriteLine(@"");
                        sw.WriteLine(@"using System.Windows.Automation.Peers;");
                        sw.WriteLine(@"using System.Windows.Controls.Primitives;");
                        sw.WriteLine(@"");
                        sw.WriteLine(@"namespace System.Windows.Controls");
                        sw.WriteLine(@"{");
                        sw.WriteLine(@"public class Button : ButtonBase");
                        sw.WriteLine(@"{");
                        sw.WriteLine(@"public static readonly DependencyProperty IsDefaultProperty;");
                        sw.WriteLine(@"public static readonly DependencyProperty IsCancelProperty;");
                        sw.WriteLine(@"public static readonly DependencyProperty IsDefaultedProperty;");
                        sw.WriteLine(@"public Button();");
                        sw.WriteLine(@"public bool IsDefault { get; set; }");
                        sw.WriteLine(@"public bool IsCancel { get; set; }");
                        sw.WriteLine(@"public bool IsDefaulted { get; }");
                        sw.WriteLine(@"protected overried void OnClick();");
                        sw.WriteLine(@"protected overried AutomationPeer OnCreateAutomationPeer();");
                        sw.WriteLine(@"}");
                        sw.WriteLine(@"}");

                        sw.Close();
                        fs.Close();

                        break;

                    case "RadioButton":

                        FileStream fs1 = null;
                        StreamWriter sw1 = null;

                        fs1 = new FileStream(filePath + @"\RadioButton.cs", FileMode.OpenOrCreate, FileAccess.Write);
                        sw1 = new StreamWriter(fs1, Encoding.UTF8);

                        sw1.WriteLine(@"#region 어셈블리 PresentationFramework, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35");
                        sw1.WriteLine(@"// C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.6.1\PresentationFramework.dll");
                        sw1.WriteLine(@"#endregion");
                        sw1.WriteLine(@"");
                        sw1.WriteLine(@"using System.ComponentModel;");
                        sw1.WriteLine(@"using System.Windows.Automation.Peers;");
                        sw1.WriteLine(@"using System.Windows.Controls.Primitives;");
                        sw1.WriteLine(@"using System.Windows.Input;");
                        sw1.WriteLine(@"");
                        sw1.WriteLine(@"namespace System.Windows.Controls");
                        sw1.WriteLine(@"{");
                        sw1.WriteLine(@"public class RadioButton : ButtonBase");
                        sw1.WriteLine(@"{");
                        sw1.WriteLine(@"public static readonly DependencyProperty GroupNameProperty;");
                        sw1.WriteLine(@"public RadioButton();");
                        sw1.WriteLine(@"public string GroupName { get; set; }");
                        sw1.WriteLine(@"protected override void OnAccessKey(AccessKeyEventArgs e);");
                        sw1.WriteLine(@"protected override void OnChecked(RoutedEventArgs e);");
                        sw1.WriteLine(@"protected override AutomationPeer OnCreateAutomationPeer();");
                        sw1.WriteLine(@"protected internal override void OnToggle();");
                        sw1.WriteLine(@"}");
                        sw1.WriteLine(@"}");

                        sw1.Close();
                        fs1.Close();

                        break;

                    case "DockPanel":

                        FileStream fs2 = null;
                        StreamWriter sw2 = null;

                        fs2 = new FileStream(filePath + @"\DockPanel.cs", FileMode.OpenOrCreate, FileAccess.Write);
                        sw2 = new StreamWriter(fs2, Encoding.UTF8);

                        sw2.WriteLine(@"#region 어셈블리 PresentationFramework, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35");
                        sw2.WriteLine(@"// C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.6.1\PresentationFramework.dll");
                        sw2.WriteLine(@"#endregion");
                        sw2.WriteLine(@"");

                        sw2.WriteLine(@"using MS.Internal.PresentationFramework;");
                        sw2.WriteLine(@"");

                        sw2.WriteLine(@"namespace System.Windows.Controls");
                        sw2.WriteLine(@"{");
                        sw2.WriteLine(@"public class DockPanel : Panel");
                        sw2.WriteLine(@"{");
                        sw2.WriteLine(@"public static readonly DependencyProperty LastChildFillProperty;");
                        sw2.WriteLine(@"public static readonly DependencyProperty DockProperty;");
                        sw2.WriteLine(@"public DockPanel();");
                        sw2.WriteLine(@"public bool LastChildFill { get; set; }");
                        sw2.WriteLine(@"public static Dock GetDock(UIElement element);");
                        sw2.WriteLine(@"public static void SetDock(UIElement element, Dock dock);");
                        sw2.WriteLine(@"protected override Size ArrangeOverride(Size arrangeSize);");
                        sw2.WriteLine(@"protected override Size MeasureOverride(Size constraint);");
                        sw2.WriteLine(@"}");
                        sw2.WriteLine(@"}");
                        break;


                    case "StackPanel":

                        FileStream fs3 = null;
                        StreamWriter sw3 = null;

                        fs3 = new FileStream(filePath + @"\StackPaenl.cs", FileMode.OpenOrCreate, FileAccess.Write);
                        sw3 = new StreamWriter(fs3, Encoding.UTF8);

                        sw3.WriteLine(@"#region 어셈블리 PresentationFramework, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35");
                        sw3.WriteLine(@"// C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.6.1\PresentationFramework.dll");
                        sw3.WriteLine(@"#endregion");
                        sw3.WriteLine(@"");

                        sw3.WriteLine(@"using System.ComponentModel;");
                        sw3.WriteLine(@"using System.Windows.Controls.Primitives;");
                        sw3.WriteLine(@"using System.Windows.Media;");
                        sw3.WriteLine(@"");

                        sw3.WriteLine(@"namespace System.Windows.Controls");
                        sw3.WriteLine(@"{");
                        sw3.WriteLine(@"public class StackPanel : Panel, IScrollInfo, IStackMeasure");
                        sw3.WriteLine(@"{");
                        sw3.WriteLine(@"public static readonly DependencyProperty OrientationProperty;");

                        sw3.WriteLine(@"public StackPanel();");

                        sw3.WriteLine(@"public double HorizontalOffset { get; }");
                        sw3.WriteLine(@"public double ViewportHeight { get; }");
                        sw3.WriteLine(@"public double ViewportWidth { get; }");
                        sw3.WriteLine(@"public double ExtentHeight { get; }");
                        sw3.WriteLine(@"public double ExtentWidth { get; }");
                        sw3.WriteLine(@"public bool CanVerticallyScroll { get; set; }");
                        sw3.WriteLine(@"public bool CanHorizontallyScroll { get; set; }");
                        sw3.WriteLine(@"public Orientation Orientation { get; set; }");
                        sw3.WriteLine(@"public double VerticalOffset { get; }");
                        sw3.WriteLine(@"public ScrollViewer ScrollOwner { get; set; }");
                        sw3.WriteLine(@"protected internal override Orientation LogicalOrientation { get; }");
                        sw3.WriteLine(@"protected internal override bool HasLogicalOrientation { get; }");



                        sw3.WriteLine(@"public void LineDown();");
                        sw3.WriteLine(@"public void LineLeft();");
                        sw3.WriteLine(@"public void LineRight();");
                        sw3.WriteLine(@"public void LineUp();");
                        sw3.WriteLine(@"public Rect MakeVisible(Visual visual, Rect rectangle);");
                        sw3.WriteLine(@"public void MouseWheelDown();");
                        sw3.WriteLine(@"public void MouseWheelLeft();");
                        sw3.WriteLine(@"public void MouseWheelRight();");
                        sw3.WriteLine(@"public void MouseWheelUp();");
                        sw3.WriteLine(@"public void PageDown();");
                        sw3.WriteLine(@"public void PageLeft();");
                        sw3.WriteLine(@"public void PageRight();");
                        sw3.WriteLine(@"public void PageUp();");
                        sw3.WriteLine(@"public void SetHorizontalOffset(double offset);");
                        sw3.WriteLine(@"public void SetVerticalOffset(double offset);");
                        sw3.WriteLine(@"protected override Size ArrangeOverride(Size arrangeSize);");
                        sw3.WriteLine(@"protected override Size MeasureOverride(Size constraint);");
                        sw3.WriteLine(@"}");
                        sw3.WriteLine(@"}");

                        sw3.Close();
                        fs3.Close();

                        break;


                    case "WrapPanel":
                        FileStream fs4 = null;
                        StreamWriter sw4 = null;

                        fs4 = new FileStream(filePath + @"\WrapPanel.cs", FileMode.OpenOrCreate, FileAccess.Write);
                        sw4 = new StreamWriter(fs4, Encoding.UTF8);

                        sw4.WriteLine(@"#region 어셈블리 PresentationFramework, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35");
                        sw4.WriteLine(@"// C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.6.1\PresentationFramework.dll");
                        sw4.WriteLine(@"#endregion");
                        sw4.WriteLine(@"");

                        sw4.WriteLine(@"using System.ComponentModel;");
                        sw4.WriteLine(@"");

                        sw4.WriteLine(@"namespace System.Windows.Controls");
                        sw4.WriteLine(@"{");
                        sw4.WriteLine(@"public class WrapPanel : Panel");
                        sw4.WriteLine(@"{");
                        sw4.WriteLine(@"public static readonly DependencyProperty ItemWidthProperty;");
                        sw4.WriteLine(@"public static readonly DependencyProperty ItemHeightProperty;");
                        sw4.WriteLine(@"public static readonly DependencyProperty OrientationProperty;");

                        sw4.WriteLine(@"public WrapPanel();");

                        sw4.WriteLine(@"public double ItemWidth { get; set; }");
                        sw4.WriteLine(@"public double ItemHeight { get; set; }");
                        sw4.WriteLine(@"public Orientation Orientation { get; set; }");

                        sw4.WriteLine(@"protected override Size ArrangeOverride(Size finalSize);");
                        sw4.WriteLine(@"protected override Size MeasureOverride(Size constraint);");
                        sw4.WriteLine(@"}");
                        sw4.WriteLine(@"}");

                        sw4.Close();
                        fs4.Close();

                        break;

                    case "TabControl":

                        FileStream fs5 = null;
                        StreamWriter sw5 = null;

                        fs5 = new FileStream(filePath + @"\TabControl.cs", FileMode.OpenOrCreate, FileAccess.Write);
                        sw5 = new StreamWriter(fs5, Encoding.UTF8);

                        sw5.WriteLine(@"#region 어셈블리 PresentationFramework, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35");
                        sw5.WriteLine(@"// C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.6.1\PresentationFramework.dll");
                        sw5.WriteLine(@"#endregion");
                        sw5.WriteLine(@"");

                        sw5.WriteLine(@"using System.Collections.Specialized;");
                        sw5.WriteLine(@"using System.ComponentModel;");
                        sw5.WriteLine(@"using System.Windows.Automation.Peers;");
                        sw5.WriteLine(@"using System.Windows.Controls.Primitives;");
                        sw5.WriteLine(@"using System.Windows.Input;");
                        sw5.WriteLine(@"");

                        sw5.WriteLine(@"namespace System.Windows.Controls");
                        sw5.WriteLine(@"{");
                        sw5.WriteLine(@"public class WrapPanel : Selector");
                        sw5.WriteLine(@"{");
                        sw5.WriteLine(@"public static readonly DependencyProperty TabStripPlacementProperty;");
                        sw5.WriteLine(@"public static readonly DependencyProperty SelectedContentProperty;");
                        sw5.WriteLine(@"public static readonly DependencyProperty SelectedContentTemplateProperty;");
                        sw5.WriteLine(@"public static readonly DependencyProperty SelectedContentTemplateSelectorProperty;");
                        sw5.WriteLine(@"public static readonly DependencyProperty SelectedContentStringFormatProperty;");
                        sw5.WriteLine(@"public static readonly DependencyProperty ContentTemplateProperty;");
                        sw5.WriteLine(@"public static readonly DependencyProperty ContentTemplateSelectorProperty;");
                        sw5.WriteLine(@"public static readonly DependencyProperty ContentStringFormatProperty;");

                        sw5.WriteLine(@"public WrapPanel();");

                        sw5.WriteLine(@"public DataTemplate ContentTemplate { get; set; }");
                        sw5.WriteLine(@"public string SelectedContentStringFormat { get; }");
                        sw5.WriteLine(@"public DataTemplateSelector SelectedContentTemplateSelector { get; }");
                        sw5.WriteLine(@"public DataTemplate SelectedContentTemplate { get; }");
                        sw5.WriteLine(@"public object SelectedContent { get; }");
                        sw5.WriteLine(@"public Dock TabStripPlacement { get; set; }");
                        sw5.WriteLine(@"public string ContentStringFormat { get; set; }");
                        sw5.WriteLine(@"public DataTemplateSelector ContentTemplateSelector { get; set; }");

                        sw5.WriteLine(@"public override void OnApplyTemplate();");
                        sw5.WriteLine(@"protected override DependencyObject GetContainerForItemOverride();");
                        sw5.WriteLine(@"protected override bool IsItemItsOwnContainerOverride(object item);");
                        sw5.WriteLine(@"protected override AutomationPeer OnCreateAutomationPeer();");
                        sw5.WriteLine(@"protected override void OnInitialized(EventArgs e);");
                        sw5.WriteLine(@"protected override void OnItemsChanged(NotifyCollectionChangedEventArgs e);");
                        sw5.WriteLine(@"protected override void OnKeyDown(KeyEventArgs e);");
                        sw5.WriteLine(@"protected override void OnSelectionChanged(SelectionChangedEventArgs e);");
                        sw5.WriteLine(@"}");
                        sw5.WriteLine(@"}");

                        sw5.Close();
                        fs5.Close();

                        break;


                    case "Label":
                        FileStream fs6 = null;
                        StreamWriter sw6 = null;
                        fs6 = new FileStream(filePath + @"\Label.cs", FileMode.OpenOrCreate, FileAccess.Write);
                        sw6 = new StreamWriter(fs6, Encoding.UTF8);

                        sw6.WriteLine(@"#region 어셈블리 PresentationFramework, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35
// C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.5\PresentationFramework.dll
#endregion

using System.ComponentModel;
using System.Windows.Automation.Peers;
using System.Windows.Markup;

namespace System.Windows.Controls
{
    //
    // 요약:
    //     Represents the text label for a control and provides support for access keys.
    [Localizability(LocalizationCategory.Label)]
    public class Label : ContentControl
    {
        //
        // 요약:
        //     Identifies the System.Windows.Controls.Label.Target dependency property.
        //
        // 반환 값:
        //     The identifier for the System.Windows.Controls.Label.Target dependency property.
        public static readonly DependencyProperty TargetProperty;

        //
        // 요약:
        //     Initializes a new instance of the System.Windows.Controls.Label class.
        public Label();

        //
        // 요약:
        //     Gets or sets the element that receives focus when the user presses the label's
        //     access key.
        //
        // 반환 값:
        //     The System.Windows.UIElement that receives focus when the user presses the access
        //     key. The default is null.
        [TypeConverter(typeof(NameReferenceConverter))]
        public UIElement Target { get; set; }

        //
        // 요약:
        //     Provides an appropriate System.Windows.Automation.Peers.LabelAutomationPeer implementation
        //     for this control, as part of the WPF infrastructure.
        //
        // 반환 값:
        //     The type-specific System.Windows.Automation.Peers.AutomationPeer implementation.
        protected override AutomationPeer OnCreateAutomationPeer();
    }
}");
                        sw6.Close();
                        fs6.Close();                       

                        break;


                    case "TextBlock":
                        FileStream fs7 = new FileStream(filePath + @"\TextBlock.cs", FileMode.OpenOrCreate, FileAccess.Write);
                        StreamWriter sw7 = new StreamWriter(fs7, Encoding.UTF8);

                        sw7.WriteLine(@"#region 어셈블리 PresentationFramework, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35
// C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.5\PresentationFramework.dll
#endregion

using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows.Automation.Peers;
using System.Windows.Documents;
using System.Windows.Markup;
using System.Windows.Media;
using MS.Internal.PresentationFramework;

namespace System.Windows.Controls
{
    //
    // 요약:
    //     Provides a lightweight control for displaying small amounts of flow content.
    [ContentProperty(""Inlines"")]
    [Localizability(LocalizationCategory.Text)]
    public class TextBlock : FrameworkElement, IContentHost, IAddChildInternal, IAddChild, IServiceProvider
    {
        //
        // 요약:
        //     Identifies the System.Windows.Controls.TextBlock.BaselineOffset dependency property.
        //
        // 반환 값:
        //     The identifier for the System.Windows.Controls.TextBlock.BaselineOffset dependency
        //     property.
        public static readonly DependencyProperty BaselineOffsetProperty;
        //
        // 요약:
        //     Identifies the System.Windows.Controls.TextBlock.IsHyphenationEnabled dependency
        //     property.
        //
        // 반환 값:
        //     The identifier for the System.Windows.Controls.TextBlock.IsHyphenationEnabled
        //     dependency property.
        public static readonly DependencyProperty IsHyphenationEnabledProperty;
        //
        // 요약:
        //     Identifies the System.Windows.Controls.TextBlock.TextWrapping dependency property.
        //
        // 반환 값:
        //     The identifier of the System.Windows.Controls.TextBlock.TextWrapping dependency
        //     property.
        [CommonDependencyPropertyAttribute]
        public static readonly DependencyProperty TextWrappingProperty;
        //
        // 요약:
        //     Identifies the System.Windows.Controls.TextBlock.TextAlignment dependency property.
        //
        // 반환 값:
        //     The identifier for the System.Windows.Controls.TextBlock.TextAlignment dependency
        //     property.
        public static readonly DependencyProperty TextAlignmentProperty;
        //
        // 요약:
        //     Identifies the System.Windows.Controls.TextBlock.Padding dependency property.
        //
        // 반환 값:
        //     The identifier for the System.Windows.Controls.TextBlock.Padding dependency property.
        public static readonly DependencyProperty PaddingProperty;
        //
        // 요약:
        //     Identifies the System.Windows.Controls.TextBlock.LineStackingStrategy dependency
        //     property.
        //
        // 반환 값:
        //     The identifier for the System.Windows.Controls.TextBlock.LineStackingStrategy
        //     dependency property.
        public static readonly DependencyProperty LineStackingStrategyProperty;
        //
        // 요약:
        //     Identifies the System.Windows.Controls.TextBlock.LineHeight dependency property.
        //
        // 반환 값:
        //     The identifier for the System.Windows.Controls.TextBlock.LineHeight dependency
        //     property.
        public static readonly DependencyProperty LineHeightProperty;
        //
        // 요약:
        //     Identifies the System.Windows.Controls.TextBlock.TextEffects dependency property.
        //
        // 반환 값:
        //     The identifier of the System.Windows.Controls.TextBlock.TextEffects dependency
        //     property.
        public static readonly DependencyProperty TextEffectsProperty;
        //
        // 요약:
        //     Identifies the System.Windows.Controls.TextBlock.TextDecorations dependency property.
        //
        // 반환 값:
        //     The identifier for the System.Windows.Controls.TextBlock.TextDecorations dependency
        //     property.
        [CommonDependencyPropertyAttribute]
        public static readonly DependencyProperty TextDecorationsProperty;
        //
        // 요약:
        //     Identifies the System.Windows.Controls.TextBlock.TextTrimming dependency property.
        //
        // 반환 값:
        //     The identifier of the System.Windows.Controls.TextBlock.TextTrimming dependency
        //     property.
        [CommonDependencyPropertyAttribute]
        public static readonly DependencyProperty TextTrimmingProperty;
        //
        // 요약:
        //     Identifies the System.Windows.Controls.TextBlock.Foreground dependency property.
        //
        // 반환 값:
        //     The identifier for the System.Windows.Controls.TextBlock.Foreground dependency
        //     property.
        [CommonDependencyPropertyAttribute]
        public static readonly DependencyProperty ForegroundProperty;
        //
        // 요약:
        //     Identifies the System.Windows.Controls.TextBlock.FontSize dependency property.
        //
        // 반환 값:
        //     The identifier for the System.Windows.Controls.TextBlock.FontSize dependency
        //     property.
        [CommonDependencyPropertyAttribute]
        public static readonly DependencyProperty FontSizeProperty;
        //
        // 요약:
        //     Identifies the System.Windows.Controls.TextBlock.FontStretch dependency property.
        //
        // 반환 값:
        //     The identifier for the System.Windows.Controls.TextBlock.FontStretch dependency
        //     property.
        [CommonDependencyPropertyAttribute]
        public static readonly DependencyProperty FontStretchProperty;
        //
        // 요약:
        //     Identifies the System.Windows.Controls.TextBlock.FontWeight dependency property.
        //
        // 반환 값:
        //     The identifier for the System.Windows.Controls.TextBlock.FontWeight dependency
        //     property.
        [CommonDependencyPropertyAttribute]
        public static readonly DependencyProperty FontWeightProperty;
        //
        // 요약:
        //     Identifies the System.Windows.Controls.TextBlock.FontStyle dependency property.
        //
        // 반환 값:
        //     The identifier for the System.Windows.Controls.TextBlock.FontStyle dependency
        //     property.
        [CommonDependencyPropertyAttribute]
        public static readonly DependencyProperty FontStyleProperty;
        //
        // 요약:
        //     Identifies the System.Windows.Controls.TextBlock.FontFamily dependency property.
        //
        // 반환 값:
        //     The identifier for the System.Windows.Controls.TextBlock.FontFamily dependency
        //     property.
        [CommonDependencyPropertyAttribute]
        public static readonly DependencyProperty FontFamilyProperty;
        //
        // 요약:
        //     Identifies the System.Windows.Controls.TextBlock.Text dependency property.
        //
        // 반환 값:
        //     The identifier of the System.Windows.Controls.TextBlock.Text dependency property.
        [CommonDependencyPropertyAttribute]
        public static readonly DependencyProperty TextProperty;
        //
        // 요약:
        //     Identifies the System.Windows.Controls.TextBlock.Background dependency property.
        //
        // 반환 값:
        //     The identifier for the System.Windows.Controls.TextBlock.Background dependency
        //     property.
        [CommonDependencyPropertyAttribute]
        public static readonly DependencyProperty BackgroundProperty;

        //
        // 요약:
        //     Initializes a new instance of the System.Windows.Controls.TextBlock class.
        public TextBlock();
        //
        // 요약:
        //     Initializes a new instance of the System.Windows.Controls.TextBlock class, adding
        //     a specified System.Windows.Documents.Inline element as the initial display content.
        //
        // 매개 변수:
        //   inline:
        //     An object deriving from the abstract System.Windows.Documents.Inline class, to
        //     be added as the initial content.
        //
        // 예외:
        //   T:System.ArgumentNullException:
        //     inline is null.
        public TextBlock(Inline inline);

        //
        // 요약:
        //     Gets or sets the top-level font weight for the System.Windows.Controls.TextBlock.
        //
        // 반환 값:
        //     A member of the System.Windows.FontWeights class specifying the desired font
        //     weight. The default is determined by the System.Windows.SystemFonts.MessageFontWeight
        //     value.
        public FontWeight FontWeight { get; set; }
        //
        // 요약:
        //     Gets or sets the top-level font style for the System.Windows.Controls.TextBlock.
        //
        // 반환 값:
        //     A member of the System.Windows.FontStyles class specifying the desired font style.
        //     The default is determined by the System.Windows.SystemFonts.MessageFontStyle
        //     value.
        public FontStyle FontStyle { get; set; }
        //
        // 요약:
        //     Gets or sets the preferred top-level font family for the System.Windows.Controls.TextBlock.
        //
        // 반환 값:
        //     A System.Windows.Media.FontFamily object specifying the preferred font family,
        //     or a primary preferred font family with one or more fallback font families. The
        //     default is the font determined by the System.Windows.SystemFonts.MessageFontFamily
        //     value.
        [Localizability(LocalizationCategory.Font)]
        public FontFamily FontFamily { get; set; }
        //
        // 요약:
        //     Gets or sets the text contents of a System.Windows.Controls.TextBlock.
        //
        // 반환 값:
        //     The text contents of this System.Windows.Controls.TextBlock. Note that all non-text
        //     content is stripped out, resulting in a plain text representation of the System.Windows.Controls.TextBlock
        //     contents. The default is System.String.Empty.
        [Localizability(LocalizationCategory.Text)]
        public string Text { get; set; }
        //
        // 요약:
        //     Gets a System.Windows.Documents.TextPointer to the end of content in the System.Windows.Controls.TextBlock.
        //
        // 반환 값:
        //     A System.Windows.Documents.TextPointer to the end of content in the System.Windows.Controls.TextBlock.
        public TextPointer ContentEnd { get; }
        //
        // 요약:
        //     Gets the currently effective typography variations for the contents of this element.
        //
        // 반환 값:
        //     A System.Windows.Documents.Typography object that specifies the currently effective
        //     typography variations. For a list of default typography values, see System.Windows.Documents.Typography.
        public Typography Typography { get; }
        //
        // 요약:
        //     Gets a System.Windows.LineBreakCondition that indicates how content should break
        //     after the current element.
        //
        // 반환 값:
        //     The conditions for breaking content after the current element.
        public LineBreakCondition BreakAfter { get; }
        //
        // 요약:
        //     Gets a System.Windows.LineBreakCondition that indicates how content should break
        //     before the current element.
        //
        // 반환 값:
        //     The conditions for breaking content after the current element.
        public LineBreakCondition BreakBefore { get; }
        //
        // 요약:
        //     Gets or sets the top-level font-stretching characteristics for the System.Windows.Controls.TextBlock.
        //
        // 반환 값:
        //     A member of the System.Windows.FontStretch class specifying the desired font-stretching
        //     characteristics to use. The default is System.Windows.FontStretches.Normal.
        public FontStretch FontStretch { get; set; }
        //
        // 요약:
        //     Gets or sets the amount by which each line of text is offset from the baseline.
        //
        // 반환 값:
        //     The amount by which each line of text is offset from the baseline, in device
        //     independent pixels. System.Double.NaN indicates that an optimal baseline offset
        //     is automatically calculated from the current font characteristics. The default
        //     is System.Double.NaN.
        public double BaselineOffset { get; set; }
        //
        // 요약:
        //     Gets or sets the top-level font size for the System.Windows.Controls.TextBlock.
        //
        // 반환 값:
        //     The desired font size to use in device independent pixels). The default is determined
        //     by the System.Windows.SystemFonts.MessageFontSize value.
        [Localizability(LocalizationCategory.None)]
        [TypeConverter(typeof(FontSizeConverter))]
        public double FontSize { get; set; }
        //
        // 요약:
        //     Gets or sets how the System.Windows.Controls.TextBlock should wrap text.
        //
        // 반환 값:
        //     One of the System.Windows.TextWrapping values. The default is System.Windows.TextWrapping.NoWrap.
        public TextWrapping TextWrapping { get; set; }
        //
        // 요약:
        //     Gets or sets the System.Windows.Media.Brush used to fill the background of content
        //     area.
        //
        // 반환 값:
        //     The brush used to fill the background of the content area, or null to not use
        //     a background brush. The default is null.
        public Brush Background { get; set; }
        //
        // 요약:
        //     Gets or sets a System.Windows.TextDecorationCollection that contains the effects
        //     to apply to the text of a System.Windows.Controls.TextBlock.
        //
        // 반환 값:
        //     A System.Windows.TextDecorationCollection collection that contains text decorations
        //     to apply to this element. The default is null (no text decorations applied).
        public TextDecorationCollection TextDecorations { get; set; }
        //
        // 요약:
        //     Gets or sets the effects to apply to the text content in this element.
        //
        // 반환 값:
        //     A System.Windows.Media.TextEffectCollection containing one or more System.Windows.Media.TextEffect
        //     objects that define effects to apply to the text of the System.Windows.Controls.TextBlock.
        //     The default is null (no effects applied).
        public TextEffectCollection TextEffects { get; set; }
        //
        // 요약:
        //     Gets or sets the height of each line of content.
        //
        // 반환 값:
        //     The height of line, in device independent pixels, in the range of 0.0034 to 160000.
        //     A value of System.Double.NaN (equivalent to an attribute value of \""Auto"") indicates
        //     that the line height is determined automatically from the current font characteristics.
        //     The default is System.Double.NaN.
        //
        // 예외:
        //   T:System.ArgumentException:
        //     System.Windows.Controls.TextBlock.LineHeight is set to a non-positive value.
        [TypeConverter(typeof(LengthConverter))]
        public double LineHeight { get; set; }
        //
        // 요약:
        //     Gets or sets the mechanism by which a line box is determined for each line of
        //     text within the System.Windows.Controls.TextBlock.
        //
        // 반환 값:
        //     The mechanism by which a line box is determined for each line of text within
        //     the System.Windows.Controls.TextBlock. The default is System.Windows.LineStackingStrategy.MaxHeight.
        public LineStackingStrategy LineStackingStrategy { get; set; }
        //
        // 요약:
        //     Gets or sets a value that indicates the thickness of padding space between the
        //     boundaries of the content area, and the content displayed by a System.Windows.Controls.TextBlock.
        //
        // 반환 값:
        //     A System.Windows.Thickness structure specifying the amount of padding to apply,
        //     in device independent pixels. The default is System.Double.NaN.
        public Thickness Padding { get; set; }
        //
        // 요약:
        //     Gets or sets a value that indicates the horizontal alignment of text content.
        //
        // 반환 값:
        //     One of the System.Windows.TextAlignment values that specifies the desired alignment.
        //     The default is System.Windows.TextAlignment.Left.
        public TextAlignment TextAlignment { get; set; }
        //
        // 요약:
        //     Gets or sets the text trimming behavior to employ when content overflows the
        //     content area.
        //
        // 반환 값:
        //     One of the System.Windows.TextTrimming values that specifies the text trimming
        //     behavior to employ. The default is System.Windows.TextTrimming.None.
        public TextTrimming TextTrimming { get; set; }
        //
        // 요약:
        //     Gets a System.Windows.Documents.TextPointer to the beginning of content in the
        //     System.Windows.Controls.TextBlock.
        //
        // 반환 값:
        //     A System.Windows.Documents.TextPointer to the beginning of content in the System.Windows.Controls.TextBlock.
        public TextPointer ContentStart { get; }
        //
        // 요약:
        //     Gets or sets a value that indicates whether automatic hyphenation of words is
        //     enabled or disabled.
        //
        // 반환 값:
        //     true to indicate that automatic breaking and hyphenation of words is enabled;
        //     otherwise, false. The default is false.
        public bool IsHyphenationEnabled { get; set; }
        //
        // 요약:
        //     Gets or sets the System.Windows.Media.Brush to apply to the text contents of
        //     the System.Windows.Controls.TextBlock.
        //
        // 반환 값:
        //     The brush used to apply to the text contents. The default is System.Windows.Media.Brushes.Black.
        public Brush Foreground { get; set; }
        //
        // 요약:
        //     Gets an System.Windows.Documents.InlineCollection containing the top-level System.Windows.Documents.Inline
        //     elements that comprise the contents of the System.Windows.Controls.TextBlock.
        //
        // 반환 값:
        //     An System.Windows.Documents.InlineCollection containing the System.Windows.Documents.Inline
        //     elements that comprise the contents of the System.Windows.Controls.TextBlock.
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public InlineCollection Inlines { get; }
        //
        // 요약:
        //     Gets an enumerator that can be used iterate the elements hosted by this System.Windows.Controls.TextBlock.
        //
        // 반환 값:
        //     An enumerator that can iterate elements hosted by this System.Windows.Controls.TextBlock.
        protected virtual IEnumerator<IInputElement> HostedElementsCore { get; }
        //
        // 요약:
        //     Gets the number of System.Windows.Media.Visual children hosted by the System.Windows.Controls.TextBlock.
        //
        // 반환 값:
        //     The number of visual children hosted by the System.Windows.Controls.TextBlock.
        protected override int VisualChildrenCount { get; }
        //
        // 요약:
        //     Gets an enumerator that can iterate the logical children of the System.Windows.Controls.TextBlock.
        //
        // 반환 값:
        //     An enumerator for the logical children.
        protected internal override IEnumerator LogicalChildren { get; }

        //
        // 요약:
        //     Returns the value of the System.Windows.Controls.TextBlock.BaselineOffset attached
        //     property for a specified dependency object.
        //
        // 매개 변수:
        //   element:
        //     The dependency object from which to retrieve the value of the System.Windows.Controls.TextBlock.BaselineOffset
        //     attached property.
        //
        // 반환 값:
        //     The current value of the System.Windows.Controls.TextBlock.BaselineOffset attached
        //     property on the specified dependency object.
        //
        // 예외:
        //   T:System.ArgumentNullException:
        //     element is null.
        public static double GetBaselineOffset(DependencyObject element);
        //
        // 요약:
        //     Returns the value of the System.Windows.Controls.TextBlock.FontFamilyProperty
        //     attached property for a specified dependency object.
        //
        // 매개 변수:
        //   element:
        //     The dependency object from which to retrieve the value of the System.Windows.Controls.TextBlock.FontFamily
        //     attached property.
        //
        // 반환 값:
        //     The current value of the System.Windows.Controls.TextBlock.FontFamily attached
        //     property on the specified dependency object.
        //
        // 예외:
        //   T:System.ArgumentNullException:
        //     element is null.
        public static FontFamily GetFontFamily(DependencyObject element);
        //
        // 요약:
        //     Returns the value of the System.Windows.Controls.TextBlock.FontSize attached
        //     property for a specified dependency object.
        //
        // 매개 변수:
        //   element:
        //     The dependency object from which to retrieve the value of the System.Windows.Controls.TextBlock.FontSize
        //     attached property.
        //
        // 반환 값:
        //     The current value of the System.Windows.Controls.TextBlock.FontSize attached
        //     property on the specified dependency object.
        //
        // 예외:
        //   T:System.ArgumentNullException:
        //     element is null.
        [TypeConverter(typeof(FontSizeConverter))]
        public static double GetFontSize(DependencyObject element);
        //
        // 요약:
        //     Returns the value of the System.Windows.Controls.TextBlock.FontStretch attached
        //     property for a specified dependency object.
        //
        // 매개 변수:
        //   element:
        //     The dependency object from which to retrieve the value of the System.Windows.Controls.TextBlock.FontStretch
        //     attached property.
        //
        // 반환 값:
        //     The current value of the System.Windows.Controls.TextBlock.FontStretch attached
        //     property on the specified dependency object.
        //
        // 예외:
        //   T:System.ArgumentNullException:
        //     element is null.
        public static FontStretch GetFontStretch(DependencyObject element);
        //
        // 요약:
        //     Returns the value of the System.Windows.Controls.TextBlock.FontStyle attached
        //     property for a specified dependency object.
        //
        // 매개 변수:
        //   element:
        //     The dependency object from which to retrieve the value of the System.Windows.Controls.TextBlock.FontStyle
        //     attached property.
        //
        // 반환 값:
        //     The current value of the System.Windows.Controls.TextBlock.FontStyle attached
        //     property on the specified dependency object.
        //
        // 예외:
        //   T:System.ArgumentNullException:
        //     element is null.
        public static FontStyle GetFontStyle(DependencyObject element);
        //
        // 요약:
        //     Returns the value of the System.Windows.Controls.TextBlock.FontWeight attached
        //     property for a specified dependency object.
        //
        // 매개 변수:
        //   element:
        //     The dependency object from which to retrieve the value of the System.Windows.Controls.TextBlock.FontWeight
        //     attached property.
        //
        // 반환 값:
        //     The current value of the System.Windows.Controls.TextBlock.FontWeight attached
        //     property on the specified dependency object.
        //
        // 예외:
        //   T:System.ArgumentNullException:
        //     element is null.
        public static FontWeight GetFontWeight(DependencyObject element);
        //
        // 요약:
        //     Returns the value of the System.Windows.Controls.TextBlock.Foreground attached
        //     property for a specified dependency object.
        //
        // 매개 변수:
        //   element:
        //     The dependency object from which to retrieve the value of the System.Windows.Controls.TextBlock.Foreground
        //     attached property.
        //
        // 반환 값:
        //     The current value of the System.Windows.Controls.TextBlock.Foreground attached
        //     property on the specified dependency object.
        //
        // 예외:
        //   T:System.ArgumentNullException:
        //     element is null.
        public static Brush GetForeground(DependencyObject element);
        //
        // 요약:
        //     Returns the value of the System.Windows.Controls.TextBlock.LineHeight attached
        //     property for a specified dependency object.
        //
        // 매개 변수:
        //   element:
        //     The dependency object from which to retrieve the value of the System.Windows.Controls.TextBlock.LineHeight
        //     attached property.
        //
        // 반환 값:
        //     The current value of the System.Windows.Controls.TextBlock.LineHeight attached
        //     property on the specified dependency object.
        //
        // 예외:
        //   T:System.ArgumentNullException:
        //     element is null.
        [TypeConverter(typeof(LengthConverter))]
        public static double GetLineHeight(DependencyObject element);
        //
        // 요약:
        //     Returns the value of the System.Windows.Controls.TextBlock.LineStackingStrategy
        //     attached property for a specified dependency object.
        //
        // 매개 변수:
        //   element:
        //     The dependency object from which to retrieve the value of the System.Windows.Controls.TextBlock.LineStackingStrategy
        //     attached property.
        //
        // 반환 값:
        //     The current value of the System.Windows.Controls.TextBlock.LineStackingStrategy
        //     attached property on the specified dependency object.
        //
        // 예외:
        //   T:System.ArgumentNullException:
        //     element is null.
        public static LineStackingStrategy GetLineStackingStrategy(DependencyObject element);
        //
        // 요약:
        //     Returns the value of the System.Windows.Controls.TextBlock.TextAlignment attached
        //     property for a specified dependency object.
        //
        // 매개 변수:
        //   element:
        //     The dependency object from which to retrieve the value of the System.Windows.Controls.TextBlock.TextAlignment
        //     attached property.
        //
        // 반환 값:
        //     The current value of the System.Windows.Controls.TextBlock.TextAlignment attached
        //     property on the specified dependency object.
        //
        // 예외:
        //   T:System.ArgumentNullException:
        //     element is null.
        public static TextAlignment GetTextAlignment(DependencyObject element);
        //
        // 요약:
        //     Sets the value of the System.Windows.Controls.TextBlock.BaselineOffset attached
        //     property on a specified dependency object.
        //
        // 매개 변수:
        //   element:
        //     The dependency object on which to set the value of the System.Windows.Controls.TextBlock.BaselineOffset
        //     property.
        //
        //   value:
        //     The new value to set the property to.
        //
        // 예외:
        //   T:System.ArgumentNullException:
        //     element is null.
        public static void SetBaselineOffset(DependencyObject element, double value);
        //
        // 요약:
        //     Sets the value of the System.Windows.Controls.TextBlock.FontFamily attached property
        //     on a specified dependency object.
        //
        // 매개 변수:
        //   element:
        //     The dependency object on which to set the value of the System.Windows.Controls.TextBlock.FontFamily
        //     property.
        //
        //   value:
        //     The new value to set the property to.
        //
        // 예외:
        //   T:System.ArgumentNullException:
        //     element is null.
        public static void SetFontFamily(DependencyObject element, FontFamily value);
        //
        // 요약:
        //     Sets the value of the System.Windows.Controls.TextBlock.FontSize attached property
        //     on a specified dependency object.
        //
        // 매개 변수:
        //   element:
        //     The dependency object on which to set the value of the System.Windows.Controls.TextBlock.FontSize
        //     property.
        //
        //   value:
        //     The new value to set the property to.
        //
        // 예외:
        //   T:System.ArgumentNullException:
        //     element is null.
        public static void SetFontSize(DependencyObject element, double value);
        //
        // 요약:
        //     Sets the value of the System.Windows.Controls.TextBlock.FontStretch attached
        //     property on a specified dependency object.
        //
        // 매개 변수:
        //   element:
        //     The dependency object on which to set the value of the System.Windows.Controls.TextBlock.FontStretch
        //     property.
        //
        //   value:
        //     The new value to set the property to.
        //
        // 예외:
        //   T:System.ArgumentNullException:
        //     element is null.
        public static void SetFontStretch(DependencyObject element, FontStretch value);
        //
        // 요약:
        //     Sets the value of the System.Windows.Controls.TextBlock.FontStyle attached property
        //     on a specified dependency object.
        //
        // 매개 변수:
        //   element:
        //     The dependency object on which to set the value of the System.Windows.Controls.TextBlock.FontStyle
        //     property.
        //
        //   value:
        //     The new value to set the property to.
        //
        // 예외:
        //   T:System.ArgumentNullException:
        //     element is null.
        public static void SetFontStyle(DependencyObject element, FontStyle value);
        //
        // 요약:
        //     Sets the value of the System.Windows.Controls.TextBlock.FontWeight attached property
        //     on a specified dependency object.
        //
        // 매개 변수:
        //   element:
        //     The dependency object on which to set the value of the System.Windows.Controls.TextBlock.FontWeight
        //     property.
        //
        //   value:
        //     The new value to set the property to.
        //
        // 예외:
        //   T:System.ArgumentNullException:
        //     element is null.
        public static void SetFontWeight(DependencyObject element, FontWeight value);
        //
        // 요약:
        //     Sets the value of the System.Windows.Controls.TextBlock.Foreground attached property
        //     on a specified dependency object.
        //
        // 매개 변수:
        //   element:
        //     The dependency object on which to set the value of the System.Windows.Controls.TextBlock.Foreground
        //     property.
        //
        //   value:
        //     The new value to set the property to.
        //
        // 예외:
        //   T:System.ArgumentNullException:
        //     element is null.
        public static void SetForeground(DependencyObject element, Brush value);
        //
        // 요약:
        //     Sets the value of the System.Windows.Controls.TextBlock.LineHeight attached property
        //     on a specified dependency object.
        //
        // 매개 변수:
        //   element:
        //     The dependency object on which to set the value of the System.Windows.Controls.TextBlock.LineHeight
        //     property.
        //
        //   value:
        //     The new value to set the property to.
        //
        // 예외:
        //   T:System.ArgumentNullException:
        //     element is null.
        //
        //   T:System.ArgumentException:
        //     System.Windows.Controls.TextBlock.LineHeightis set to a non-positive value.
        public static void SetLineHeight(DependencyObject element, double value);
        //
        // 요약:
        //     Sets the value of the System.Windows.Controls.TextBlock.LineStackingStrategy
        //     attached property on a specified dependency object.
        //
        // 매개 변수:
        //   element:
        //     The dependency object on which to set the value of the System.Windows.Controls.TextBlock.LineStackingStrategy
        //     property.
        //
        //   value:
        //     The new value to set the property to.
        //
        // 예외:
        //   T:System.ArgumentNullException:
        //     element is null.
        public static void SetLineStackingStrategy(DependencyObject element, LineStackingStrategy value);
        //
        // 요약:
        //     Sets the value of the System.Windows.Controls.TextBlock.TextAlignment attached
        //     property on a specified dependency object.
        //
        // 매개 변수:
        //   element:
        //     The dependency object on which to set the value of the System.Windows.Controls.TextBlock.TextAlignment
        //     property.
        //
        //   value:
        //     The new value to set the property to.
        //
        // 예외:
        //   T:System.ArgumentNullException:
        //     element is null.
        public static void SetTextAlignment(DependencyObject element, TextAlignment value);
        //
        // 요약:
        //     Returns a System.Windows.Documents.TextPointer to the position closest to a specified
        //     System.Windows.Point.
        //
        // 매개 변수:
        //   point:
        //     A System.Windows.Point in the coordinate space of the System.Windows.Controls.TextBlock
        //     for which to return a System.Windows.Documents.TextPointer.
        //
        //   snapToText:
        //     true to return a System.Windows.Documents.TextPointer to the insertion point
        //     closest to point, whether or not point is inside a character's bounding box;
        //     false to return null if point is not inside a character's bounding box.
        //
        // 반환 값:
        //     A System.Windows.Documents.TextPointer to the specified point, or null if snapToText
        //     is false and the specified point does not fall within a character bounding box
        //     in the System.Windows.Controls.TextBlock content area.
        //
        // 예외:
        //   T:System.InvalidOperationException:
        //     Current, valid layout information for the control is unavailable.
        public TextPointer GetPositionFromPoint(Point point, bool snapToText);
        //
        // 요약:
        //     Returns a value that indicates whether the effective value of the System.Windows.Controls.TextBlock.BaselineOffset
        //     property should be serialized during serialization of a System.Windows.Controls.TextBlock
        //     object.
        //
        // 반환 값:
        //     true if the System.Windows.Controls.TextBlock.BaselineOffset property should
        //     be serialized; otherwise, false.
        [EditorBrowsable(EditorBrowsableState.Never)]
        public bool ShouldSerializeBaselineOffset();
        //
        // 요약:
        //     Returns a value that indicates whether the effective value of the System.Windows.Controls.TextBlock.Inlines
        //     property should be serialized during serialization of a System.Windows.Controls.TextBlock
        //     object.
        //
        // 매개 변수:
        //   manager:
        //     A serialization service manager object for this object.
        //
        // 반환 값:
        //     true if the System.Windows.Controls.TextBlock.Inlines property should be serialized;
        //     otherwise, false.
        //
        // 예외:
        //   T:System.ArgumentNullException:
        //     manager is null.
        [EditorBrowsable(EditorBrowsableState.Never)]
        public bool ShouldSerializeInlines(XamlDesignerSerializationManager manager);
        //
        // 요약:
        //     Returns a value that indicates whether the effective value of the System.Windows.Controls.TextBlock.Text
        //     property should be serialized during serialization of a System.Windows.Controls.TextBlock
        //     object.
        //
        // 반환 값:
        //     true if the System.Windows.Controls.TextBlock.Text property should be serialized;
        //     otherwise, false.
        [EditorBrowsable(EditorBrowsableState.Never)]
        public bool ShouldSerializeText();
        //
        // 요약:
        //     Positions child elements and determines a size for the System.Windows.Controls.TextBlock.
        //
        // 매개 변수:
        //   arrangeSize:
        //     A System.Windows.Size within the hosting parent element that the System.Windows.Controls.TextBlock
        //     should use to arrange itself and its child elements. Sizing constraints may affect
        //     this requested size.
        //
        // 반환 값:
        //     The actual System.Windows.Size used to arrange the element.
        protected sealed override Size ArrangeOverride(Size arrangeSize);
        //
        // 요약:
        //     Returns a read-only collection of bounding rectangles for a specified System.Windows.ContentElement.
        //
        // 매개 변수:
        //   child:
        //     A System.Windows.ContentElement for which to generate and return a collection
        //     of bounding rectangles.
        //
        // 반환 값:
        //     A read-only collection of bounding rectangles for the specified System.Windows.ContentElement.
        //
        // 예외:
        //   T:System.ArgumentNullException:
        //     child is null.
        protected virtual ReadOnlyCollection<Rect> GetRectanglesCore(ContentElement child);
        //
        // 요약:
        //     Returns the System.Windows.Media.Visual child at a specified index.
        //
        // 매개 변수:
        //   index:
        //     A zero-based index specifying the System.Windows.Media.Visual child to return.
        //     This value must be between 0 and (System.Windows.Controls.TextBlock.VisualChildrenCount
        //     minus 1)
        //
        // 반환 값:
        //     The System.Windows.Media.Visual child at the specified index.
        //
        // 예외:
        //   T:System.ArgumentOutOfRangeException:
        //     index is not between 0 and (System.Windows.Controls.TextBlock.VisualChildrenCount
        //     minus 1)
        protected override Visual GetVisualChild(int index);
        //
        // 요약:
        //     Returns a System.Windows.Media.PointHitTestResult for specified System.Windows.Media.PointHitTestParameters.
        //
        // 매개 변수:
        //   hitTestParameters:
        //     A System.Windows.Media.PointHitTestParameters object specifying the parameters
        //     to hit test for.
        //
        // 반환 값:
        //     A System.Windows.Media.PointHitTestResult for the specified hit test parameters.
        //
        // 예외:
        //   T:System.ArgumentNullException:
        //     hitTestParameters is null.
        protected sealed override HitTestResult HitTestCore(PointHitTestParameters hitTestParameters);
        //
        // 요약:
        //     Returns the System.Windows.IInputElement at a specified System.Windows.Point
        //     within the System.Windows.Controls.TextBlock.
        //
        // 매개 변수:
        //   point:
        //     A System.Windows.Point, in the coordinate space of the System.Windows.Controls.TextBlock,
        //     for which to return the corresponding System.Windows.IInputElement.
        //
        // 반환 값:
        //     The System.Windows.IInputElement found at the specified Point, or null if no
        //     such System.Windows.IInputElement can be found.
        protected virtual IInputElement InputHitTestCore(Point point);
        //
        // 요약:
        //     Called to re-measure the System.Windows.Controls.TextBlock.
        //
        // 매개 변수:
        //   constraint:
        //     A System.Windows.Size structure specifying any constraints on the size of the
        //     System.Windows.Controls.TextBlock.
        //
        // 반환 값:
        //     A System.Windows.Size structure indicating the new size of the System.Windows.Controls.TextBlock.
        protected sealed override Size MeasureOverride(Size constraint);
        //
        // 요약:
        //     Called when a child element deriving from System.Windows.UIElement changes its
        //     System.Windows.UIElement.DesiredSize.
        //
        // 매개 변수:
        //   child:
        //     The child System.Windows.UIElement element whose System.Windows.UIElement.DesiredSize
        //     has changed.
        protected virtual void OnChildDesiredSizeChangedCore(UIElement child);
        //
        // 요약:
        //     Creates and returns an System.Windows.Automation.Peers.AutomationPeer object
        //     for this System.Windows.Controls.TextBlock.
        //
        // 반환 값:
        //     An System.Windows.Automation.Peers.AutomationPeer object for this System.Windows.Controls.TextBlock.
        protected override AutomationPeer OnCreateAutomationPeer();
        //
        // 요약:
        //     Called when the value one or more hosted dependency properties changes.
        //
        // 매개 변수:
        //   e:
        //     Arguments for the associated event.
        protected sealed override void OnPropertyChanged(DependencyPropertyChangedEventArgs e);
        //
        // 요약:
        //     Renders the contents of a System.Windows.Controls.TextBlock.
        //
        // 매개 변수:
        //   ctx:
        //     The System.Windows.Media.DrawingContext to render the control on.
        //
        // 예외:
        //   T:System.ArgumentNullException:
        //     ctx is null.
        protected sealed override void OnRender(DrawingContext ctx);
    }
}");
                        sw7.Close();
                        fs7.Close();
                        break;

                    case "TextBox":
                        FileStream fs8 = new FileStream(filePath + @"\TextBox.cs", FileMode.OpenOrCreate, FileAccess.Write);
                        StreamWriter sw8 = new StreamWriter(fs8, Encoding.UTF8);

                        sw8.WriteLine(@"#region 어셈블리 PresentationFramework, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35
// C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.5\PresentationFramework.dll
#endregion

using System.Collections;
using System.ComponentModel;
using System.Windows.Automation.Peers;
using System.Windows.Controls.Primitives;
using System.Windows.Documents;
using System.Windows.Markup;

namespace System.Windows.Controls
{
    //
    // 요약:
    //     Represents a control that can be used to display or edit unformatted text.
    [ContentProperty(""Text"")]
    [Localizability(LocalizationCategory.Text)]
    public class TextBox : TextBoxBase, IAddChild, ITextBoxViewHost
        {
            //
            // 요약:
            //     Identifies the System.Windows.Controls.TextBox.TextWrapping dependency property.
            public static readonly DependencyProperty TextWrappingProperty;
            //
            // 요약:
            //     Identifies the System.Windows.Controls.TextBox.MinLines dependency property.
            //
            // 반환 값:
            //     The identifier for the System.Windows.Controls.TextBox.MinLines dependency property.
            public static readonly DependencyProperty MinLinesProperty;
            //
            // 요약:
            //     Identifies the System.Windows.Controls.TextBox.MaxLines dependency property.
            //
            // 반환 값:
            //     The identifier for the System.Windows.Controls.TextBox.MaxLines dependency property.
            public static readonly DependencyProperty MaxLinesProperty;
            //
            // 요약:
            //     Identifies the System.Windows.Controls.TextBox.Text dependency property.
            //
            // 반환 값:
            //     The identifier for the System.Windows.Controls.TextBox.Text dependency property.
            public static readonly DependencyProperty TextProperty;
            //
            // 요약:
            //     Identifies the System.Windows.Controls.TextBox.CharacterCasing dependency property.
            //
            // 반환 값:
            //     The identifier for the System.Windows.Controls.TextBox.CharacterCasing dependency
            //     property.
            public static readonly DependencyProperty CharacterCasingProperty;
            //
            // 요약:
            //     Identifies the System.Windows.Controls.TextBox.MaxLength dependency property.
            //
            // 반환 값:
            //     The identifier for the System.Windows.Controls.TextBox.MaxLength dependency property.
            public static readonly DependencyProperty MaxLengthProperty;
            //
            // 요약:
            //     Identifies the System.Windows.Controls.TextBox.TextAlignment dependency property.
            //
            // 반환 값:
            //     The identifier for the System.Windows.Controls.TextBox.TextAlignment dependency
            //     property.
            public static readonly DependencyProperty TextAlignmentProperty;
            //
            // 요약:
            //     Identifies the System.Windows.Controls.TextBox.TextDecorations dependency property.
            public static readonly DependencyProperty TextDecorationsProperty;

            //
            // 요약:
            //     Initializes a new instance of the System.Windows.Controls.TextBox class.
            public TextBox();

            //
            // 요약:
            //     Gets or sets the minimum number of visible lines.
            //
            // 반환 값:
            //     The minimum number of visible lines. The default is 1.
            //
            // 예외:
            //   T:System.Exception:
            //     System.Windows.Controls.TextBox.MinLines is greater than System.Windows.Controls.TextBox.MaxLines.
            [DefaultValue(1)]
            public int MinLines { get; set; }
            //
            // 요약:
            //     Gets or sets the maximum number of visible lines.
            //
            // 반환 값:
            //     The maximum number of visible lines. The default is System.Int32.MaxValue.
            //
            // 예외:
            //   T:System.Exception:
            //     System.Windows.Controls.TextBox.MaxLines is less than System.Windows.Controls.TextBox.MinLines.
            [DefaultValue(int.MaxValue)]
            public int MaxLines { get; set; }
            //
            // 요약:
            //     Gets or sets the text contents of the text box.
            //
            // 반환 값:
            //     A string containing the text contents of the text box. The default is an empty
            //     string ("").
            [DefaultValue("")]
            [Localizability(LocalizationCategory.Text)]
            public string Text { get; set; }
            //
            // 요약:
            //     Gets or sets how characters are cased when they are manually entered into the
            //     text box.
            //
            // 반환 값:
            //     One of the System.Windows.Controls.CharacterCasing values that specifies how
            //     manually entered characters are cased. The default is System.Windows.Controls.CharacterCasing.Normal.
            public CharacterCasing CharacterCasing { get; set; }
            //
            // 요약:
            //     Gets or sets the maximum number of characters that can be manually entered into
            //     the text box.
            //
            // 반환 값:
            //     The maximum number of characters that can be manually entered into the text box.
            //     The default is 0, which indicates no limit.
            [DefaultValue(0)]
            [Localizability(LocalizationCategory.None, Modifiability = Modifiability.Unmodifiable)]
            public int MaxLength { get; set; }
            //
            // 요약:
            //     Gets or sets the horizontal alignment of the contents of the text box.
            //
            // 반환 값:
            //     One of the System.Windows.TextAlignment values that specifies the horizontal
            //     alignment of the contents of the text box. The default is System.Windows.TextAlignment.Left.
            public TextAlignment TextAlignment { get; set; }
            //
            // 요약:
            //     Gets or sets the insertion position index of the caret.
            //
            // 반환 값:
            //     The zero-based insertion position index of the caret.
            [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
            public int CaretIndex { get; set; }
            //
            // 요약:
            //     Gets or sets a value indicating the number of characters in the current selection
            //     in the text box.
            //
            // 반환 값:
            //     The number of characters in the current selection in the text box. The default
            //     is 0.
            //
            // 예외:
            //   T:System.ArgumentOutOfRangeException:
            //     System.Windows.Controls.TextBox.SelectionLength is set to a negative value.
            [DefaultValue(0)]
            [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
            public int SelectionLength { get; set; }
            //
            // 요약:
            //     Gets or sets a character index for the beginning of the current selection.
            //
            // 반환 값:
            //     The character index for the beginning of the current selection.
            //
            // 예외:
            //   T:System.ArgumentOutOfRangeException:
            //     System.Windows.Controls.TextBox.SelectionStart is set to a negative value.
            [DefaultValue(0)]
            [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
            public int SelectionStart { get; set; }
            //
            // 요약:
            //     Gets the currently effective typography variations for the text contents of the
            //     text box.
            //
            // 반환 값:
            //     A System.Windows.Documents.Typography object that specifies the currently effective
            //     typography variations. For a list of default typography values, see System.Windows.Documents.Typography.
            public Typography Typography { get; }
            //
            // 요약:
            //     Gets the total number of lines in the text box.
            //
            // 반환 값:
            //     The total number of lines in the text box, or –1 if layout information is not
            //     available.
            [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
            public int LineCount { get; }
            //
            // 요약:
            //     Gets the text decorations to apply to the text box.
            //
            // 반환 값:
            //     A System.Windows.TextDecorationCollection collection that contains text decorations
            //     to apply to the text box. The default is null (no text decorations applied).
            public TextDecorationCollection TextDecorations { get; set; }
            //
            // 요약:
            //     Gets or sets the content of the current selection in the text box.
            //
            // 반환 값:
            //     The currently selected text in the text box.
            [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
            public string SelectedText { get; set; }
            //
            // 요약:
            //     Gets or sets how the text box should wrap text.
            //
            // 반환 값:
            //     One of the System.Windows.TextWrapping values that indicates how the text box
            //     should wrap text. The default is System.Windows.TextWrapping.NoWrap.
            public TextWrapping TextWrapping { get; set; }
            //
            // 요약:
            //     Gets an enumerator for the logical child elements of the System.Windows.Controls.TextBox.
            //
            // 반환 값:
            //     An enumerator for the logical child elements of the System.Windows.Controls.TextBox.
            protected internal override IEnumerator LogicalChildren { get; }

            //
            // 요약:
            //     Clears all the content from the text box.
            public void Clear();
            //
            // 요약:
            //     Returns the zero-based character index for the first character in the specified
            //     line.
            //
            // 매개 변수:
            //   lineIndex:
            //     The zero-based index of the line to retrieve the initial character index for.
            //
            // 반환 값:
            //     The zero-based index for the first character in the specified line.
            public int GetCharacterIndexFromLineIndex(int lineIndex);
            //
            // 요약:
            //     Returns the zero-based index of the character that is closest to the specified
            //     point.
            //
            // 매개 변수:
            //   point:
            //     A point in System.Windows.Controls.TextBox coordinate-space for which to return
            //     an index.
            //
            //   snapToText:
            //     true to return the nearest index if there is no character at the specified point;
            //     false to return –1 if there is no character at the specified point.
            //
            // 반환 값:
            //     The index of the character that is closest to the specified point, or –1 if no
            //     valid index can be found.
            public int GetCharacterIndexFromPoint(Point point, bool snapToText);
            //
            // 요약:
            //     Returns the line index for the first line that is currently visible in the text
            //     box.
            //
            // 반환 값:
            //     The zero-based index for the first visible line in the text box.
            public int GetFirstVisibleLineIndex();
            //
            // 요약:
            //     Returns the line index for the last line that is currently visible in the text
            //     box.
            //
            // 반환 값:
            //     The zero-based index for the last visible line in the text box.
            public int GetLastVisibleLineIndex();
            //
            // 요약:
            //     Returns the zero-based line index for the line that contains the specified character
            //     index.
            //
            // 매개 변수:
            //   charIndex:
            //     The zero-based character index for which to retrieve the associated line index.
            //
            // 반환 값:
            //     The zero-based index for the line that contains the specified character index.
            public int GetLineIndexFromCharacterIndex(int charIndex);
            //
            // 요약:
            //     Returns the number of characters in the specified line.
            //
            // 매개 변수:
            //   lineIndex:
            //     The zero-based line index for which to return a character count.
            //
            // 반환 값:
            //     The number of characters in the specified line.
            public int GetLineLength(int lineIndex);
            //
            // 요약:
            //     Returns the text that is currently displayed on the specified line.
            //
            // 매개 변수:
            //   lineIndex:
            //     The zero-based line index for which to retrieve the currently displayed text.
            //
            // 반환 값:
            //     A string containing a copy of the text currently visible on the specified line.
            public string GetLineText(int lineIndex);
            //
            // 요약:
            //     Returns the beginning character index for the next spelling error in the contents
            //     of the text box.
            //
            // 매개 변수:
            //   charIndex:
            //     The zero-based character index indicating a position from which to search for
            //     the next spelling error.
            //
            //   direction:
            //     One of the System.Windows.Documents.LogicalDirection values that specifies the
            //     direction in which to search for the next spelling error, starting at the specified
            //     charIndex.
            //
            // 반환 값:
            //     The character index for the beginning of the next spelling error in the contents
            //     of the text box, or –1 if no next spelling error exists.
            public int GetNextSpellingErrorCharacterIndex(int charIndex, LogicalDirection direction);
            //
            // 요약:
            //     Returns the rectangle for the leading or trailing edge of the character at the
            //     specified index.
            //
            // 매개 변수:
            //   charIndex:
            //     The zero-based character index of the character for which to retrieve the rectangle.
            //
            //   trailingEdge:
            //     true to get the trailing edge of the character; false to get the leading edge
            //     of the character.
            //
            // 반환 값:
            //     A rectangle for an edge of the character at the specified character index, or
            //     System.Windows.Rect.Empty if a bounding rectangle cannot be determined.
            //
            // 예외:
            //   T:System.ArgumentOutOfRangeException:
            //     charIndex is negative or is greater than the length of the content.
            public Rect GetRectFromCharacterIndex(int charIndex, bool trailingEdge);
            //
            // 요약:
            //     Returns the rectangle for the leading edge of the character at the specified
            //     index.
            //
            // 매개 변수:
            //   charIndex:
            //     The zero-based character index of the character for which to retrieve the rectangle.
            //
            // 반환 값:
            //     A rectangle for the leading edge of the character at the specified character
            //     index, or System.Windows.Rect.Empty if a bounding rectangle cannot be determined.
            public Rect GetRectFromCharacterIndex(int charIndex);
            //
            // 요약:
            //     Returns a System.Windows.Controls.SpellingError object associated with any spelling
            //     error at the specified character index.
            //
            // 매개 변수:
            //   charIndex:
            //     The zero-based character index of a position in content to examine for a spelling
            //     error.
            //
            // 반환 값:
            //     A System.Windows.Controls.SpellingError object containing the details of the
            //     spelling error found at the character indicated by charIndex, or null if no spelling
            //     error exists at the specified character.
            public SpellingError GetSpellingError(int charIndex);
            //
            // 요약:
            //     Returns the length of any spelling error that includes the specified character.
            //
            // 매개 변수:
            //   charIndex:
            //     The zero-based character index of a position in content to examine for a spelling
            //     error.
            //
            // 반환 값:
            //     The length of any spelling error that includes the character specified by charIndex,
            //     or 0 if the specified character is not part of a spelling error.
            public int GetSpellingErrorLength(int charIndex);
            //
            // 요약:
            //     Returns the beginning character index for any spelling error that includes the
            //     specified character.
            //
            // 매개 변수:
            //   charIndex:
            //     The zero-based character index of a position in content to examine for a spelling
            //     error.
            //
            // 반환 값:
            //     The beginning character index for any spelling error that includes the character
            //     specified by charIndex, or –1 if the specified character is not part of a spelling
            //     error.
            public int GetSpellingErrorStart(int charIndex);
            //
            // 요약:
            //     Scrolls the line at the specified line index into view.
            //
            // 매개 변수:
            //   lineIndex:
            //     The zero-based line index of the line to scroll into view.
            public void ScrollToLine(int lineIndex);
            //
            // 요약:
            //     Selects a range of text in the text box.
            //
            // 매개 변수:
            //   start:
            //     The zero-based character index of the first character in the selection.
            //
            //   length:
            //     The length of the selection, in characters.
            //
            // 예외:
            //   T:System.ArgumentOutOfRangeException:
            //     start or length is negative.
            public void Select(int start, int length);
            //
            // 요약:
            //     Returns a value that indicates whether the effective value of the System.Windows.Controls.TextBox.Text
            //     property should be serialized during serialization of the System.Windows.Controls.TextBox
            //     object.
            //
            // 매개 변수:
            //   manager:
            //     A serialization service manager object for this object.
            //
            // 반환 값:
            //     true if the System.Windows.Controls.TextBox.Text property should be serialized;
            //     otherwise, false.
            //
            // 예외:
            //   T:System.NullReferenceException:
            //     manager is null.
            [EditorBrowsable(EditorBrowsableState.Never)]
            public bool ShouldSerializeText(XamlDesignerSerializationManager manager);
            //
            // 요약:
            //     Sizes the text box to its content.
            //
            // 매개 변수:
            //   constraint:
            //     A System.Windows.Size structure that specifies the constraints on the size of
            //     the text box.
            //
            // 반환 값:
            //     A System.Windows.Size structure indicating the new size of the text box.
            protected override Size MeasureOverride(Size constraint);
            //
            // 요약:
            //     Creates and returns an System.Windows.Automation.Peers.AutomationPeer object
            //     for the text box.
            //
            // 반환 값:
            //     An System.Windows.Automation.Peers.AutomationPeer object for the text box.
            protected override AutomationPeer OnCreateAutomationPeer();
            //
            // 요약:
            //     Called when one or more of the dependency properties that exist on the element
            //     have had their effective values changed.
            //
            // 매개 변수:
            //   e:
            //     Arguments for the associated event.
            protected override void OnPropertyChanged(DependencyPropertyChangedEventArgs e);
        }
    }");
                        sw8.Close();
                        fs8.Close();

                        break;


                    case "CheckBox":
                        FileStream fs9 = new FileStream(filePath + @"\CheckBox.cs", FileMode.OpenOrCreate, FileAccess.Write);
                        StreamWriter sw9 = new StreamWriter(fs9, Encoding.UTF8);

                        sw9.WriteLine(@"#region 어셈블리 PresentationFramework, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35
// C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.5\PresentationFramework.dll
#endregion

using System.ComponentModel;
using System.Windows.Automation.Peers;
using System.Windows.Controls.Primitives;
using System.Windows.Input;

namespace System.Windows.Controls
{
    //
    // 요약:
    //     Represents a control that a user can select and clear.
    [DefaultEvent(""CheckStateChanged"")]
    [Localizability(LocalizationCategory.CheckBox)]
    public class CheckBox : ToggleButton
        {
            //
            // 요약:
            //     Initializes a new instance of the System.Windows.Controls.CheckBox class.
            public CheckBox();

            //
            // 요약:
            //     Called when the access key for a System.Windows.Controls.CheckBox is invoked.
            //
            // 매개 변수:
            //   e:
            //     The System.Windows.Input.AccessKeyEventArgs that contains the event data.
            protected override void OnAccessKey(AccessKeyEventArgs e);
            //
            // 요약:
            //     Creates an System.Windows.Automation.Peers.AutomationPeer for the System.Windows.Controls.CheckBox.
            //
            // 반환 값:
            //     An System.Windows.Automation.Peers.AutomationPeer for the System.Windows.Controls.CheckBox.
            protected override AutomationPeer OnCreateAutomationPeer();
            //
            // 요약:
            //     Responds to a System.Windows.Controls.CheckBoxSystem.Windows.UIElement.KeyDown
            //     event.
            //
            // 매개 변수:
            //   e:
            //     The System.Windows.Input.KeyEventArgs that contains the event data.
            protected override void OnKeyDown(KeyEventArgs e);
        }
    }");

                        sw9.Close();
                        fs9.Close();

                        break;

                    case "ComboBox":
                        FileStream fs10 = new FileStream(filePath + @"\ComboBox.cs", FileMode.OpenOrCreate, FileAccess.Write);
                        StreamWriter sw10 = new StreamWriter(fs10, Encoding.UTF8);

                        sw10.WriteLine(@"#region 어셈블리 PresentationFramework, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35
// C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.5\PresentationFramework.dll
#endregion

using System.ComponentModel;
using System.Windows.Automation.Peers;
using System.Windows.Controls.Primitives;
using System.Windows.Input;

namespace System.Windows.Controls
{
    //
    // 요약:
    //     Represents a selection control with a drop-down list that can be shown or hidden
    //     by clicking the arrow on the control.
    [Localizability(LocalizationCategory.ComboBox)]
    [StyleTypedProperty(Property = ""ItemContainerStyle"", StyleTargetType = typeof(ComboBoxItem))]
    [TemplatePart(Name = ""PART_Popup"", Type = typeof(Popup))]
    [TemplatePart(Name = ""PART_EditableTextBox"", Type = typeof(TextBox))]
    public class ComboBox : Selector
        {
            //
            // 요약:
            //     Identifies the System.Windows.Controls.ComboBox.MaxDropDownHeight dependency
            //     property.
            //
            // 반환 값:
            //     The identifier for the System.Windows.Controls.ComboBox.MaxDropDownHeight dependency
            //     property.
            public static readonly DependencyProperty MaxDropDownHeightProperty;
            //
            // 요약:
            //     Identifies the System.Windows.Controls.ComboBox.IsDropDownOpen dependency property.
            //
            // 반환 값:
            //     The identifier for the System.Windows.Controls.ComboBox.IsDropDownOpen dependency
            //     property.
            public static readonly DependencyProperty IsDropDownOpenProperty;
            //
            // 요약:
            //     Identifies the System.Windows.Controls.ComboBox.ShouldPreserveUserEnteredPrefix
            //     dependency property.
            //
            // 반환 값:
            //     The identifier for the System.Windows.Controls.ComboBox.ShouldPreserveUserEnteredPrefix
            //     dependency property.
            public static readonly DependencyProperty ShouldPreserveUserEnteredPrefixProperty;
            //
            // 요약:
            //     Identifies the System.Windows.Controls.ComboBox.IsEditable dependency property.
            //
            // 반환 값:
            //     The identifier for the System.Windows.Controls.ComboBox.IsEditable dependency
            //     property.
            public static readonly DependencyProperty IsEditableProperty;
            //
            // 요약:
            //     Identifies the System.Windows.Controls.ComboBox.Text dependency property.
            //
            // 반환 값:
            //     The identifier for the System.Windows.Controls.ComboBox.Text dependency property.
            public static readonly DependencyProperty TextProperty;
            //
            // 요약:
            //     Identifies the System.Windows.Controls.ComboBox.IsReadOnly dependency property.
            //
            // 반환 값:
            //     The identifier for the System.Windows.Controls.ComboBox.IsReadOnly dependency
            //     property.
            public static readonly DependencyProperty IsReadOnlyProperty;
            //
            // 요약:
            //     Identifies the System.Windows.Controls.ComboBox.SelectionBoxItem dependency property.
            //
            // 반환 값:
            //     The identifier for the System.Windows.Controls.ComboBox.SelectionBoxItem dependency
            //     property.
            public static readonly DependencyProperty SelectionBoxItemProperty;
            //
            // 요약:
            //     Identifies the System.Windows.Controls.ComboBox.SelectionBoxItemTemplate dependency
            //     property.
            //
            // 반환 값:
            //     The identifier for the System.Windows.Controls.ComboBox.SelectionBoxItemTemplate
            //     dependency property.
            public static readonly DependencyProperty SelectionBoxItemTemplateProperty;
            //
            // 요약:
            //     Identifies the System.Windows.Controls.ComboBox.SelectionBoxItemStringFormat
            //     dependency property.
            //
            // 반환 값:
            //     The identifier for the System.Windows.Controls.ComboBox.SelectionBoxItemStringFormat
            //     dependency property.
            public static readonly DependencyProperty SelectionBoxItemStringFormatProperty;
            //
            // 요약:
            //     Identifies the System.Windows.Controls.ComboBox.StaysOpenOnEdit dependency property.
            //
            // 반환 값:
            //     The identifier for the System.Windows.Controls.ComboBox.StaysOpenOnEdit dependency
            //     property.
            public static readonly DependencyProperty StaysOpenOnEditProperty;

            //
            // 요약:
            //     Initializes a new instance of the System.Windows.Controls.ComboBox class.
            public ComboBox();

            //
            // 요약:
            //     Gets or sets a value that indicates whether the System.Windows.Controls.ComboBox
            //     keeps the user's input or replaces the input with a matching item.
            //
            // 반환 값:
            //     true if the System.Windows.Controls.ComboBox keeps the user's input; false if
            //     the System.Windows.Controls.ComboBox replaces the input with a matching item
            //     The registered default is false. For more information about what can influence
            //     the value, see Dependency Property Value Precedence.
            public bool ShouldPreserveUserEnteredPrefix { get; set; }
            //
            // 요약:
            //     Gets or sets a value that enables or disables editing of the text in text box
            //     of the System.Windows.Controls.ComboBox.
            //
            // 반환 값:
            //     true if the System.Windows.Controls.ComboBox can be edited; otherwise false.
            //     The default is false.
            public bool IsEditable { get; set; }
            //
            // 요약:
            //     Gets or sets the text of the currently selected item.
            //
            // 반환 값:
            //     The string of the currently selected item. The default is an empty string ("").
            public string Text { get; set; }
            //
            // 요약:
            //     Gets or sets a value that enables selection-only mode, in which the contents
            //     of the combo box are selectable but not editable.
            //
            // 반환 값:
            //     true if the System.Windows.Controls.ComboBox is read-only; otherwise, false.
            //     The default is false.
            public bool IsReadOnly { get; set; }
            //
            // 요약:
            //     Gets the item that is displayed in the selection box.
            //
            // 반환 값:
            //     The selected item.
            public object SelectionBoxItem { get; }
            //
            // 요약:
            //     Gets or sets the maximum height for a combo box drop-down.
            //
            // 반환 값:
            //     A double that represents the height that is retrieved or the height to set. The
            //     default value as defined to the property system is a calculated value based on
            //     taking a one-third fraction of the system max screen height parameters, but this
            //     default is potentially overridden by various control templates.
            [Bindable(true)]
            [Category(""Layout"")]
            [TypeConverter(typeof(LengthConverter))]
            public double MaxDropDownHeight { get; set; }
            //
            // 요약:
            //     Gets a composite string that specifies how to format the selected item in the
            //     selection box if it is displayed as a string.
            //
            // 반환 값:
            //     A composite string that specifies how to format the selected item in the selection
            //     box if it is displayed as a string.
            public string SelectionBoxItemStringFormat { get; }
            //
            // 요약:
            //     Gets or sets whether a System.Windows.Controls.ComboBox that is open and displays
            //     a drop-down control will remain open when a user clicks the System.Windows.Controls.TextBox.
            //
            // 반환 값:
            //     true to keep the drop-down control open when the user clicks on the text area
            //     to start editing; otherwise, false. The default is false.
            public bool StaysOpenOnEdit { get; set; }
            //
            // 요약:
            //     Gets whether the System.Windows.Controls.ComboBox.SelectionBoxItem is highlighted.
            //
            // 반환 값:
            //     true if the System.Windows.Controls.ComboBox.SelectionBoxItem is highlighted;
            //     otherwise, false.
            public bool IsSelectionBoxHighlighted { get; }
            //
            // 요약:
            //     Gets or sets a value that indicates whether the drop-down for a combo box is
            //     currently open.
            //
            // 반환 값:
            //     true if the drop-down is open; otherwise, false. The default is false.
            [Bindable(true)]
            [Browsable(false)]
            [Category(""Appearance"")]
            public bool IsDropDownOpen { get; set; }
            //
            // 요약:
            //     Gets the item template of the selection box content.
            //
            // 반환 값:
            //     An item template.
            public DataTemplate SelectionBoxItemTemplate { get; }
            //
            // 요약:
            //     Gets a value that indicates whether a combo box supports scrolling.
            //
            // 반환 값:
            //     true if the System.Windows.Controls.ComboBox supports scrolling; otherwise, false.
            //     The default is true.
            protected internal override bool HandlesScrolling { get; }
            //
            // 요약:
            //     Gets a value that indicates whether the System.Windows.Controls.ComboBox has
            //     focus.
            //
            // 반환 값:
            //     true if the System.Windows.Controls.ComboBox has focus; otherwise, false.
            protected internal override bool HasEffectiveKeyboardFocus { get; }

            //
            // 요약:
            //     Occurs when the drop-down list of the combo box closes.
            public event EventHandler DropDownClosed;
            //
            // 요약:
            //     Occurs when the drop-down list of the combo box opens.
            public event EventHandler DropDownOpened;

            //
            // 요약:
            //     Called when System.Windows.FrameworkElement.ApplyTemplate is called.
            public override void OnApplyTemplate();
            //
            // 요약:
            //     Creates or identifies the element used to display the specified item.
            //
            // 반환 값:
            //     The element used to display the specified item.
            protected override DependencyObject GetContainerForItemOverride();
            //
            // 요약:
            //     Determines if the specified item is (or is eligible to be) its own ItemContainer.
            //
            // 매개 변수:
            //   item:
            //     Specified item.
            //
            // 반환 값:
            //     true if the item is its own ItemContainer; otherwise, false.
            protected override bool IsItemItsOwnContainerOverride(object item);
            //
            // 요약:
            //     Provides an appropriate System.Windows.Automation.Peers.ComboBoxAutomationPeer
            //     implementation for this control, as part of the WPF infrastructure.
            //
            // 반환 값:
            //     The type-specific System.Windows.Automation.Peers.AutomationPeer implementation.
            protected override AutomationPeer OnCreateAutomationPeer();
            //
            // 요약:
            //     Reports when a combo box's popup closes.
            //
            // 매개 변수:
            //   e:
            //     The event data for the System.Windows.Controls.ComboBox.DropDownClosed event.
            protected virtual void OnDropDownClosed(EventArgs e);
            //
            // 요약:
            //     Reports when a combo box's popup opens.
            //
            // 매개 변수:
            //   e:
            //     The event data for the System.Windows.Controls.ComboBox.DropDownOpened event.
            protected virtual void OnDropDownOpened(EventArgs e);
            //
            // 요약:
            //     Reports that the System.Windows.ContentElement.IsKeyboardFocusWithin property
            //     changed.
            //
            // 매개 변수:
            //   e:
            //     The event data for the System.Windows.UIElement.IsKeyboardFocusWithinChanged
            //     event.
            protected override void OnIsKeyboardFocusWithinChanged(DependencyPropertyChangedEventArgs e);
            //
            // 요약:
            //     Called when the System.Windows.UIElement.IsMouseCaptured property changes.
            //
            // 매개 변수:
            //   e:
            //     The event data for the System.Windows.UIElement.IsMouseCapturedChanged event.
            protected override void OnIsMouseCapturedChanged(DependencyPropertyChangedEventArgs e);
            //
            // 요약:
            //     Invoked when a System.Windows.Input.Keyboard.KeyDown attached routed event occurs.
            //
            // 매개 변수:
            //   e:
            //     Event data.
            protected override void OnKeyDown(KeyEventArgs e);
            //
            // 요약:
            //     Called to report that the left mouse button was released.
            //
            // 매개 변수:
            //   e:
            //     The event data for the System.Windows.UIElement.MouseLeftButtonUp event.
            protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e);
            //
            // 요약:
            //     Invoked when a System.Windows.Input.Keyboard.PreviewKeyDown attached routed event
            //     occurs.
            //
            // 매개 변수:
            //   e:
            //     Event data.
            protected override void OnPreviewKeyDown(KeyEventArgs e);
            //
            // 요약:
            //     Responds to a System.Windows.Controls.ComboBox selection change by raising a
            //     System.Windows.Controls.Primitives.Selector.SelectionChanged event.
            //
            // 매개 변수:
            //   e:
            //     Provides data for System.Windows.Controls.SelectionChangedEventArgs.
            protected override void OnSelectionChanged(SelectionChangedEventArgs e);
            //
            // 요약:
            //     Prepares the specified element to display the specified item.
            //
            // 매개 변수:
            //   element:
            //     Element used to display the specified item.
            //
            //   item:
            //     Specified item.
            protected override void PrepareContainerForItemOverride(DependencyObject element, object item);
        }
    }");
                        sw10.Close();
                        fs10.Close();
                        break;

                    case "TreeView":
                        FileStream fs11 = new FileStream(filePath + @"\TreeView.cs", FileMode.OpenOrCreate, FileAccess.Write);
                        StreamWriter sw11 = new StreamWriter(fs11, Encoding.UTF8);

                        sw11.WriteLine(@"#region 어셈블리 PresentationFramework, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35
// C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.5\PresentationFramework.dll
#endregion

using System.Collections.Specialized;
using System.ComponentModel;
using System.Windows.Automation.Peers;
using System.Windows.Input;

namespace System.Windows.Controls
{
    //
    // 요약:
    //     Represents a control that displays hierarchical data in a tree structure that
    //     has items that can expand and collapse.
    [StyleTypedProperty(Property = ""ItemContainerStyle"", StyleTargetType = typeof(TreeViewItem))]
    public class TreeView : ItemsControl
        {
            //
            // 요약:
            //     Identifies the System.Windows.Controls.TreeView.SelectedItem dependency property.
            //
            // 반환 값:
            //     The identifier for the System.Windows.Controls.TreeView.SelectedItem dependency
            //     property.
            public static readonly DependencyProperty SelectedItemProperty;
            //
            // 요약:
            //     Identifies the System.Windows.Controls.TreeView.SelectedValue dependency property.
            //
            // 반환 값:
            //     The identifier for the System.Windows.Controls.TreeView.SelectedValuePathProperty
            //     dependency property.
            public static readonly DependencyProperty SelectedValueProperty;
            //
            // 요약:
            //     Identifies the System.Windows.Controls.TreeView.SelectedValuePath dependency
            //     property.
            //
            // 반환 값:
            //     The identifier for the System.Windows.Controls.TreeView.SelectedValuePath dependency
            //     property.
            public static readonly DependencyProperty SelectedValuePathProperty;
            //
            // 요약:
            //     Identifies the System.Windows.Controls.TreeView.SelectedItemChanged routed event.
            //
            // 반환 값:
            //     The identifier for the System.Windows.Controls.TreeView.SelectedItemChanged routed
            //     event.
            public static readonly RoutedEvent SelectedItemChangedEvent;

            //
            // 요약:
            //     Initializes a new instance of the System.Windows.Controls.TreeView class.
            public TreeView();

            //
            // 요약:
            //     Gets or sets the path that is used to get the System.Windows.Controls.TreeView.SelectedValue
            //     of the System.Windows.Controls.TreeView.SelectedItem in a System.Windows.Controls.TreeView.
            //
            // 반환 값:
            //     A string that contains the path that is used to get the System.Windows.Controls.TreeView.SelectedValue.
            //     The default value is String.Empty.
            [Bindable(true)]
            [Category(""Appearance"")]
            public string SelectedValuePath { get; set; }
            //
            // 요약:
            //     Gets the value of the property that is the specified by System.Windows.Controls.TreeView.SelectedValuePath
            //     for the System.Windows.Controls.TreeView.SelectedItem.
            //
            // 반환 값:
            //     The value of the property that is specified by the System.Windows.Controls.TreeView.SelectedValuePath
            //     for the System.Windows.Controls.TreeView.SelectedItem, or null if no item is
            //     selected. The default value is null.
            [Bindable(true)]
            [Category(""Appearance"")]
            [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
            [ReadOnly(true)]
            public object SelectedValue { get; }
            //
            // 요약:
            //     Gets the selected item in a System.Windows.Controls.TreeView.
            //
            // 반환 값:
            //     The selected object in the System.Windows.Controls.TreeView, or null if no item
            //     is selected. The default value is null.
            [Bindable(true)]
            [Category(""Appearance"")]
            [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
            [ReadOnly(true)]
            public object SelectedItem { get; }
            //
            // 요약:
            //     Gets whether the System.Windows.Controls.TreeView can scroll.
            //
            // 반환 값:
            //     Always returns true because the control has a System.Windows.Controls.ScrollViewer
            //     in its style.
            protected internal override bool HandlesScrolling { get; }

            //
            // 요약:
            //     Occurs when the System.Windows.Controls.TreeView.SelectedItem changes.
            [Category(""Behavior"")]
            public event RoutedPropertyChangedEventHandler<object> SelectedItemChanged;

            //
            // 요약:
            //     Expands the specified System.Windows.Controls.TreeViewItem control and all its
            //     child System.Windows.Controls.TreeViewItem elements.
            //
            // 매개 변수:
            //   container:
            //     The System.Windows.Controls.TreeViewItem to expand.
            //
            // 반환 값:
            //     true if the specified System.Windows.Controls.TreeViewItem and all its child
            //     elements were expanded; otherwise, false.
            protected virtual bool ExpandSubtree(TreeViewItem container);
            //
            // 요약:
            //     Creates a System.Windows.Controls.TreeViewItem to use to display content.
            //
            // 반환 값:
            //     A new System.Windows.Controls.TreeViewItem to use as a container for content.
            protected override DependencyObject GetContainerForItemOverride();
            //
            // 요약:
            //     Determines whether the specified item is its own container or can be its own
            //     container.
            //
            // 매개 변수:
            //   item:
            //     The object to evaluate.
            //
            // 반환 값:
            //     true if item is a System.Windows.Controls.TreeViewItem; otherwise, false.
            protected override bool IsItemItsOwnContainerOverride(object item);
            //
            // 요약:
            //     Defines an System.Windows.Automation.Peers.AutomationPeer for the System.Windows.Controls.TreeView
            //     control.
            //
            // 반환 값:
            //     A System.Windows.Automation.Peers.TreeViewAutomationPeer for the System.Windows.Controls.TreeView
            //     control.
            protected override AutomationPeer OnCreateAutomationPeer();
            //
            // 요약:
            //     Raises the System.Windows.UIElement.GotFocus routed event.
            //
            // 매개 변수:
            //   e:
            //     The data for the event.
            protected override void OnGotFocus(RoutedEventArgs e);
            //
            // 요약:
            //     Provides class handling for an System.Windows.ContentElement.IsKeyboardFocusWithinChanged
            //     event when the keyboard focus changes for a System.Windows.Controls.TreeView.
            //
            // 매개 변수:
            //   e:
            //     The event data.
            protected override void OnIsKeyboardFocusWithinChanged(DependencyPropertyChangedEventArgs e);
            //
            // 요약:
            //     Provides class handling for an System.Windows.Controls.ItemContainerGenerator.ItemsChanged
            //     event that occurs when there is a change in the System.Windows.Controls.ItemsControl.Items
            //     collection.
            //
            // 매개 변수:
            //   e:
            //     The event data.
            protected override void OnItemsChanged(NotifyCollectionChangedEventArgs e);
            //
            // 요약:
            //     Provides class handling for the System.Windows.UIElement.KeyDown event for a
            //     System.Windows.Controls.TreeView.
            //
            // 매개 변수:
            //   e:
            //     The event data.
            protected override void OnKeyDown(KeyEventArgs e);
            //
            // 요약:
            //     Raises the System.Windows.Controls.TreeView.SelectedItemChanged event when the
            //     System.Windows.Controls.TreeView.SelectedItem property value changes.
            //
            // 매개 변수:
            //   e:
            //     Provides the item that was previously selected and the item that is currently
            //     selected for the System.Windows.Controls.TreeView.SelectedItemChanged event.
            protected virtual void OnSelectedItemChanged(RoutedPropertyChangedEventArgs<object> e);
        }
    }");
                        sw11.Close();
                        fs11.Close();
                        break;

                    case "ListView":
                        FileStream fs12 = new FileStream(filePath + @"\ListView.cs", FileMode.OpenOrCreate, FileAccess.Write);
                        StreamWriter sw12 = new StreamWriter(fs12, Encoding.UTF8);
                        sw12.WriteLine(@"#region 어셈블리 PresentationFramework, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35
// C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.5\PresentationFramework.dll
#endregion

using System.Collections.Specialized;
using System.Windows.Automation.Peers;

namespace System.Windows.Controls
{
    //
    // 요약:
    //     Represents a control that displays a list of data items.
    [StyleTypedProperty(Property = ""ItemContainerStyle"", StyleTargetType = typeof(ListViewItem))]
    public class ListView : ListBox
        {
            //
            // 요약:
            //     Identifies the System.Windows.Controls.ListView.View dependency property.
            //
            // 반환 값:
            //     The identifier for the System.Windows.Controls.ListView.View dependency property.
            public static readonly DependencyProperty ViewProperty;

            //
            // 요약:
            //     Initializes a new instance of the System.Windows.Controls.ListView class.
            public ListView();

            //
            // 요약:
            //     Gets or sets an object that defines how the data is styled and organized in a
            //     System.Windows.Controls.ListView control.
            //
            // 반환 값:
            //     A System.Windows.Controls.ViewBase object that specifies how to display information
            //     in the System.Windows.Controls.ListView.
            public ViewBase View { get; set; }

            //
            // 요약:
            //     Removes all templates, styles, and bindings for the object that is displayed
            //     as a System.Windows.Controls.ListViewItem.
            //
            // 매개 변수:
            //   element:
            //     The System.Windows.Controls.ListViewItem container to clear.
            //
            //   item:
            //     The object that the System.Windows.Controls.ListViewItem contains.
            protected override void ClearContainerForItemOverride(DependencyObject element, object item);
            //
            // 요약:
            //     Creates and returns a new System.Windows.Controls.ListViewItem container.
            //
            // 반환 값:
            //     A new System.Windows.Controls.ListViewItem control.
            protected override DependencyObject GetContainerForItemOverride();
            //
            // 요약:
            //     Determines whether an object is a System.Windows.Controls.ListViewItem.
            //
            // 매개 변수:
            //   item:
            //     The object to evaluate.
            //
            // 반환 값:
            //     true if the item is a System.Windows.Controls.ListViewItem; otherwise, false.
            protected override bool IsItemItsOwnContainerOverride(object item);
            //
            // 요약:
            //     Defines an System.Windows.Automation.Peers.AutomationPeer for the System.Windows.Controls.ListView
            //     control.
            //
            // 반환 값:
            //     Returns a System.Windows.Automation.Peers.ListViewAutomationPeer object for the
            //     System.Windows.Controls.ListView control.
            protected override AutomationPeer OnCreateAutomationPeer();
            //
            // 요약:
            //     Responds to an System.Windows.Controls.ItemsControl.OnItemsChanged(System.Collections.Specialized.NotifyCollectionChangedEventArgs).
            //
            // 매개 변수:
            //   e:
            //     The event arguments.
            protected override void OnItemsChanged(NotifyCollectionChangedEventArgs e);
            //
            // 요약:
            //     Sets the styles, templates, and bindings for a System.Windows.Controls.ListViewItem.
            //
            // 매개 변수:
            //   element:
            //     An object that is a System.Windows.Controls.ListViewItem or that can be converted
            //     into one.
            //
            //   item:
            //     The object to use to create the System.Windows.Controls.ListViewItem.
            protected override void PrepareContainerForItemOverride(DependencyObject element, object item);
        }
    }");
                        sw12.Close();
                        fs12.Close();
                        break;

                    case "Image":
                        FileStream fs13 = new FileStream(filePath + @"\Image.cs", FileMode.OpenOrCreate, FileAccess.Write);
                        StreamWriter sw13 = new StreamWriter(fs13, Encoding.UTF8);

                        sw13.WriteLine(@"#region 어셈블리 PresentationFramework, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35
// C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.5\PresentationFramework.dll
#endregion

using System.Windows.Automation.Peers;
using System.Windows.Markup;
using System.Windows.Media;
using MS.Internal.PresentationFramework;

namespace System.Windows.Controls
{
    //
    // 요약:
    //     Represents a control that displays an image.
    [Localizability(LocalizationCategory.None, Readability = Readability.Unreadable)]
    public class Image : FrameworkElement, IUriContext, IProvidePropertyFallback
    {
        //
        // 요약:
        //     Identifies the System.Windows.Controls.Image.Source dependency property.
        //
        // 반환 값:
        //     The identifier for the System.Windows.Controls.Image.Source dependency property.
        [CommonDependencyPropertyAttribute]
        public static readonly DependencyProperty SourceProperty;
        //
        // 요약:
        //     Identifies the System.Windows.Controls.Image.Stretch dependency property.
        //
        // 반환 값:
        //     The identifier for the System.Windows.Controls.Image.Stretch dependency property.
        [CommonDependencyPropertyAttribute]
        public static readonly DependencyProperty StretchProperty;
        //
        // 요약:
        //     Identifies the System.Windows.Controls.StretchDirection dependency property.
        //
        // 반환 값:
        //     The identifier for the System.Windows.Controls.StretchDirection dependency property.
        public static readonly DependencyProperty StretchDirectionProperty;
        //
        // 요약:
        //     Identifies the System.Windows.Controls.Image.ImageFailed routed event.
        //
        // 반환 값:
        //     The identifier for the System.Windows.Controls.Image.ImageFailed routed event.
        public static readonly RoutedEvent ImageFailedEvent;

        //
        // 요약:
        //     Initializes a new instance of the System.Windows.Controls.Image class.
        public Image();

        //
        // 요약:
        //     Gets or sets the System.Windows.Media.ImageSource for the image.
        //
        // 반환 값:
        //     The source of the drawn image. The default value is null.
        public ImageSource Source { get; set; }
        //
        // 요약:
        //     Gets or sets a value that describes how an System.Windows.Controls.Image should
        //     be stretched to fill the destination rectangle.
        //
        // 반환 값:
        //     One of the System.Windows.Media.Stretch values. The default is System.Windows.Media.Stretch.Uniform.
        public Stretch Stretch { get; set; }
        //
        // 요약:
        //     Gets or sets a value that indicates how the image is scaled.
        //
        // 반환 값:
        //     One of the System.Windows.Controls.StretchDirection values. The default is System.Windows.Controls.StretchDirection.Both.
        public StretchDirection StretchDirection { get; set; }
        //
        // 요약:
        //     Gets or sets the base uniform resource identifier (URI) for the System.Windows.Controls.Image.
        //
        // 반환 값:
        //     A base URI for the System.Windows.Controls.Image.
        protected virtual Uri BaseUri { get; set; }

        //
        // 요약:
        //     Occurs when there is a failure in the image.
        public event EventHandler<ExceptionRoutedEventArgs> ImageFailed;

        //
        // 요약:
        //     Arranges and sizes an image control.
        //
        // 매개 변수:
        //   arrangeSize:
        //     The size used to arrange the control.
        //
        // 반환 값:
        //     The size of the control.
        protected override Size ArrangeOverride(Size arrangeSize);
        //
        // 요약:
        //     Updates the System.Windows.UIElement.DesiredSize of the image. This method is
        //     called by the parent System.Windows.UIElement and is the first pass of layout.
        //
        // 매개 변수:
        //   constraint:
        //     The size that the image should not exceed.
        //
        // 반환 값:
        //     The image's desired size.
        protected override Size MeasureOverride(Size constraint);
        //
        // 요약:
        //     Creates and returns an System.Windows.Automation.Peers.AutomationPeer object
        //     for this System.Windows.Controls.Image.
        //
        // 반환 값:
        //     An System.Windows.Automation.Peers.AutomationPeer object for this System.Windows.Controls.Image.
        protected override AutomationPeer OnCreateAutomationPeer();
        //
        // 요약:
        //     Renders the contents of an System.Windows.Controls.Image.
        //
        // 매개 변수:
        //   dc:
        //     An instance of System.Windows.Media.DrawingContext used to render the control.
        protected override void OnRender(DrawingContext dc);
    }
}");

                        sw13.Close();
                        fs13.Close();
                        break;


                    default:

                        break;
                }

                //sw.Close();
                //fs.Close();

            }
            catch (IOException err)
            {
                MessageBox.Show(err.Message);
            }
        }

        public void Func_MakeScriptFileForComponent(string fileName, string type)
            // CSFile
        {
            FileStream fs = null;
            StreamReader sr = null;

            if (!File.Exists(fileName))
            {
                MakeScriptFileForm(fileName, type);
            }
            else
            {
                try
                {
                    fs = new FileStream(fileName, FileMode.OpenOrCreate, FileAccess.Read);
                    sr = new StreamReader(fs, Encoding.Default);
                }
                catch (IOException err) { MessageBox.Show(err.Message); }
                finally
                {
                    sr.Close();
                    fs.Close();                    
                }
            }

            return;
        }
        public void MakeXamlFileToObject(object obj, string[] Property)
        {
            if (obj.GetType().ToString().Contains("Button"))
            {
                Button btn = obj as Button;

                FileStream fs1 = null;
                StreamWriter sw1 = null;

                FileStream fs2 = null;
                StreamWriter sw2 = null;

                try
                {
                    fs1 = new FileStream(StaticHelper.ProjectPath + @"\" + Property[0] + ".xaml", FileMode.OpenOrCreate, FileAccess.Write);
                    sw1 = new StreamWriter(fs1, Encoding.Default);

                    sw1.WriteLine("<UserControl x:Class=\"MARINEWIZ.View.UserControls.UIButton\"");
                    sw1.WriteLine("xmlns=\"http://schemas.microsoft.com/winfx/2006/xaml/presentation\"");
                    sw1.WriteLine("xmlns:x=\"http://schemas.microsoft.com/winfx/2006/xaml\"");
                    sw1.WriteLine("xmlns:mc=\"http://schemas.openxmlformats.org/markup-compatibility/2006\"");
                    sw1.WriteLine("xmlns:d=\"http://schemas.microsoft.com/expression/blend/2008\"");
                    sw1.WriteLine("mc:Ignorable=\"d\"");
                    sw1.WriteLine("Width=\"Auto\" Height=\"Auto\" HorizontalAlignment=\"Stretch\" VerticalAlignment=\"Stretch\"");
                    sw1.WriteLine(">");
                    sw1.WriteLine("<Button");
                    sw1.WriteLine("Name=\"" + Property[0] + "\"");
                    sw1.WriteLine("Tag=\"" + Property[1] + "\"");
                    sw1.WriteLine("Width=\"" + Property[2] + "\"");
                    sw1.WriteLine("Height=\"" + Property[3] + "\"");
                    sw1.WriteLine("HorizontalAlignment=\"" + Property[4] + "\"");
                    sw1.WriteLine("VerticalAlignment=\"" + Property[5] + "\"");
                    sw1.WriteLine("HorizontalContentAlignment=\"" + Property[6] + "\"");
                    sw1.WriteLine("VerticalContentAlignment=\"" + Property[7] + "\"");
                    sw1.WriteLine("Content=\"" + Property[8] + "\"");
                    sw1.WriteLine("/>");
                    sw1.WriteLine("</UserControl>");

                    fs2 = new FileStream(StaticHelper.ProjectPath + @"\" + Property[0] + ".cs", FileMode.OpenOrCreate, FileAccess.Write);
                    sw2 = new StreamWriter(fs2, Encoding.Default);

                    //TODO : 저기를 프로젝트 이름으로 바꿔줘야하나.
                    sw2.WriteLine(@"using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace MARINEWIZ.View.UserControls
{
    /// <summary>
    /// UIButton.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class UIButton : UserControl
    {
        public UIButton()
        {
            InitializeComponent();
            AddEventHandler();
        }

        protected bool isDragging;
        private Point clickPosition;

        private void AddEventHandler()
        {
            this.MouseDoubleClick += new MouseButtonEventHandler(Control_MouseLeftButtonDown);
            this.MouseLeftButtonUp += new MouseButtonEventHandler(Control_MouseLeftButtonUp);
            this.MouseMove += new MouseEventHandler(Control_MouseMove);
        }

        private void Control_MouseMove(object sender, MouseEventArgs e)
        {
            var draggableControl = sender as UserControl;

            if (isDragging && draggableControl != null)
            {
                Point currentPosition = e.GetPosition(this.Parent as UIElement);
                var transform = draggableControl.RenderTransform as TranslateTransform;
                if (transform == null)
                {
                    transform = new TranslateTransform();
                    draggableControl.RenderTransform = transform;
                }

                transform.X = currentPosition.X - clickPosition.X;
                transform.Y = currentPosition.Y - clickPosition.Y;
            }
        }

        private void Control_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            isDragging = false;
            var draggable = sender as UserControl;
            draggable.ReleaseMouseCapture();
        }

        private void Control_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            isDragging = true;
            var draggableControl = sender as UserControl;
            clickPosition = e.GetPosition(this);
            draggableControl.CaptureMouse();
        }
    }
}
");


                }
                catch (Exception err)
                {
                    MessageBox.Show(err.Message);
                }
                finally
                {
                    sw1.Close();
                    fs1.Close();
                    sw2.Close();
                    fs2.Close();
                }
            }
            else if (obj.GetType().ToString().Contains("TreeView"))
            {
                TreeView tv = obj as TreeView;

                FileStream fs1 = null;
                StreamWriter sw1 = null;

                FileStream fs2 = null;
                StreamWriter sw2 = null;

                try
                {
                    fs1 = new FileStream(StaticHelper.ProjectPath + @"\" + Property[0] + ".xaml", FileMode.OpenOrCreate, FileAccess.Write);
                    sw1 = new StreamWriter(fs1, Encoding.Default);

                    fs2 = new FileStream(StaticHelper.ProjectPath + @"\" + Property[0] + ".cs", FileMode.OpenOrCreate, FileAccess.Write);
                    sw2 = new StreamWriter(fs2, Encoding.Default);

                    sw1.WriteLine("<UserControl x:Class=\"MARINEWIZ.View.UserControls.UITreeView\"");
                    sw1.WriteLine("xmlns=\"http://schemas.microsoft.com/winfx/2006/xaml/presentation\"");
                    sw1.WriteLine("xmlns:x=\"http://schemas.microsoft.com/winfx/2006/xaml\"");
                    sw1.WriteLine("xmlns:mc=\"http://schemas.openxmlformats.org/markup-compatibility/2006\"");
                    sw1.WriteLine("xmlns:d=\"http://schemas.microsoft.com/expression/blend/2008\"");
                    sw1.WriteLine("mc:Ignorable=\"d\"");
                    sw1.WriteLine("Width=\"Auto\" Height=\"Auto\" HorizontalAlignment=\"Stretch\" VerticalAlignment=\"Stretch\"");
                    sw1.WriteLine(">");
                    sw1.WriteLine("<TreeView");
                    sw1.WriteLine("Name=\"" + Property[0] + "\"");
                    sw1.WriteLine("Tag=\"" + Property[1] + "\"");
                    sw1.WriteLine("Width=\"" + Property[2] + "\"");
                    sw1.WriteLine("Height=\"" + Property[3] + "\"");
                    sw1.WriteLine("HorizontalAlignment=\"" + Property[4] + "\"");
                    sw1.WriteLine("VerticalAlignment=\"" + Property[5] + "\"");
                    sw1.WriteLine("HorizontalContentAlignment=\"" + Property[6] + "\"");
                    sw1.WriteLine("VerticalContentAlignment=\"" + Property[7] + "\"");
                    sw1.WriteLine(">");
                    sw1.WriteLine("");
                    sw1.WriteLine("</TreeView>");
                    sw1.WriteLine("</UserControl>");

                    sw2.WriteLine(@"using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace MARINEWIZ.View.UserControls
{
    /// <summary>
    /// UITreeView.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class UITreeView : UserControl
    {
        public UITreeView()
        {
            InitializeComponent();
            AddEventHandler();
        }

        protected bool isDragging;
        private Point clickPosition;

        private void AddEventHandler()
        {
            this.MouseDoubleClick += new MouseButtonEventHandler(Control_MouseLeftButtonDown);
            this.MouseLeftButtonUp += new MouseButtonEventHandler(Control_MouseLeftButtonUp);
            this.MouseMove += new MouseEventHandler(Control_MouseMove);
        }

        private void Control_MouseMove(object sender, MouseEventArgs e)
        {
            var draggableControl = sender as UserControl;

            if (isDragging && draggableControl != null)
            {
                Point currentPosition = e.GetPosition(this.Parent as UIElement);
                var transform = draggableControl.RenderTransform as TranslateTransform;
                if (transform == null)
                {
                    transform = new TranslateTransform();
                    draggableControl.RenderTransform = transform;
                }

                transform.X = currentPosition.X - clickPosition.X;
                transform.Y = currentPosition.Y - clickPosition.Y;
            }
        }

        private void Control_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            isDragging = false;
            var draggable = sender as UserControl;
            draggable.ReleaseMouseCapture();
        }

        private void Control_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            isDragging = true;
            var draggableControl = sender as UserControl;
            clickPosition = e.GetPosition(this);
            draggableControl.CaptureMouse();
        }
    }
}
");
                }
                catch (Exception err)
                {
                    MessageBox.Show(err.Message);
                }
                finally
                {
                    sw1.Close();
                    fs1.Close();
                    sw2.Close();
                    fs2.Close();
                }
            }
        }

  
        #region Private Func

        private void ExportToXaml(object target, string fileName)
        {
            try
            {
                FileStream fs = File.Open(fileName, FileMode.Create);
                XamlWriter.Save(target, fs);
                fs.Close();
            }
            catch { return; }
        }

        private void MakeScriptFileForm(string fileName, string type)
        {
            FileStream fs = null;
            StreamWriter sw = null;

            try
            {
                fs = new FileStream(fileName, FileMode.OpenOrCreate, FileAccess.Write);
                sw = new StreamWriter(fs, Encoding.Default);

                switch (type)
                {
                    case "BUTTON":




                        break;

                    default:
                        return;
                }
            }
            catch (IOException err)
            {
                MessageBox.Show(err.Message);
            }
            finally
            {
                sw.Close();
                fs.Close();
            }

        }

        #endregion


        public void MakeComponentFiles(UserControl target)
        {
            if (target.GetType().ToString().Contains("UIButton"))
            {
                FileStream fs1 = null;
                StreamWriter sw1 = null;

                FileStream fs2 = null;
                StreamWriter sw2 = null;

                try
                {
                    Button child = target.Content as Button;

                    //MessageBox.Show(child.Name);

                    fs1 = new FileStream(StaticHelper.CodePath + @"\" + child.Name + @".cs", FileMode.OpenOrCreate, FileAccess.Write);
                    sw1 = new StreamWriter(fs1, Encoding.UTF8);

                    fs2 = new FileStream(StaticHelper.XamlPath + @"\" + child.Name + @".xaml", FileMode.OpenOrCreate, FileAccess.Write);
                    sw2 = new StreamWriter(fs2, Encoding.UTF8);

                    sw1.WriteLine(@"using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Input;
    using System.Windows.Media;

    namespace MARINEWIZ1._0.View.UserControls
    {
        /// <summary>
        /// UIButton.xaml에 대한 상호 작용 논리
        /// </summary>
        public partial class UIButton : UserControl
        {
            public UIButton()
            {
                InitializeComponent();
                AddEventHandler();
            }

            protected bool isDragging;
            private Point clickPosition;

            private void AddEventHandler()
            {
                this.MouseDoubleClick += new MouseButtonEventHandler(Control_MouseLeftButtonDown);
                this.MouseLeftButtonUp += new MouseButtonEventHandler(Control_MouseLeftButtonUp);
                this.MouseMove += new MouseEventHandler(Control_MouseMove);
            }

            private void Control_MouseMove(object sender, MouseEventArgs e)
            {
                var draggableControl = sender as UserControl;

                if (isDragging && draggableControl != null)
                {
                    Point currentPosition = e.GetPosition(this.Parent as UIElement);
                    var transform = draggableControl.RenderTransform as TranslateTransform;
                    if (transform == null)
                    {
                        transform = new TranslateTransform();
                        draggableControl.RenderTransform = transform;
                    }

                    transform.X = currentPosition.X - clickPosition.X;
                    transform.Y = currentPosition.Y - clickPosition.Y;
                }
            }

            private void Control_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
            {
                isDragging = false;
                var draggable = sender as UserControl;
                draggable.ReleaseMouseCapture();
            }

            private void Control_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
            {
                isDragging = true;
                var draggableControl = sender as UserControl;
                clickPosition = e.GetPosition(this);
                draggableControl.CaptureMouse();
            }

            private void ClickEvent(object sender, System.Windows.RoutedEventArgs e){
                // Do Event
                
            }
        }
    }
                                    ");

                    sw2.WriteLine(
                        "<UserControl x:Class=\"MARINEWIZ1._0.View.UserControls.UIButton\"" +
                        "xmlns = \"http://schemas.microsoft.com/winfx/2006/xaml/presentation\" " +
                        "xmlns: x = \"http://schemas.microsoft.com/winfx/2006/xaml\"" +
                        "xmlns: mc = \"http://schemas.openxmlformats.org/markup-compatibility/2006\"" +
                        "xmlns: d = \"http://schemas.microsoft.com/expression/blend/2008\"" +
                        "mc: Ignorable = \"d\"" +
                        "Width = \"Auto\" Height = \"Auto\"" +
                        "HorizontalAlignment = \"Stretch\" VerticalAlignment = \"Stretch\">" +
                        "<Button" +
                        "Name= \"" + child.Name + "\" HorizontalAlignment =  \"" + child.HorizontalAlignment + "\" VerticalAlignment \"" + child.VerticalAlignment + "\"" +
                        "Width = \"" + child.Width + "\" Height = \"" + child.Height + "\" Content = \"" + child.Content + "\"" + "Click=" + "\"ClickEvent\"" +
                        ">" +                        
                        "</ Button >" +
                        "</ UserControl >"
                        );
                }
                catch (Exception err)
                {
                    MessageBox.Show(err.Message);
                    return;
                }
                finally
                {
                    sw1.Close();
                    fs1.Close();
                    sw2.Close();
                    fs2.Close();
                }
            }
            else if (target.GetType().ToString().Contains("UICheckBox"))
            {
                FileStream fs1 = null;
                StreamWriter sw1 = null;

                FileStream fs2 = null;
                StreamWriter sw2 = null;

                try
                {
                    CheckBox child = target.Content as CheckBox;

                    fs1 = new FileStream(StaticHelper.CodePath + @"\" + child.Name + @".cs", FileMode.OpenOrCreate, FileAccess.Write);
                    sw1 = new StreamWriter(fs1, Encoding.UTF8);

                    fs2 = new FileStream(StaticHelper.XamlPath + @"\" + child.Name + @".xaml", FileMode.OpenOrCreate, FileAccess.Write);
                    sw2 = new StreamWriter(fs2, Encoding.UTF8);

                    sw1.WriteLine(@"using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MARINEWIZ1._0.View.UserControls
{
    /// <summary>
    /// UICheckBox.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class UICheckBox : UserControl
    {
        public UICheckBox()
        {
            InitializeComponent();
            AddEventHandler();
        }

        protected bool isDragging;
        private Point clickPosition;

        private void AddEventHandler()
        {
            this.MouseDoubleClick += new MouseButtonEventHandler(Control_MouseLeftButtonDown);
            this.MouseLeftButtonUp += new MouseButtonEventHandler(Control_MouseLeftButtonUp);
            this.MouseMove += new MouseEventHandler(Control_MouseMove);
        }

        private void Control_MouseMove(object sender, MouseEventArgs e)
        {
            var draggableControl = sender as UserControl;

            if (isDragging && draggableControl != null)
            {
                Point currentPosition = e.GetPosition(this.Parent as UIElement);
                var transform = draggableControl.RenderTransform as TranslateTransform;
                if (transform == null)
                {
                    transform = new TranslateTransform();
                    draggableControl.RenderTransform = transform;
                }

                transform.X = currentPosition.X - clickPosition.X;
                transform.Y = currentPosition.Y - clickPosition.Y;
            }
        }

        private void Control_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            isDragging = false;
            var draggable = sender as UserControl;
            draggable.ReleaseMouseCapture();
        }

        private void Control_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            isDragging = true;
            var draggableControl = sender as UserControl;
            clickPosition = e.GetPosition(this);
            draggableControl.CaptureMouse();
        }
    }
}");
                    sw2.WriteLine(
                        "<UserControl " +
                        "x:Class=\"MARINEWIZ1._0.View.UserControls.UICheckBox\"" +
                        "xmlns = \"http://schemas.microsoft.com/winfx/2006/xaml/presentation\" " +
                        "xmlns: x = \"http://schemas.microsoft.com/winfx/2006/xaml\"" +
                        "xmlns: mc = \"http://schemas.openxmlformats.org/markup-compatibility/2006\"" +
                        "xmlns: d = \"http://schemas.microsoft.com/expression/blend/2008\"" +
                        "mc: Ignorable = \"d\"" +
                        "Width = \"Auto\" Height = \"Auto\"" +
                        "HorizontalAlignment = \"Stretch\" VerticalAlignment = \"Stretch\">" +
                        "<CheckBox" +
                        "Name= \"" + child.Name + "\" HorizontalAlignment =  \"" + child.HorizontalAlignment + "\" VerticalAlignment \"" + child.VerticalAlignment + "\"" +
                        "Width = \"" + child.Width + "\" Height = \"" + child.Height + "\" Content = \"" + child.Content + "\"" +
                        ">" +
                        "</ CheckBox >" +
                        "</ UserControl >");

                }
                catch (Exception err)
                {
                    MessageBox.Show(err.Message);
                }
                finally
                {
                    sw1.Close();
                    sw2.Close();
                    fs1.Close();
                    fs2.Close();
                }
            }
            else if (target.GetType().ToString().Contains("UIComboBox"))
            {
                FileStream fs1 = null;
                StreamWriter sw1 = null;

                FileStream fs2 = null;
                StreamWriter sw2 = null;

                try
                {
                    ComboBox child = target.Content as ComboBox;

                    fs1 = new FileStream(StaticHelper.CodePath + @"\" + child.Name + @".cs", FileMode.OpenOrCreate, FileAccess.Write);
                    sw1 = new StreamWriter(fs1, Encoding.UTF8);

                    fs2 = new FileStream(StaticHelper.XamlPath + @"\" + child.Name + @".xaml", FileMode.OpenOrCreate, FileAccess.Write);
                    sw2 = new StreamWriter(fs2, Encoding.UTF8);

                    sw1.WriteLine(@"using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace MARINEWIZ1._0.View.UserControls
{
    /// <summary>
    /// UIComboBox.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class UIComboBox : UserControl
    {
        public UIComboBox()
        {
            InitializeComponent();
            AddEventHandler();
        }

        protected bool isDragging;
        private Point clickPosition;

        private void AddEventHandler()
        {
            this.MouseDoubleClick += new MouseButtonEventHandler(Control_MouseLeftButtonDown);
            this.MouseLeftButtonUp += new MouseButtonEventHandler(Control_MouseLeftButtonUp);
            this.MouseMove += new MouseEventHandler(Control_MouseMove);
        }

        private void Control_MouseMove(object sender, MouseEventArgs e)
        {
            var draggableControl = sender as UserControl;

            if (isDragging && draggableControl != null)
            {
                Point currentPosition = e.GetPosition(this.Parent as UIElement);
                var transform = draggableControl.RenderTransform as TranslateTransform;
                if (transform == null)
                {
                    transform = new TranslateTransform();
                    draggableControl.RenderTransform = transform;
                }

                transform.X = currentPosition.X - clickPosition.X;
                transform.Y = currentPosition.Y - clickPosition.Y;
            }
        }

        private void Control_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            isDragging = false;
            var draggable = sender as UserControl;
            draggable.ReleaseMouseCapture();
        }

        private void Control_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            isDragging = true;
            var draggableControl = sender as UserControl;
            clickPosition = e.GetPosition(this);
            draggableControl.CaptureMouse();
        }
    }
}
");

                    sw2.WriteLine(
                        "<UserControl " +
                        "x:Class=\"MARINEWIZ1._0.View.UserControls.UIComboBox\"" +
                        "xmlns = \"http://schemas.microsoft.com/winfx/2006/xaml/presentation\" " +
                        "xmlns: x = \"http://schemas.microsoft.com/winfx/2006/xaml\"" +
                        "xmlns: mc = \"http://schemas.openxmlformats.org/markup-compatibility/2006\"" +
                        "xmlns: d = \"http://schemas.microsoft.com/expression/blend/2008\"" +
                        "mc: Ignorable = \"d\"" +
                        "Width = \"Auto\" Height = \"Auto\"" +
                        "HorizontalAlignment = \"Stretch\" VerticalAlignment = \"Stretch\">" +
                        "<ComboBox" +
                        "Name= \"" + child.Name + "\" HorizontalAlignment =  \"" + child.HorizontalAlignment + "\" VerticalAlignment \"" + child.VerticalAlignment + "\"" +
                        "Width = \"" + child.Width + "\" Height = \"" + child.Height + "\"" +
                        ">" +
                        "</ ComboBox >" +
                        "</ UserControl >");

                }
                catch (Exception err)
                {
                    MessageBox.Show(err.Message);
                }
                finally
                {
                    sw1.Close();
                    sw2.Close();
                    fs1.Close();
                    fs2.Close();
                }
            }
            else if (target.GetType().ToString().Contains("UIDockPanel"))
            {
                FileStream fs1 = null;
                StreamWriter sw1 = null;

                FileStream fs2 = null;
                StreamWriter sw2 = null;

                try
                {
                    DockPanel child = target.Content as DockPanel;

                    fs1 = new FileStream(StaticHelper.CodePath + @"\" + child.Name + @".cs", FileMode.OpenOrCreate, FileAccess.Write);
                    sw1 = new StreamWriter(fs1, Encoding.UTF8);

                    fs2 = new FileStream(StaticHelper.XamlPath + @"\" + child.Name + @".xaml", FileMode.OpenOrCreate, FileAccess.Write);
                    sw2 = new StreamWriter(fs2, Encoding.UTF8);

                    sw1.WriteLine(@"using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace MARINEWIZ1._0.View.UserControls
{
    /// <summary>
    /// UIDockPanel.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class UIDockPanel : UserControl
    {
        public UIDockPanel()
        {
            InitializeComponent();
            AddEventHandler();
        }

        protected bool isDragging;
        private Point clickPosition;

        private void AddEventHandler()
        {
            this.MouseDoubleClick += new MouseButtonEventHandler(Control_MouseLeftButtonDown);
            this.MouseLeftButtonUp += new MouseButtonEventHandler(Control_MouseLeftButtonUp);
            this.MouseMove += new MouseEventHandler(Control_MouseMove);
        }

        private void Control_MouseMove(object sender, MouseEventArgs e)
        {
            var draggableControl = sender as UserControl;

            if (isDragging && draggableControl != null)
            {
                Point currentPosition = e.GetPosition(this.Parent as UIElement);
                var transform = draggableControl.RenderTransform as TranslateTransform;
                if (transform == null)
                {
                    transform = new TranslateTransform();
                    draggableControl.RenderTransform = transform;
                }

                transform.X = currentPosition.X - clickPosition.X;
                transform.Y = currentPosition.Y - clickPosition.Y;
            }
        }

        private void Control_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            isDragging = false;
            var draggable = sender as UserControl;
            draggable.ReleaseMouseCapture();
        }

        private void Control_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            isDragging = true;
            var draggableControl = sender as UserControl;
            clickPosition = e.GetPosition(this);
            draggableControl.CaptureMouse();
        }
    }
}
");
                    sw2.WriteLine(
                        "<UserControl " +
                        "x:Class=\"MARINEWIZ1._0.View.UserControls.UIDockPanel\"" +
                        "xmlns = \"http://schemas.microsoft.com/winfx/2006/xaml/presentation\" " +
                        "xmlns: x = \"http://schemas.microsoft.com/winfx/2006/xaml\"" +
                        "xmlns: mc = \"http://schemas.openxmlformats.org/markup-compatibility/2006\"" +
                        "xmlns: d = \"http://schemas.microsoft.com/expression/blend/2008\"" +
                        "mc: Ignorable = \"d\"" +
                        "Width = \"Auto\" Height = \"Auto\"" +
                        "HorizontalAlignment = \"Stretch\" VerticalAlignment = \"Stretch\">" +
                        "<DockPanel" +
                        "Background=\"Gray\"" +
                        "Name= \"" + child.Name + "\" HorizontalAlignment =  \"" + child.HorizontalAlignment + "\" VerticalAlignment \"" + child.VerticalAlignment + "\"" +
                        "Width = \"" + child.Width + "\" Height = \"" + child.Height + "\"" +
                        ">" + 
                        "</DockPanel>" +
                        "</UserControl>");


                }
                catch (Exception err)
                {
                    MessageBox.Show(err.Message);
                }
                finally
                {
                    sw1.Close();
                    sw2.Close();
                    fs1.Close();
                    fs2.Close();
                }

            }
            /*
            else if (target.GetType().ToString().Contains("UIGridView"))
            {
                FileStream fs1 = null;
                StreamWriter sw1 = null;

                FileStream fs2 = null;
                StreamWriter sw2 = null;

                try
                {
                    GridView child = target.Content as GridView;

                    fs1 = new FileStream(StaticHelper.CodePath + @"\" + child.Name + @".cs", FileMode.OpenOrCreate, FileAccess.Write);
                    sw1 = new StreamWriter(fs1, Encoding.UTF8);

                    fs2 = new FileStream(StaticHelper.XamlPath + @"\" + child.Name + @".xaml", FileMode.OpenOrCreate, FileAccess.Write);
                    sw2 = new StreamWriter(fs2, Encoding.UTF8);

                    



                }catch(Exception err)
                {
                    MessageBox.Show(err.Message);
                }
                finally
                {
                    sw1.Close();
                    sw2.Close();
                    fs1.Close();
                    fs2.Close();
                }

            }
            */
            else if (target.GetType().ToString().Contains("UIImage"))
            {
                FileStream fs1 = null;
                StreamWriter sw1 = null;

                FileStream fs2 = null;
                StreamWriter sw2 = null;

                try
                {
                    Image child = target.Content as Image;

                    fs1 = new FileStream(StaticHelper.CodePath + @"\" + child.Name + @".cs", FileMode.OpenOrCreate, FileAccess.Write);
                    sw1 = new StreamWriter(fs1, Encoding.UTF8);

                    fs2 = new FileStream(StaticHelper.XamlPath + @"\" + child.Name + @".xaml", FileMode.OpenOrCreate, FileAccess.Write);
                    sw2 = new StreamWriter(fs2, Encoding.UTF8);


                    sw1.WriteLine(@"using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace MARINEWIZ1._0.View.UserControls
{
    /// <summary>
    /// UIImage.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class UIImage : UserControl
    {
        public UIImage()
        {
            InitializeComponent();
            AddEventHandler();
        }

        protected bool isDragging;
        private Point clickPosition;

        private void AddEventHandler()
        {
            this.MouseDoubleClick += new MouseButtonEventHandler(Control_MouseLeftButtonDown);
            this.MouseLeftButtonUp += new MouseButtonEventHandler(Control_MouseLeftButtonUp);
            this.MouseMove += new MouseEventHandler(Control_MouseMove);
        }

        private void Control_MouseMove(object sender, MouseEventArgs e)
        {
            var draggableControl = sender as UserControl;

            if (isDragging && draggableControl != null)
            {
                Point currentPosition = e.GetPosition(this.Parent as UIElement);
                var transform = draggableControl.RenderTransform as TranslateTransform;
                if (transform == null)
                {
                    transform = new TranslateTransform();
                    draggableControl.RenderTransform = transform;
                }

                transform.X = currentPosition.X - clickPosition.X;
                transform.Y = currentPosition.Y - clickPosition.Y;
            }
        }

        private void Control_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            isDragging = false;
            var draggable = sender as UserControl;
            draggable.ReleaseMouseCapture();
        }

        private void Control_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            isDragging = true;
            var draggableControl = sender as UserControl;
            clickPosition = e.GetPosition(this);
            draggableControl.CaptureMouse();
        }
    }
}
");
                    sw2.WriteLine(
                        "<UserControl " +
                        "x:Class=\"MARINEWIZ1._0.View.UserControls.UIImage\"" +
                        "xmlns = \"http://schemas.microsoft.com/winfx/2006/xaml/presentation\" " +
                        "xmlns: x = \"http://schemas.microsoft.com/winfx/2006/xaml\"" +
                        "xmlns: mc = \"http://schemas.openxmlformats.org/markup-compatibility/2006\"" +
                        "xmlns: d = \"http://schemas.microsoft.com/expression/blend/2008\"" +
                        "mc: Ignorable = \"d\"" +
                        "Width = \"Auto\" Height = \"Auto\"" +
                        "HorizontalAlignment = \"Stretch\" VerticalAlignment = \"Stretch\">" +
                        "<Image" +
                        "Name= \"" + child.Name + "\" HorizontalAlignment =  \"" + child.HorizontalAlignment + "\" VerticalAlignment \"" + child.VerticalAlignment + "\"" +
                        "Width = \"" + child.Width + "\" Height = \"" + child.Height + "\"" +
                        "Source = \"" + child.Source + "\"" +
                        ">" +
                        "</Image>" +
                        "</UserControl>");
                }
                catch (Exception err)
                {
                    MessageBox.Show(err.Message);
                }
                finally
                {
                    sw1.Close();
                    sw2.Close();
                    fs1.Close();
                    fs2.Close();
                }
            }
            else if (target.GetType().ToString().Contains("UILabel"))
            {
                FileStream fs1 = null;
                StreamWriter sw1 = null;

                FileStream fs2 = null;
                StreamWriter sw2 = null;

                try
                {
                    Label child = target.Content as Label;

                    fs1 = new FileStream(StaticHelper.CodePath + @"\" + child.Name + @".cs", FileMode.OpenOrCreate, FileAccess.Write);
                    sw1 = new StreamWriter(fs1, Encoding.UTF8);

                    fs2 = new FileStream(StaticHelper.XamlPath + @"\" + child.Name + @".xaml", FileMode.OpenOrCreate, FileAccess.Write);
                    sw2 = new StreamWriter(fs2, Encoding.UTF8);

                    sw1.WriteLine(@"using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace MARINEWIZ1._0.View.UserControls
{
    /// <summary>
    /// UILabel.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class UILabel : UserControl
    {
        public UILabel()
        {
            InitializeComponent();
            AddEventHandler();
        }

        protected bool isDragging;
        private Point clickPosition;

        private void AddEventHandler()
        {
            this.MouseDoubleClick += new MouseButtonEventHandler(Control_MouseLeftButtonDown);
            this.MouseLeftButtonUp += new MouseButtonEventHandler(Control_MouseLeftButtonUp);
            this.MouseMove += new MouseEventHandler(Control_MouseMove);
        }

        private void Control_MouseMove(object sender, MouseEventArgs e)
        {
            var draggableControl = sender as UserControl;

            if (isDragging && draggableControl != null)
            {
                Point currentPosition = e.GetPosition(this.Parent as UIElement);
                var transform = draggableControl.RenderTransform as TranslateTransform;
                if (transform == null)
                {
                    transform = new TranslateTransform();
                    draggableControl.RenderTransform = transform;
                }

                transform.X = currentPosition.X - clickPosition.X;
                transform.Y = currentPosition.Y - clickPosition.Y;
            }
        }

        private void Control_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            isDragging = false;
            var draggable = sender as UserControl;
            draggable.ReleaseMouseCapture();
        }

        private void Control_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            isDragging = true;
            var draggableControl = sender as UserControl;
            clickPosition = e.GetPosition(this);
            draggableControl.CaptureMouse();
        }
    }
}
");
                    sw2.WriteLine(
                        "<UserControl " +
                        "x:Class=\"MARINEWIZ1._0.View.UserControls.UILabel\"" +
                        "xmlns = \"http://schemas.microsoft.com/winfx/2006/xaml/presentation\" " +
                        "xmlns: x = \"http://schemas.microsoft.com/winfx/2006/xaml\"" +
                        "xmlns: mc = \"http://schemas.openxmlformats.org/markup-compatibility/2006\"" +
                        "xmlns: d = \"http://schemas.microsoft.com/expression/blend/2008\"" +
                        "mc: Ignorable = \"d\"" +
                        "Width = \"Auto\" Height = \"Auto\"" +
                        "HorizontalAlignment = \"Stretch\" VerticalAlignment = \"Stretch\">" +
                        "<Label" +
                        "Background=\"Black\"" +
                        "Name= \"" + child.Name + "\" HorizontalAlignment =  \"" + child.HorizontalAlignment + "\" VerticalAlignment \"" + child.VerticalAlignment + "\"" +
                        "Width = \"" + child.Width + "\" Height = \"" + child.Height + "\"" +
                        "Content = \"" + child.Content + "\"" +
                        ">" +
                        "</Label>" +
                        "</UserControl>");

                }
                catch (Exception err)
                {
                    MessageBox.Show(err.Message);
                }
                finally
                {
                    sw1.Close();
                    sw2.Close();
                    fs1.Close();
                    fs2.Close();
                }
            }
            else if (target.GetType().ToString().Contains("UIListView"))
            {
                FileStream fs1 = null;
                StreamWriter sw1 = null;

                FileStream fs2 = null;
                StreamWriter sw2 = null;

                try
                {
                    ListView child = target.Content as ListView;

                    fs1 = new FileStream(StaticHelper.CodePath + @"\" + child.Name + @".cs", FileMode.OpenOrCreate, FileAccess.Write);
                    sw1 = new StreamWriter(fs1, Encoding.UTF8);

                    fs2 = new FileStream(StaticHelper.XamlPath + @"\" + child.Name + @".xaml", FileMode.OpenOrCreate, FileAccess.Write);
                    sw2 = new StreamWriter(fs2, Encoding.UTF8);

                    sw1.WriteLine(@"using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace MARINEWIZ1._0.View.UserControls
{
    /// <summary>
    /// UIListView.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class UIListView : UserControl
    {
        public UIListView()
        {
            InitializeComponent();
            AddEventHandler();
        }

        protected bool isDragging;
        private Point clickPosition;

        private void AddEventHandler()
        {
            this.MouseDoubleClick += new MouseButtonEventHandler(Control_MouseLeftButtonDown);
            this.MouseLeftButtonUp += new MouseButtonEventHandler(Control_MouseLeftButtonUp);
            this.MouseMove += new MouseEventHandler(Control_MouseMove);
        }

        private void Control_MouseMove(object sender, MouseEventArgs e)
        {
            var draggableControl = sender as UserControl;

            if (isDragging && draggableControl != null)
            {
                Point currentPosition = e.GetPosition(this.Parent as UIElement);
                var transform = draggableControl.RenderTransform as TranslateTransform;
                if (transform == null)
                {
                    transform = new TranslateTransform();
                    draggableControl.RenderTransform = transform;
                }

                transform.X = currentPosition.X - clickPosition.X;
                transform.Y = currentPosition.Y - clickPosition.Y;
            }
        }

        private void Control_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            isDragging = false;
            var draggable = sender as UserControl;
            draggable.ReleaseMouseCapture();
        }

        private void Control_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            isDragging = true;
            var draggableControl = sender as UserControl;
            clickPosition = e.GetPosition(this);
            draggableControl.CaptureMouse();
        }
    }
}
");
                    sw2.WriteLine(
        "<UserControl " +
        "x:Class=\"MARINEWIZ1._0.View.UserControls.UIListView\"" +
        "xmlns = \"http://schemas.microsoft.com/winfx/2006/xaml/presentation\" " +
        "xmlns: x = \"http://schemas.microsoft.com/winfx/2006/xaml\"" +
        "xmlns: mc = \"http://schemas.openxmlformats.org/markup-compatibility/2006\"" +
        "xmlns: d = \"http://schemas.microsoft.com/expression/blend/2008\"" +
        "mc: Ignorable = \"d\"" +
        "Width = \"Auto\" Height = \"Auto\"" +
        "HorizontalAlignment = \"Stretch\" VerticalAlignment = \"Stretch\">" +
        "<ListView" +
        "Background=\"Gray\"" +
        "Name= \"" + child.Name + "\" HorizontalAlignment =  \"" + child.HorizontalAlignment + "\" VerticalAlignment \"" + child.VerticalAlignment + "\"" +
        "Width = \"" + child.Width + "\" Height = \"" + child.Height + "\"" +
        ">" +
        "</ListView>" +
        "</UserControl>");


                }
                catch (Exception err)
                {
                    MessageBox.Show(err.Message);
                }
                finally
                {
                    sw1.Close();
                    sw2.Close();
                    fs1.Close();
                    fs2.Close();
                }
            }
            else if (target.GetType().ToString().Contains("UIRadioButton"))
            {
                FileStream fs1 = null;
                StreamWriter sw1 = null;

                FileStream fs2 = null;
                StreamWriter sw2 = null;

                try
                {
                    RadioButton child = target.Content as RadioButton;

                    fs1 = new FileStream(StaticHelper.CodePath + @"\" + child.Name + @".cs", FileMode.OpenOrCreate, FileAccess.Write);
                    sw1 = new StreamWriter(fs1, Encoding.UTF8);

                    fs2 = new FileStream(StaticHelper.XamlPath + @"\" + child.Name + @".xaml", FileMode.OpenOrCreate, FileAccess.Write);
                    sw2 = new StreamWriter(fs2, Encoding.UTF8);


                    sw1.WriteLine(@"using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace MARINEWIZ1._0.View.UserControls
{
    /// <summary>
    /// UIRadioButton.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class UIRadioButton : UserControl
    {
        public UIRadioButton()
        {
            InitializeComponent();
            AddEventHandler();
        }

        protected bool isDragging;
        private Point clickPosition;

        private void AddEventHandler()
        {
            this.MouseDoubleClick += new MouseButtonEventHandler(Control_MouseLeftButtonDown);
            this.MouseLeftButtonUp += new MouseButtonEventHandler(Control_MouseLeftButtonUp);
            this.MouseMove += new MouseEventHandler(Control_MouseMove);
        }

        private void Control_MouseMove(object sender, MouseEventArgs e)
        {
            var draggableControl = sender as UserControl;

            if (isDragging && draggableControl != null)
            {
                Point currentPosition = e.GetPosition(this.Parent as UIElement);
                var transform = draggableControl.RenderTransform as TranslateTransform;
                if (transform == null)
                {
                    transform = new TranslateTransform();
                    draggableControl.RenderTransform = transform;
                }

                transform.X = currentPosition.X - clickPosition.X;
                transform.Y = currentPosition.Y - clickPosition.Y;
            }
        }

        private void Control_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            isDragging = false;
            var draggable = sender as UserControl;
            draggable.ReleaseMouseCapture();
        }

        private void Control_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            isDragging = true;
            var draggableControl = sender as UserControl;
            clickPosition = e.GetPosition(this);
            draggableControl.CaptureMouse();
        }
    }
}
");

                    sw2.WriteLine(
        "<UserControl " +
        "x:Class=\"MARINEWIZ1._0.View.UserControls.UIRadioButton\"" +
        "xmlns = \"http://schemas.microsoft.com/winfx/2006/xaml/presentation\" " +
        "xmlns: x = \"http://schemas.microsoft.com/winfx/2006/xaml\"" +
        "xmlns: mc = \"http://schemas.openxmlformats.org/markup-compatibility/2006\"" +
        "xmlns: d = \"http://schemas.microsoft.com/expression/blend/2008\"" +
        "mc: Ignorable = \"d\"" +
        "Width = \"Auto\" Height = \"Auto\"" +
        "HorizontalAlignment = \"Stretch\" VerticalAlignment = \"Stretch\">" +
        "<RadioButton" +
        "Name= \"" + child.Name + "\" HorizontalAlignment =  \"" + child.HorizontalAlignment + "\" VerticalAlignment \"" + child.VerticalAlignment + "\"" +
        "Width = \"" + child.Width + "\" Height = \"" + child.Height + "\"" +
        "Content=\"" + child.Content + "\"" +
        ">" +
        "</RadioButton>" +
        "</UserControl>");

                }
                catch (Exception err)
                {
                    MessageBox.Show(err.Message);
                }
                finally
                {
                    sw1.Close();
                    sw2.Close();
                    fs1.Close();
                    fs2.Close();
                }
            }
            else if (target.GetType().ToString().Contains("UIStackPanel"))
            {
                FileStream fs1 = null;
                StreamWriter sw1 = null;

                FileStream fs2 = null;
                StreamWriter sw2 = null;

                try
                {
                    StackPanel child = target.Content as StackPanel;

                    fs1 = new FileStream(StaticHelper.CodePath + @"\" + child.Name + @".cs", FileMode.OpenOrCreate, FileAccess.Write);
                    sw1 = new StreamWriter(fs1, Encoding.UTF8);

                    fs2 = new FileStream(StaticHelper.XamlPath + @"\" + child.Name + @".xaml", FileMode.OpenOrCreate, FileAccess.Write);
                    sw2 = new StreamWriter(fs2, Encoding.UTF8);

                    sw1.WriteLine(@"using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace MARINEWIZ1._0.View.UserControls
{
    /// <summary>
    /// UIStackPanel.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class UIStackPanel : UserControl
    {
        public UIStackPanel()
        {
            InitializeComponent();
            AddEventHandler();
        }

        protected bool isDragging;
        private Point clickPosition;

        private void AddEventHandler()
        {
            this.MouseDoubleClick += new MouseButtonEventHandler(Control_MouseLeftButtonDown);
            this.MouseLeftButtonUp += new MouseButtonEventHandler(Control_MouseLeftButtonUp);
            this.MouseMove += new MouseEventHandler(Control_MouseMove);
        }

        private void Control_MouseMove(object sender, MouseEventArgs e)
        {
            var draggableControl = sender as UserControl;

            if (isDragging && draggableControl != null)
            {
                Point currentPosition = e.GetPosition(this.Parent as UIElement);
                var transform = draggableControl.RenderTransform as TranslateTransform;
                if (transform == null)
                {
                    transform = new TranslateTransform();
                    draggableControl.RenderTransform = transform;
                }

                transform.X = currentPosition.X - clickPosition.X;
                transform.Y = currentPosition.Y - clickPosition.Y;
            }
        }

        private void Control_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            isDragging = false;
            var draggable = sender as UserControl;
            draggable.ReleaseMouseCapture();
        }

        private void Control_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            isDragging = true;
            var draggableControl = sender as UserControl;
            clickPosition = e.GetPosition(this);
            draggableControl.CaptureMouse();
        }
    }
}
");

                    sw2.WriteLine(
                        " < UserControl " +
        "x:Class=\"MARINEWIZ1._0.View.UserControls.UIStackPanel\"" +
        "xmlns = \"http://schemas.microsoft.com/winfx/2006/xaml/presentation\" " +
        "xmlns: x = \"http://schemas.microsoft.com/winfx/2006/xaml\"" +
        "xmlns: mc = \"http://schemas.openxmlformats.org/markup-compatibility/2006\"" +
        "xmlns: d = \"http://schemas.microsoft.com/expression/blend/2008\"" +
        "mc: Ignorable = \"d\"" +
        "Width = \"Auto\" Height = \"Auto\"" +
        "HorizontalAlignment = \"Stretch\" VerticalAlignment = \"Stretch\">" +
        "<StackPanel" +
        "Name= \"" + child.Name + "\" HorizontalAlignment =  \"" + child.HorizontalAlignment + "\" VerticalAlignment \"" + child.VerticalAlignment + "\"" +
        "Width = \"" + child.Width + "\" Height = \"" + child.Height + "\"" +
        ">" +
        "</StackPanel>" +
        "</UserControl>");

                }
                catch (Exception err)
                {
                    MessageBox.Show(err.Message);
                }
                finally
                {
                    sw1.Close();
                    sw2.Close();
                    fs1.Close();
                    fs2.Close();
                }
            }
            else if (target.GetType().ToString().Contains("UITabControl"))
            {
                FileStream fs1 = null;
                StreamWriter sw1 = null;

                FileStream fs2 = null;
                StreamWriter sw2 = null;

                try
                {
                    TabControl child = target.Content as TabControl;

                    fs1 = new FileStream(StaticHelper.CodePath + @"\" + child.Name + @".cs", FileMode.OpenOrCreate, FileAccess.Write);
                    sw1 = new StreamWriter(fs1, Encoding.UTF8);

                    fs2 = new FileStream(StaticHelper.XamlPath + @"\" + child.Name + @".xaml", FileMode.OpenOrCreate, FileAccess.Write);
                    sw2 = new StreamWriter(fs2, Encoding.UTF8);

                    sw1.WriteLine(@"using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace MARINEWIZ1._0.View.UserControls
{
    /// <summary>
    /// UITabControl.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class UITabControl : UserControl
    {
        public UITabControl()
        {
            InitializeComponent();
            AddEventHandler();
        }

        protected bool isDragging;
        private Point clickPosition;

        private void AddEventHandler()
        {
            this.MouseDoubleClick += new MouseButtonEventHandler(Control_MouseLeftButtonDown);
            this.MouseLeftButtonUp += new MouseButtonEventHandler(Control_MouseLeftButtonUp);
            this.MouseMove += new MouseEventHandler(Control_MouseMove);
        }

        private void Control_MouseMove(object sender, MouseEventArgs e)
        {
            var draggableControl = sender as UserControl;

            if (isDragging && draggableControl != null)
            {
                Point currentPosition = e.GetPosition(this.Parent as UIElement);
                var transform = draggableControl.RenderTransform as TranslateTransform;
                if (transform == null)
                {
                    transform = new TranslateTransform();
                    draggableControl.RenderTransform = transform;
                }

                transform.X = currentPosition.X - clickPosition.X;
                transform.Y = currentPosition.Y - clickPosition.Y;
            }
        }

        private void Control_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            isDragging = false;
            var draggable = sender as UserControl;
            draggable.ReleaseMouseCapture();
        }

        private void Control_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            isDragging = true;
            var draggableControl = sender as UserControl;
            clickPosition = e.GetPosition(this);
            draggableControl.CaptureMouse();
        }
    }
}
");
                    sw2.WriteLine(" < UserControl " +
        "x:Class=\"MARINEWIZ1._0.View.UserControls.UITabControl\"" +
        "xmlns = \"http://schemas.microsoft.com/winfx/2006/xaml/presentation\" " +
        "xmlns: x = \"http://schemas.microsoft.com/winfx/2006/xaml\"" +
        "xmlns: mc = \"http://schemas.openxmlformats.org/markup-compatibility/2006\"" +
        "xmlns: d = \"http://schemas.microsoft.com/expression/blend/2008\"" +
        "mc: Ignorable = \"d\"" +
        "Width = \"Auto\" Height = \"Auto\"" +
        "HorizontalAlignment = \"Stretch\" VerticalAlignment = \"Stretch\">" +
        "<TabControl" +
        "Name= \"" + child.Name + "\" HorizontalAlignment =  \"" + child.HorizontalAlignment + "\" VerticalAlignment \"" + child.VerticalAlignment + "\"" +
        "Width = \"" + child.Width + "\" Height = \"" + child.Height + "\"" +
        ">" +
        "</TabControl>" +
        "</UserControl>");

                }
                catch (Exception err)
                {
                    MessageBox.Show(err.Message);
                }
                finally
                {
                    sw1.Close();
                    sw2.Close();
                    fs1.Close();
                    fs2.Close();
                }
            }
            else if (target.GetType().ToString().Contains("UITextBlock"))
            {
                FileStream fs1 = null;
                StreamWriter sw1 = null;

                FileStream fs2 = null;
                StreamWriter sw2 = null;

                try
                {
                    TextBlock child = target.Content as TextBlock;

                    fs1 = new FileStream(StaticHelper.CodePath + @"\" + child.Name + @".cs", FileMode.OpenOrCreate, FileAccess.Write);
                    sw1 = new StreamWriter(fs1, Encoding.UTF8);

                    fs2 = new FileStream(StaticHelper.XamlPath + @"\" + child.Name + @".xaml", FileMode.OpenOrCreate, FileAccess.Write);
                    sw2 = new StreamWriter(fs2, Encoding.UTF8);


                    sw1.WriteLine(@"using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace MARINEWIZ1._0.View.UserControls
{
    /// <summary>
    /// UITextBlock.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class UITextBlock : UserControl
    {
        public UITextBlock()
        {
            InitializeComponent();
            AddEventHandler();
        }

        protected bool isDragging;
        private Point clickPosition;

        private void AddEventHandler()
        {
            this.MouseDoubleClick += new MouseButtonEventHandler(Control_MouseLeftButtonDown);
            this.MouseLeftButtonUp += new MouseButtonEventHandler(Control_MouseLeftButtonUp);
            this.MouseMove += new MouseEventHandler(Control_MouseMove);
        }

        private void Control_MouseMove(object sender, MouseEventArgs e)
        {
            var draggableControl = sender as UserControl;

            if (isDragging && draggableControl != null)
            {
                Point currentPosition = e.GetPosition(this.Parent as UIElement);
                var transform = draggableControl.RenderTransform as TranslateTransform;
                if (transform == null)
                {
                    transform = new TranslateTransform();
                    draggableControl.RenderTransform = transform;
                }

                transform.X = currentPosition.X - clickPosition.X;
                transform.Y = currentPosition.Y - clickPosition.Y;
            }
        }

        private void Control_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            isDragging = false;
            var draggable = sender as UserControl;
            draggable.ReleaseMouseCapture();
        }

        private void Control_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            isDragging = true;
            var draggableControl = sender as UserControl;
            clickPosition = e.GetPosition(this);
            draggableControl.CaptureMouse();
        }
    }
}
");
                    sw2.WriteLine(" < UserControl " +
        "x:Class=\"MARINEWIZ1._0.View.UserControls.UITextBlock\"" +
        "xmlns = \"http://schemas.microsoft.com/winfx/2006/xaml/presentation\" " +
        "xmlns: x = \"http://schemas.microsoft.com/winfx/2006/xaml\"" +
        "xmlns: mc = \"http://schemas.openxmlformats.org/markup-compatibility/2006\"" +
        "xmlns: d = \"http://schemas.microsoft.com/expression/blend/2008\"" +
        "mc: Ignorable = \"d\"" +
        "Width = \"Auto\" Height = \"Auto\"" +
        "HorizontalAlignment = \"Stretch\" VerticalAlignment = \"Stretch\">" +
        "<TextBlock" +
        "Name= \"" + child.Name + "\" HorizontalAlignment =  \"" + child.HorizontalAlignment + "\" VerticalAlignment \"" + child.VerticalAlignment + "\"" +
        "Width = \"" + child.Width + "\" Height = \"" + child.Height + "\"" +
        ">" +
        "</TextBlock>" +
        "</UserControl>");

                }
                catch (Exception err)
                {
                    MessageBox.Show(err.Message);
                }
                finally
                {
                    sw1.Close();
                    sw2.Close();
                    fs1.Close();
                    fs2.Close();
                }
            }
            else if (target.GetType().ToString().Contains("UITextBox"))
            {
                FileStream fs1 = null;
                StreamWriter sw1 = null;

                FileStream fs2 = null;
                StreamWriter sw2 = null;

                try
                {
                    TextBox child = target.Content as TextBox;

                    fs1 = new FileStream(StaticHelper.CodePath + @"\" + child.Name + @".cs", FileMode.OpenOrCreate, FileAccess.Write);
                    sw1 = new StreamWriter(fs1, Encoding.UTF8);

                    fs2 = new FileStream(StaticHelper.XamlPath + @"\" + child.Name + @".xaml", FileMode.OpenOrCreate, FileAccess.Write);
                    sw2 = new StreamWriter(fs2, Encoding.UTF8);
                    
                    sw1.WriteLine(@"using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace MARINEWIZ1._0.View.UserControls
{
    /// <summary>
    /// UITextBox.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class UITextBox : UserControl
    {
        public UITextBox()
        {
            InitializeComponent();
            AddEventHandler();
        }

        protected bool isDragging;
        private Point clickPosition;

        private void AddEventHandler()
        {
            this.MouseDoubleClick += new MouseButtonEventHandler(Control_MouseLeftButtonDown);
            this.MouseLeftButtonUp += new MouseButtonEventHandler(Control_MouseLeftButtonUp);
            this.MouseMove += new MouseEventHandler(Control_MouseMove);
        }

        private void Control_MouseMove(object sender, MouseEventArgs e)
        {
            var draggableControl = sender as UserControl;

            if (isDragging && draggableControl != null)
            {
                Point currentPosition = e.GetPosition(this.Parent as UIElement);
                var transform = draggableControl.RenderTransform as TranslateTransform;
                if (transform == null)
                {
                    transform = new TranslateTransform();
                    draggableControl.RenderTransform = transform;
                }

                transform.X = currentPosition.X - clickPosition.X;
                transform.Y = currentPosition.Y - clickPosition.Y;
            }
        }

        private void Control_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            isDragging = false;
            var draggable = sender as UserControl;
            draggable.ReleaseMouseCapture();
        }

        private void Control_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            isDragging = true;
            var draggableControl = sender as UserControl;
            clickPosition = e.GetPosition(this);
            draggableControl.CaptureMouse();
        }
    }
}
");
                    sw2.WriteLine(" < UserControl " +
        "x:Class=\"MARINEWIZ1._0.View.UserControls.UITextBox\"" +
        "xmlns = \"http://schemas.microsoft.com/winfx/2006/xaml/presentation\" " +
        "xmlns: x = \"http://schemas.microsoft.com/winfx/2006/xaml\"" +
        "xmlns: mc = \"http://schemas.openxmlformats.org/markup-compatibility/2006\"" +
        "xmlns: d = \"http://schemas.microsoft.com/expression/blend/2008\"" +
        "mc: Ignorable = \"d\"" +
        "Width = \"Auto\" Height = \"Auto\"" +
        "HorizontalAlignment = \"Stretch\" VerticalAlignment = \"Stretch\">" +
        "<TextBox" +
        "Name= \"" + child.Name + "\" HorizontalAlignment =  \"" + child.HorizontalAlignment + "\" VerticalAlignment \"" + child.VerticalAlignment + "\"" +
        "Width = \"" + child.Width + "\" Height = \"" + child.Height + "\"" +
        ">" +
        "</TextBox>" +
        "</UserControl>");

                }
                catch (Exception err)
                {
                    MessageBox.Show(err.Message);
                }
                finally
                {
                    sw1.Close();
                    sw2.Close();
                    fs1.Close();
                    fs2.Close();
                }
            }
            else if (target.GetType().ToString().Contains("UITreeView"))
            {
                FileStream fs1 = null;
                StreamWriter sw1 = null;

                FileStream fs2 = null;
                StreamWriter sw2 = null;

                try
                {
                    TreeView child = target.Content as TreeView;

                    fs1 = new FileStream(StaticHelper.CodePath + @"\" + child.Name + @".cs", FileMode.OpenOrCreate, FileAccess.Write);
                    sw1 = new StreamWriter(fs1, Encoding.UTF8);

                    fs2 = new FileStream(StaticHelper.XamlPath + @"\" + child.Name + @".xaml", FileMode.OpenOrCreate, FileAccess.Write);
                    sw2 = new StreamWriter(fs2, Encoding.UTF8);

                    sw1.WriteLine(@"using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace MARINEWIZ1._0.View.UserControls
{
    /// <summary>
    /// UITreeView.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class UITreeView : UserControl
    {
        public UITreeView()
        {
            InitializeComponent();
            AddEventHandler();
        }

        protected bool isDragging;
        private Point clickPosition;

        private void AddEventHandler()
        {
            this.MouseDoubleClick += new MouseButtonEventHandler(Control_MouseLeftButtonDown);
            this.MouseLeftButtonUp += new MouseButtonEventHandler(Control_MouseLeftButtonUp);
            this.MouseMove += new MouseEventHandler(Control_MouseMove);
        }

        private void Control_MouseMove(object sender, MouseEventArgs e)
        {
            var draggableControl = sender as UserControl;

            if (isDragging && draggableControl != null)
            {
                Point currentPosition = e.GetPosition(this.Parent as UIElement);
                var transform = draggableControl.RenderTransform as TranslateTransform;
                if (transform == null)
                {
                    transform = new TranslateTransform();
                    draggableControl.RenderTransform = transform;
                }

                transform.X = currentPosition.X - clickPosition.X;
                transform.Y = currentPosition.Y - clickPosition.Y;
            }
        }

        private void Control_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            isDragging = false;
            var draggable = sender as UserControl;
            draggable.ReleaseMouseCapture();
        }

        private void Control_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            isDragging = true;
            var draggableControl = sender as UserControl;
            clickPosition = e.GetPosition(this);
            draggableControl.CaptureMouse();
        }
    }
}
");
                    sw2.WriteLine(" < UserControl " +
        "x:Class=\"MARINEWIZ1._0.View.UserControls.UITreeView\"" +
        "xmlns = \"http://schemas.microsoft.com/winfx/2006/xaml/presentation\" " +
        "xmlns: x = \"http://schemas.microsoft.com/winfx/2006/xaml\"" +
        "xmlns: mc = \"http://schemas.openxmlformats.org/markup-compatibility/2006\"" +
        "xmlns: d = \"http://schemas.microsoft.com/expression/blend/2008\"" +
        "mc: Ignorable = \"d\"" +
        "Width = \"Auto\" Height = \"Auto\"" +
        "HorizontalAlignment = \"Stretch\" VerticalAlignment = \"Stretch\">" +
        "<TreeView" +
        "Name= \"" + child.Name + "\" HorizontalAlignment =  \"" + child.HorizontalAlignment + "\" VerticalAlignment \"" + child.VerticalAlignment + "\"" +
        "Width = \"" + child.Width + "\" Height = \"" + child.Height + "\"" +
        ">" +
        "</TreeView>" +
        "</UserControl>");
                }
                catch (Exception err)
                {
                    MessageBox.Show(err.Message);
                }
                finally
                {
                    sw1.Close();
                    sw2.Close();
                    fs1.Close();
                    fs2.Close();
                }
            }
            else if (target.GetType().ToString().Contains("UIWrapPanel"))
            {
                FileStream fs1 = null;
                StreamWriter sw1 = null;

                FileStream fs2 = null;
                StreamWriter sw2 = null;

                try
                {
                    WrapPanel child = target.Content as WrapPanel;

                    fs1 = new FileStream(StaticHelper.CodePath + @"\" + child.Name + @".cs", FileMode.OpenOrCreate, FileAccess.Write);
                    sw1 = new StreamWriter(fs1, Encoding.UTF8);

                    fs2 = new FileStream(StaticHelper.XamlPath + @"\" + child.Name + @".xaml", FileMode.OpenOrCreate, FileAccess.Write);
                    sw2 = new StreamWriter(fs2, Encoding.UTF8);

                    sw1.WriteLine(@"using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace MARINEWIZ1._0.View.UserControls
{
    /// <summary>
    /// UIWrapPanel.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class UIWrapPanel : UserControl
    {
        public UIWrapPanel()
        {
            InitializeComponent();
            AddEventHandler();
        }

        protected bool isDragging;
        private Point clickPosition;

        private void AddEventHandler()
        {
            this.MouseDoubleClick += new MouseButtonEventHandler(Control_MouseLeftButtonDown);
            this.MouseLeftButtonUp += new MouseButtonEventHandler(Control_MouseLeftButtonUp);
            this.MouseMove += new MouseEventHandler(Control_MouseMove);
        }

        private void Control_MouseMove(object sender, MouseEventArgs e)
        {
            var draggableControl = sender as UserControl;

            if (isDragging && draggableControl != null)
            {
                Point currentPosition = e.GetPosition(this.Parent as UIElement);
                var transform = draggableControl.RenderTransform as TranslateTransform;
                if (transform == null)
                {
                    transform = new TranslateTransform();
                    draggableControl.RenderTransform = transform;
                }

                transform.X = currentPosition.X - clickPosition.X;
                transform.Y = currentPosition.Y - clickPosition.Y;
            }
        }

        private void Control_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            isDragging = false;
            var draggable = sender as UserControl;
            draggable.ReleaseMouseCapture();
        }

        private void Control_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            isDragging = true;
            var draggableControl = sender as UserControl;
            clickPosition = e.GetPosition(this);
            draggableControl.CaptureMouse();
        }
    }
}
");
                    sw2.WriteLine(
                        " < UserControl " +
        "x:Class=\"MARINEWIZ1._0.View.UserControls.UIWrapPanel\"" +
        "xmlns = \"http://schemas.microsoft.com/winfx/2006/xaml/presentation\" " +
        "xmlns: x = \"http://schemas.microsoft.com/winfx/2006/xaml\"" +
        "xmlns: mc = \"http://schemas.openxmlformats.org/markup-compatibility/2006\"" +
        "xmlns: d = \"http://schemas.microsoft.com/expression/blend/2008\"" +
        "mc: Ignorable = \"d\"" +
        "Width = \"Auto\" Height = \"Auto\"" +
        "HorizontalAlignment = \"Stretch\" VerticalAlignment = \"Stretch\">" +
        "<WrapPanel" +
        "Name= \"" + child.Name + "\" HorizontalAlignment =  \"" + child.HorizontalAlignment + "\" VerticalAlignment \"" + child.VerticalAlignment + "\"" +
        "Width = \"" + child.Width + "\" Height = \"" + child.Height + "\"" +
        ">" +
        "</WrapPanel>" +
        "</UserControl>");

                }
                catch (Exception err)
                {
                    MessageBox.Show(err.Message);
                }
                finally
                {
                    sw1.Close();
                    sw2.Close();
                    fs1.Close();
                    fs2.Close();
                }
                return;
            }
        }
    }
}
