﻿using System.Collections.Generic;
using System.Windows;
using System.Windows.Media;

namespace MARINEWIZ1._0.Helper
{
    /// <summary>
    /// UIHelper :: 부모 Object를 설정하고 하단의 Child Object의 이름을 검색하여 가져올 수 있음.
    /// 임시방편으로 만든 Class로써 정리하고 화면 내에서 클릭이나 의존관계를 이용하여 변수를 찾을 수 있게끔 재 설계 필요.
    /// </summary>
    public static class UIHelper
    {
        public static T FindChild<T>(DependencyObject parent, string childName)
   where T : DependencyObject
        {
            // Confirm parent and childName are valid. 
            if (parent == null) return null;

            T foundChild = null;

            int childrenCount = VisualTreeHelper.GetChildrenCount(parent);
            for (int i = 0; i < childrenCount; i++)
            {
                var child = VisualTreeHelper.GetChild(parent, i);
                // If the child is not of the request child type child
                T childType = child as T;
                if (childType == null)
                {
                    // recursively drill down the tree
                    foundChild = FindChild<T>(child, childName);

                    // If the child is found, break so we do not overwrite the found child. 
                    if (foundChild != null) break;
                }
                else if (!string.IsNullOrEmpty(childName))
                {
                    var frameworkElement = child as FrameworkElement;
                    // If the child's name is set for search
                    if (frameworkElement != null && frameworkElement.Name == childName)
                    {
                        // if the child's name is of the request name
                        foundChild = (T)child;
                        break;
                    }
                }
                else
                {
                    // child element found.
                    foundChild = (T)child;
                    break;
                }
            }

            return foundChild;
        }


        public static T FindControlWithTag<T>(this DependencyObject parent, string tag) where T : UIElement
        {
            List<UIElement> elements = new List<UIElement>();

            int count = VisualTreeHelper.GetChildrenCount(parent);
            if (count > 0)
            {
                for (int i = 0; i < count; i++)
                {
                    DependencyObject child = VisualTreeHelper.GetChild(parent, i);
                    if (typeof(FrameworkElement).IsAssignableFrom(child.GetType())
                        && ((string)((FrameworkElement)child).Tag == tag))
                    {
                        return child as T;
                    }
                    var item = FindControlWithTag<T>(child, tag);
                    if (item != null) return item as T;
                }
            }
            return null;
        }

    }
}
