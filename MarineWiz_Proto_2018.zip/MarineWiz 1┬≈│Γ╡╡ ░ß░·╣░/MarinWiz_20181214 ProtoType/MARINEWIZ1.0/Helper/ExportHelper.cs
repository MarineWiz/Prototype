﻿using MahApps.Metro.Controls;
using MARINEWIZ1._0.View.ExternalControls;
using MARINEWIZ1._0.View.UserControls;
using MARINEWIZ1._0.View.Windows;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace MARINEWIZ1._0.Helper
{
    class ExportHelper
    {
        FileStream fs;
        StreamWriter sw;

        public ExportHelper()
        {

        }


        public void MakeXAMLByType()
        {
            fs = null;
            sw = null;

            string path = Path.Combine(StaticHelper.ProjectPath, StaticHelper.Projectname, StaticHelper.Projectname + ".xaml");

            try
            {
                fs = new FileStream(path, FileMode.OpenOrCreate);
                sw = new StreamWriter(fs, Encoding.UTF8);

                StartWindow mainwindow = Application.Current.MainWindow as StartWindow;
                Canvas canvas = mainwindow.maincanvas;


                sw.WriteLine("" +
                    "<control:MetroWindow" +
                    "\n    xmlns = \"http://schemas.microsoft.com/winfx/2006/xaml/presentation\"" +
                    "\n    xmlns:x = \"http://schemas.microsoft.com/winfx/2006/xaml\"" +
                    "\n    xmlns:d = \"http://schemas.microsoft.com/expression/blend/2008\"" +
                    "\n    xmlns:mc = \"http://schemas.openxmlformats.org/markup-compatibility/2006\"" +
                    "\n    xmlns:control = \"http://metro.mahapps.com/winfx/xaml/controls\" " +
                    "\n    xmlns:system = \"clr-namespace:System;assembly=mscorlib\"" +
                    "\n    xmlns:external =\"clr-namespace:MARINEWIZ1._0.View.ExternalControls\"" +
                    "\n    xmlns:uc=\"clr-namespace:MARINEWIZ1._0.View.UserControls\"" +
                    "\n    x:Class = \"MARINEWIZ1._0.MainWindow\"" +
                    "\n    mc:Ignorable = \"d\"" +
                    "\n    Title = \"Builder 전용 - MarineWiz\"" +
                    "\n    Height = \"800\" Width = \"1000\"" +
                    "\n    WindowStartupLocation = \"CenterOwner\"" +
                    ">" +
                    "<ScrollViewer HorizontalScrollBarVisibility=\"Auto\" VerticalScrollBarVisibility=\"Auto\" >" +

                    "<Canvas Width=\"1920\" Height=\"1080\" Name = \"maincanvas\"" + " AllowDrop = \"True\"" + " " + ">");
                sw.WriteLine();

                foreach (UserControl uc in canvas.Children)
                {
                    if (uc.GetType().ToString().Contains("ChartImage"))
                    {
                        ChartImage obj = uc as ChartImage;

                        if (uc.Name.Contains("gaugechart"))
                        {                            
                            sw.WriteLine("<external:ExtGaugeChart Tag=\""+ obj.Tag +"\" Canvas.Left=\""+ obj.OffsetX +"\" Canvas.Top=\""+ obj.OffsetY + "\"  Width=\"" + obj.Width + "\" Height=\"" + obj.Height + "\" />");
                        }
                        else if (uc.Name.Contains("treeview"))
                        {
                            sw.WriteLine("<uc:UITreeView Tag=\""+ obj.Tag + "\" Canvas.Left=\"" + obj.OffsetX + "\" Canvas.Top=\"" + obj.OffsetY + "\" />");
                        }
                        else if (uc.Name.Contains("piechart"))
                        {
                            sw.WriteLine("<external:ExtPieChart Tag=\"" + obj.Tag +"\" Canvas.Left=\""+ obj.OffsetX + "\" Canvas.Top=\""+ obj.OffsetY +"\"  Width=\""+ obj.Width +"\" Height=\""+ obj.Height + "\" />");
                        }
                        else if (uc.Name.Contains("barchart"))
                        {
                            sw.WriteLine("<external:ExtBarChart Tag=\"" + obj.Tag + "\" Canvas.Left=\"" + obj.OffsetX + "\" Canvas.Top=\"" + obj.OffsetY + "\"  Width=\"" + obj.Width + "\" Height=\"" + obj.Height + "\" />");
                        }
                        else if (uc.Name.Contains("doughnutchart"))
                        {
                            sw.WriteLine("<external:ExtDoughnutChart Tag=\"" + obj.Tag + "\" Canvas.Left=\"" + obj.OffsetX + "\" Canvas.Top=\"" + obj.OffsetY + "\"  Width=\"" + obj.Width + "\" Height=\"" + obj.Height + "\" />");
                        }
                    }
                    else if (uc.GetType().ToString().Contains("UIButton"))
                    {
                        UIButton uiBtn = uc as UIButton;
                        Button Btn = uc.Content as Button;

                        sw.WriteLine("<uc:UIButton Tag=\"" + uiBtn.Tag + "\" Content=\"" + Btn.Content + "\" Canvas.Left=\""+ uiBtn.OffsetX  + "\" Canvas.Top=\""+ uiBtn.OffsetY +"\" Width=\""+ Btn.Width + "\" Height=\"" + Btn.Height + "\" />");
                    }
                    else if (uc.GetType().ToString().Contains("UICheckBox"))
                    {
                        UICheckBox uiCheck = uc as UICheckBox;
                        CheckBox Check = uc.Content as CheckBox;

                        sw.WriteLine("<uc:UICheckBox Tag=\"" + uiCheck.Tag +"\" Content=\"" + Check.Content +"\" Canvas.Left=\""+ uiCheck.OffsetX +"\" Canvas.Top=\"" + uiCheck.OffsetY +"\" Width=\"" + Check.Width +"\" Height=\""+ Check.Height + "\" />");
                    }
                    else if (uc.GetType().ToString().Contains("UIComboBox"))
                    {
                        UIComboBox uiCmb = uc as UIComboBox;
                        ComboBox Cmb = uc.Content as ComboBox;

                        sw.WriteLine("<uc:UIComboBox Tag=\"" + uiCmb.Tag + "\" Canvas.Left=\"" + uiCmb.OffsetX + "\" Canvas.Top=\"" + uiCmb.OffsetY + "\" Width=\"" + Cmb.Width + "\" Height=\"" + Cmb.Height + "\" />");
                    }
                    else if (uc.GetType().ToString().Contains("UIDockPanel"))
                    {
                        UIDockPanel uiDock = uc as UIDockPanel;
                        DockPanel Dock = uc.Content as DockPanel;

                        sw.WriteLine("<uc:UIDockPanel Tag=\"" + uiDock.Tag + "\" Canvas.Left=\"" + uiDock.OffsetX + "\" Canvas.Top=\"" + uiDock.OffsetY + "\" Width=\"" + Dock.Width + "\" Height=\"" + Dock.Height + "\" />");
                    }
                    else if (uc.GetType().ToString().Contains("UIGridView"))
                    {
                        UIGridView uiGrid = uc as UIGridView;
                        Grid grid = uc.Content as Grid;

                        sw.WriteLine("<uc:UIGridView x:Name=\"" + uiGrid.Name + "\"  Tag=\"" + uiGrid.Tag + "\" Canvas.Left=\"" + uiGrid.OffsetX + "\" Canvas.Top=\"" + uiGrid.OffsetY + "\" Width=\"" + grid.Width + "\" Height=\"" + grid.Height + "\" />");
                    }
                    else if (uc.GetType().ToString().Contains("UIImage"))
                    {
                        UIImage uiImg = uc as UIImage;
                        Image Img = uc.Content as Image;

                        sw.WriteLine("<uc:UIImage x:Name=\"" + uiImg.Name + "\"  Tag=\"" + Img.Source + "\" Canvas.Left=\"" + uiImg.OffsetX + "\" Canvas.Top=\"" + uiImg.OffsetY + "\" Width=\"" + Img.Width + "\" Height=\"" + Img.Height + "\" />");
                    }
                    else if (uc.GetType().ToString().Contains("UILabel"))
                    {
                        UILabel uiLbl = uc as UILabel;
                        Label Lbl = uc.Content as Label;

                        sw.WriteLine("<uc:UILabel x:Name=\"" + uiLbl.Name + "\"  Tag=\"" + uiLbl.Tag + "\" Content=\"" + Lbl.Content + "\" Canvas.Left=\"" + uiLbl.OffsetX + "\" Canvas.Top=\"" + uiLbl.OffsetY + "\" Width=\"" + Lbl.Width + "\" Height=\"" + Lbl.Height + "\" />");
                    }
                    else if (uc.GetType().ToString().Contains("UIListView"))
                    {
                        UIListView uiLv = uc as UIListView;
                        ListView Lv = uc.Content as ListView;

                        sw.WriteLine("<uc:UIListView x:Name=\"" + uiLv.Name + "\"  Tag=\"" + uiLv.Tag + "\" Canvas.Left=\"" + uiLv.OffsetX + "\" Canvas.Top=\"" + uiLv.OffsetY + "\" Width=\"" + Lv.Width + "\" Height=\"" + Lv.Height + "\" />");
                    }
                    else if (uc.GetType().ToString().Contains("UIRadioButton"))
                    {
                        UIRadioButton uiRadio = uc as UIRadioButton;
                        RadioButton radio = uc.Content as RadioButton;

                        sw.WriteLine("<uc:UIListView x:Name=\"" + uiRadio.Name + "\"  Tag=\"" + uiRadio.Tag + "\" Content=\"" + radio.Content + "\" Canvas.Left=\"" + uiRadio.OffsetX + "\" Canvas.Top=\"" + uiRadio.OffsetY + "\" Width=\"" + radio.Width + "\" Height=\"" + radio.Height + "\" />");
                    }
                    else if (uc.GetType().ToString().Contains("UIStackPanel"))
                    {
                        UIStackPanel uiStk = uc as UIStackPanel;
                        StackPanel Stk = uc.Content as StackPanel;

                        sw.WriteLine("<uc:UIStackPanel x:Name=\"" + uiStk.Name + "\"  Tag=\"" + uiStk.Tag + "\" Canvas.Left=\"" + uiStk.OffsetX + "\" Canvas.Top=\"" + uiStk.OffsetY + "\" Width=\"" + Stk.Width + "\" Height=\"" + Stk.Height + "\" />");
                    }
                    else if (uc.GetType().ToString().Contains("UITabControl"))
                    {
                        UITabControl uiTab = uc as UITabControl;
                        TabControl Tab = uc.Content as TabControl;

                        sw.WriteLine("<uc:UITabControl x:Name=\"" + uiTab.Name + "\"  Tag=\"" + uiTab.Tag + "\" Canvas.Left=\"" + uiTab.OffsetX + "\" Canvas.Top=\"" + uiTab.OffsetY + "\" Width=\"" + Tab.Width + "\" Height=\"" + Tab.Height + "\" />");
                    }
                    else if (uc.GetType().ToString().Contains("UITextBlock"))
                    {
                        UITextBlock uiTbk = uc as UITextBlock;
                        TextBlock Tbk = uc.Content as TextBlock;

                        sw.WriteLine("<uc:UITextBlock x:Name=\"" + uiTbk.Name + "\" Foreground=\"" + Tbk.Foreground  +"\"  Tag=\"" + Tbk.Text + "\" Canvas.Left=\"" + uiTbk.OffsetX + "\" Canvas.Top=\"" + uiTbk.OffsetY + "\" Width=\"" + Tbk.Width + "\" Height=\"" + Tbk.Height + "\" />");
                    }
                    else if (uc.GetType().ToString().Contains("UITextBox"))
                    {
                        UITextBox uiTbx = uc as UITextBox;
                        TextBox Tbx = uc.Content as TextBox;

                        sw.WriteLine("<uc:UITextBlock x:Name=\"" + uiTbx.Name + "\"  Tag=\"" + uiTbx.Tag + "\" Canvas.Left=\"" + uiTbx.OffsetX + "\" Canvas.Top=\"" + uiTbx.OffsetY + "\" Width=\"" + Tbx.Width + "\" Height=\"" + Tbx.Height + "\" />");
                    }
                    else if (uc.GetType().ToString().Contains("UITreeView"))
                    {
                        UITreeView uiTv = uc as UITreeView;
                        TreeView Tv = uc.Content as TreeView;

                        sw.WriteLine("<uc:UITreeView x:Name=\"" + uiTv.Name + "\" Tag=\"" + uiTv.Tag + "\" Canvas.Left=\"" + uiTv.OffsetX + "\" Canvas.Top=\"" + uiTv.OffsetY + "\" Width=\"" + Tv.Width + "\" Height=\"" + Tv.Height + "\" />");
                    }
                    else if (uc.GetType().ToString().Contains("UIWrapPanel"))
                    {
                        //sw.WriteLine("<uc:UIWrapPanel Tag=\"" + strPath + "\"" + "\" Canvas.Left=\"" + dCanvasLeft + "\" Canvas.Top=\"" + dCanvasTop + "\" Width=\"" + nWidth + "\" Height=\"" + nHeight + "\" />");
                    }
                    else if (uc.GetType().ToString().Contains("TemplateShipStateMonitoring"))
                    {
                        //sw.WriteLine("<uc:TemplateShipStateMonitoring Tag=\"" + strPath + "\"" + " Content=\"" + strContent + "\" Canvas.Left=\"" + dCanvasLeft + "\" Canvas.Top=\"" + dCanvasTop + "\" Width=\"" + nWidth + "\" Height=\"" + nHeight + "\" />");
                    }
                    else
                    {
                        
                    }
                }
            }
            catch (Exception err)
            {
                MessageBox.Show("Exception Message :: " + err.Message);
                MessageBox.Show("Exception StackTrace :: " + err.StackTrace);
                MessageBox.Show("Exception InnerException :: " + err.InnerException);
            }
            finally
            {
                sw.WriteLine();
                sw.WriteLine("</Canvas>");
                sw.WriteLine("</ScrollViewer> " +
                    "</control:MetroWindow > ");

                sw.Close();
                fs.Close();                
            }

            return;
        }


        public void MakeTempXAML(string strTreePath, double nTreeLeft, double nTreeTop, string strChartPath, double nChartLeft, double nChartTop)
        {
            FileStream tempfs = null;
            StreamWriter tempsw = null;

            try
            {
                tempfs = new FileStream(StaticHelper.ProjectPath + @"\" + StaticHelper.Projectname + @"\Export.xaml", FileMode.OpenOrCreate);
                tempsw = new StreamWriter(tempfs, Encoding.UTF8);

                tempsw.WriteLine("" +
                    "<control:MetroWindow" +
                    "\n    xmlns = \"http://schemas.microsoft.com/winfx/2006/xaml/presentation\"" +
                    "\n    xmlns:x = \"http://schemas.microsoft.com/winfx/2006/xaml\"" +
                    "\n    xmlns:d = \"http://schemas.microsoft.com/expression/blend/2008\"" +
                    "\n    xmlns:mc = \"http://schemas.openxmlformats.org/markup-compatibility/2006\"" +
                    "\n    xmlns:control = \"http://metro.mahapps.com/winfx/xaml/controls\" " +
                    "\n    xmlns:system = \"clr-namespace:System;assembly=mscorlib\"" +
                    "\n    xmlns:external =\"clr-namespace:MARINEWIZ1._0.View.ExternalControls\"" +
                    "\n    xmlns:uc=\"clr-namespace:MARINEWIZ1._0.View.UserControls\"" +
                    "\n    x:Class = \"MARINEWIZ1._0.MainWindow\"" +
                    "\n    mc:Ignorable = \"d\"" +
                    "\n    Title = \"Builder 전용 - MarineWiz\"" +
                    "\n    Height = \"800\" Width = \"1000\"" +
                    "\n    WindowStartupLocation = \"CenterOwner\"" +
                    ">" +

                    "<Canvas Name = \"maincanvas\"" +  " AllowDrop = \"True\"" + " " + ">" +
                    "\n <external:ExtGaugeChart Tag= \"" + strChartPath + "\" Canvas.Left=\"" + nChartLeft + "\" Canvas.Top=\"" + nChartTop + "\"/>" +
                    "\n <uc:UITreeView Width=\"250\" Height=\"500\" Tag= \"" + strTreePath + "\" Canvas.Left=\"" + nTreeLeft + "\" Canvas.Top=\"" + nTreeTop + "\"/>" +
                    "</Canvas >" +
                    "</control:MetroWindow > ");
            }
            catch (Exception err)
            {
                MessageBox.Show("InnerException :: " + err.InnerException);
                MessageBox.Show("StackTrace :: " + err.StackTrace);
                MessageBox.Show("ErrorMessage :: " + err.Message);

                tempsw.Close();
                tempfs.Close();
            }
            finally
            {
                tempsw.Close();
                tempfs.Close();
            }
            
        }


    }
}
