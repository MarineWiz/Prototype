﻿using MahApps.Metro.Controls;
using MARINEWIZ1._0.Helper;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Imaging;

namespace MARINEWIZ1._0.View.Windows
{
    /// <summary>
    /// DataFileSelectWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class DataFileSelectWindow : MetroWindow
    {
        /// <summary>
        /// File Data(.xml) Select Window
        /// </summary>
        public DataFileSelectWindow()
        {
            InitializeComponent();
            SetList();
        }

        private void SetList()
        {
            try
            {
                // 현재 점거중인 MainWindow 교체
                StartWindow mainwindow = Application.Current.MainWindow as StartWindow;
                TreeView tv = mainwindow.datatreeview;

                TreeViewItem rootItem = tv.Items.GetItemAt(0) as TreeViewItem;
                // Tree view root item
                TreeViewItem SubItem = rootItem.Items.GetItemAt(1) as TreeViewItem;
                // Tree view File Data sub item (x:Name="filedata")

                TreeViewItem[] items = new TreeViewItem[SubItem.Items.Count];

                for (int i = 0; i < SubItem.Items.Count; ++i)
                {
                    items[i] = SubItem.Items.GetItemAt(i) as TreeViewItem;
                }

                for (int i = 0; i < SubItem.Items.Count; ++i)
                {
                    WrapPanel wpnl = new WrapPanel();
                    Image img = new Image();
                    TextBlock tbk = new TextBlock();

                    wpnl.Children.Add(img); wpnl.Children.Add(tbk);
                    wpnl.Tag = GetType().GetProperty("Tag").GetValue(SubItem.Items.GetItemAt(i)).ToString();
                    wpnl.MouseDown += SelectListItemEvent;

                    img.Width = 25; img.Height = 25; img.Source = new BitmapImage(new Uri(@"/Resources/Image/ComponentIcon/DataFileDataIcon.png", UriKind.RelativeOrAbsolute));
                    tbk.HorizontalAlignment = HorizontalAlignment.Center; tbk.VerticalAlignment = VerticalAlignment.Center;
                    tbk.FontSize = 15; tbk.Text = GetType().GetProperty("Uid").GetValue(SubItem.Items.GetItemAt(i)).ToString();

                    datalistbox.Items.Add(wpnl);
                }
            }
            catch (Exception err)
            {
                MessageBox.Show(err.StackTrace);
            }
        }

        private void SelectListItemEvent(object sender, MouseButtonEventArgs e)
        {
            StaticHelper.CurrentFileDataPath = GetType().GetProperty("Tag").GetValue(sender).ToString();
            MessageBox.Show("선택되었습니다.");
        }

        private void Confirm_btn_Click(object sender, RoutedEventArgs e)
        {
            if (StaticHelper.CurrentFileDataPath != string.Empty)
            {
                StartWindow mainwindow = Application.Current.MainWindow as StartWindow;
                mainwindow.Component_DataSelect();
                this.Close();
            }
        }

        private void Cancel_btn_Click(object sender, RoutedEventArgs e)
        {
            StaticHelper.CurrentFileDataPath = string.Empty;
            this.Close();
            return;
        }



    }
}

