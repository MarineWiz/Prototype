﻿using MahApps.Metro.Controls;
using MARINEWIZ1._0.Helper;
using MARINEWIZ1._0.View.ExternalControls;
using MARINEWIZ1._0.View.UserControls;
using MARINEWIZ1._0.View.UserTemplates;
using Microsoft.Win32;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml;
using Path = System.IO.Path;

namespace MARINEWIZ1._0.View.Windows
{
    /// <summary>
    /// StartWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class StartWindow : MetroWindow
    {
        string strClickedCompName = string.Empty;
        UserControl clickedObj;

        /// <summary>
        /// Init
        /// </summary>
        public StartWindow()
        {
            InitializeComponent();
            this.Title = StaticHelper.Projectname + " - MarineWiz 0.8";

            ProjectDefineWindow defineWindow = new ProjectDefineWindow();
            defineWindow.Show();
            defineWindow.Topmost = true;
            
        }

        private void Component_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            strClickedCompName = GetType().GetProperty("Name").GetValue(sender).ToString();
            if (strClickedCompName != string.Empty)
            {
                DragDrop.DoDragDrop(this, sender, DragDropEffects.Copy);
            }
            return;
        }

        private void Maincanvas_Drop(object sender, DragEventArgs e)
        {
            Canvas maincanvas = null;
            
            Random rand = new Random();
            string num = rand.Next(0, 100000).ToString();

            if (mainscrollviewer.Content != null)
                maincanvas = mainscrollviewer.FindChild<Canvas>("maincanvas") as Canvas;


            Point point = e.GetPosition(sender as UIElement);
           

            switch (strClickedCompName)
            {

                case "comp_barchart":
                    ChartImage BarChartImg = new ChartImage(new Uri(@"/Resources/Temp20181206/barChartImg.PNG", UriKind.RelativeOrAbsolute))
                    {
                        Name = "barchart" + num,
                        Width = 250,
                        Height = 250
                    };

                    Canvas.SetLeft(BarChartImg, point.X);
                    Canvas.SetTop(BarChartImg, point.Y);

                    BarChartImg.CanvasLeftPositionValue = point.X;
                    BarChartImg.CanvasTopPositionValue = point.Y;

                    maincanvas.Children.Add(BarChartImg);
                    
                    break;


                case "comp_dockpanel":
                    UIDockPanel dockpanel = new UIDockPanel
                    {
                        Name = "dockpanel" + num
                    };

                    Canvas.SetLeft(dockpanel, point.X);
                    Canvas.SetTop(dockpanel, point.Y);
                    dockpanel.CanvasLeftPositionValue = point.X;
                    dockpanel.CanvasTopPositionValue = point.Y;

                    maincanvas.Children.Add(dockpanel);

                    break;


                case "comp_dotlinechart":

                    ChartImage DotLineChartImg = new ChartImage(new Uri(@"/Resources/Temp20181206/Line.png", UriKind.RelativeOrAbsolute))
                    {
                        Name = "dotlinechart" + num,
                        Width = 250,
                        Height = 250
                    };


                    Canvas.SetLeft(DotLineChartImg, point.X);
                    Canvas.SetTop(DotLineChartImg, point.Y);
                    DotLineChartImg.CanvasLeftPositionValue = point.X;
                    DotLineChartImg.CanvasTopPositionValue = point.Y;

                    maincanvas.Children.Add(DotLineChartImg);

                    break;

                case "comp_stackpanel":
                    UIStackPanel stackpanel = new UIStackPanel
                    {
                        Name = "stackpanel" + num
                    };

                    Canvas.SetLeft(stackpanel, point.X);
                    Canvas.SetTop(stackpanel, point.Y);

                    stackpanel.CanvasLeftPositionValue = point.X;
                    stackpanel.CanvasTopPositionValue = point.Y;

                    maincanvas.Children.Add(stackpanel);
                    break;

                case "comp_wrappanel":
                    UIWrapPanel wrappanel = new UIWrapPanel
                    {
                        Name = "wrappanel" + num
                    };

                    Canvas.SetLeft(wrappanel, point.X);
                    Canvas.SetTop(wrappanel, point.Y);

                    wrappanel.CanvasLeftPositionValue = point.X;
                    wrappanel.CanvasTopPositionValue = point.Y;

                    maincanvas.Children.Add(wrappanel);
                    break;

                case "comp_tabcontrol":
                    UITabControl tabcontrol = new UITabControl
                    {
                        Name = "tabcontrol" + num
                    };

                    Canvas.SetLeft(tabcontrol, point.X);
                    Canvas.SetTop(tabcontrol, point.Y);

                    tabcontrol.CanvasLeftPositionValue = point.X;
                    tabcontrol.CanvasTopPositionValue = point.Y;

                    maincanvas.Children.Add(tabcontrol);
                    break;

                case "comp_label":
                    UILabel label = new UILabel
                    {
                        Name = "label" + num
                    };

                    Canvas.SetLeft(label, point.X);
                    Canvas.SetTop(label, point.X);

                    label.CanvasLeftPositionValue = point.X;
                    label.CanvasTopPositionValue = point.Y;

                    maincanvas.Children.Add(label);
                    break;

                case "comp_textbox":
                    UITextBox textbox = new UITextBox
                    {
                        Name = "textbox" + num
                    };

                    Canvas.SetLeft(textbox, point.X);
                    Canvas.SetTop(textbox, point.Y);

                    textbox.CanvasLeftPositionValue = point.X;
                    textbox.CanvasTopPositionValue = point.Y;

                    maincanvas.Children.Add(textbox);
                    break;

                case "comp_textblock":
                    UITextBlock textblock = new UITextBlock
                    {
                        Name = "textblock" + num
                    };

                    Canvas.SetLeft(textblock, point.X);
                    Canvas.SetTop(textblock, point.Y);

                    textblock.CanvasLeftPositionValue = point.X;
                    textblock.CanvasTopPositionValue = point.Y;

                    maincanvas.Children.Add(textblock);
                    break;

                case "comp_btn":
                    UIButton button = new UIButton
                    {
                        Name = "btn" + num
                    };
                    Button btn = button.Content as Button;
                    btn.Name = "button" + num;

                    Canvas.SetLeft(button, point.X);
                    Canvas.SetTop(button, point.Y);

                    button.CanvasLeftPositionValue = point.X;
                    button.CanvasTopPositionValue = point.Y;

                    // 2018-12-04 Skeleton Code Test 
                    IOHelper ioHelper = new IOHelper();
                    ioHelper.MakeComponentFiles(button);


                    maincanvas.Children.Add(button);
                    break;

                case "comp_radiobtn":
                    UIRadioButton radiobutton = new UIRadioButton
                    {
                        Name = "radio" + num
                    };

                    Canvas.SetLeft(radiobutton, point.X);
                    Canvas.SetTop(radiobutton, point.Y);

                    radiobutton.CanvasLeftPositionValue = point.X;
                    radiobutton.CanvasTopPositionValue = point.Y;

                    maincanvas.Children.Add(radiobutton);
                    break;

                case "comp_checkbox":
                    UICheckBox checkbox = new UICheckBox
                    {
                        Name = "checkbox" + num
                    };

                    Canvas.SetLeft(checkbox, point.X);
                    Canvas.SetTop(checkbox, point.Y);

                    checkbox.CanvasLeftPositionValue = point.X;
                    checkbox.CanvasTopPositionValue = point.Y;

                    maincanvas.Children.Add(checkbox);
                    break;

                case "comp_combobox":
                    UIComboBox combobox = new UIComboBox
                    {
                        Name = "combobox" + num
                    };

                    Canvas.SetLeft(combobox, point.X);
                    Canvas.SetTop(combobox, point.Y);

                    combobox.CanvasLeftPositionValue = point.X;
                    combobox.CanvasTopPositionValue = point.Y;

                    maincanvas.Children.Add(combobox);
                    break;

                case "comp_treeview":

                    //20181213
                    ChartImage TreeviewImg = new ChartImage(new Uri(@"/Resources/Image/ComponentIcon/TreeviewImg.png", UriKind.RelativeOrAbsolute))
                    {
                        Name = "treeview" + num,
                        Width = 250,
                        Height = 250
                    };

                    Canvas.SetLeft(TreeviewImg, point.X);
                    Canvas.SetTop(TreeviewImg, point.Y);

                    TreeviewImg.CanvasLeftPositionValue = point.X;
                    TreeviewImg.CanvasTopPositionValue = point.Y;

                    maincanvas.Children.Add(TreeviewImg);

                    break;

                case "comp_listview":
                    UIListView listview = new UIListView
                    {
                        Name = "listview" + num
                    };

                    Canvas.SetLeft(listview, point.X);
                    Canvas.SetTop(listview, point.Y);

                    listview.CanvasLeftPositionValue = point.X;
                    listview.CanvasTopPositionValue = point.Y;

                    maincanvas.Children.Add(listview);
                    break;

                case "comp_img":
                    UIImage image = new UIImage
                    {
                        Name = "image" + num
                    };

                    Canvas.SetLeft(image, point.X);
                    Canvas.SetTop(image, point.Y);

                    image.CanvasLeftPositionValue = point.X;
                    image.CanvasTopPositionValue = point.Y;

                    maincanvas.Children.Add(image);
                    break;


                    // Temp Source
                case "etri":
                    UIImage etriLogo = new UIImage
                    {
                        Name = "etri" + num,                        
                    };
                    Image img_etri = etriLogo.Content as Image;
                    img_etri.Source = new BitmapImage(new Uri(@"/Resources/ETRI.jpg", UriKind.RelativeOrAbsolute));

                    Canvas.SetLeft(etriLogo, point.X);
                    Canvas.SetTop(etriLogo, point.Y);

                    etriLogo.CanvasLeftPositionValue = point.X;
                    etriLogo.CanvasTopPositionValue = point.Y;

                    maincanvas.Children.Add(etriLogo);
                    break;

                case "emarine":
                    UIImage emarineLogo = new UIImage
                    {
                        Name = "emarine" + num,
                    };
                    Image img_emarine = emarineLogo.Content as Image;
                    img_emarine.Source = new BitmapImage(new Uri(@"/Resources/eMARINE.png", UriKind.RelativeOrAbsolute));

                    Canvas.SetLeft(emarineLogo, point.X);
                    Canvas.SetTop(emarineLogo, point.Y);

                    emarineLogo.CanvasLeftPositionValue = point.X;
                    emarineLogo.CanvasTopPositionValue = point.Y;

                    maincanvas.Children.Add(emarineLogo);
                    break;

                case "wininfo":
                    UIImage wininfoLogo = new UIImage
                    {
                        Name = "wininfo" + num,
                    };
                    Image img_wininfo = wininfoLogo.Content as Image;
                    img_wininfo.Source = new BitmapImage(new Uri(@"/Resources/Wininfo.png", UriKind.RelativeOrAbsolute));

                    Canvas.SetLeft(wininfoLogo, point.X);
                    Canvas.SetTop(wininfoLogo, point.Y);

                    wininfoLogo.CanvasLeftPositionValue = point.X;
                    wininfoLogo.CanvasTopPositionValue = point.Y;

                    maincanvas.Children.Add(wininfoLogo);
                    break;


                case "comp_map":
                   

                    ExtGoogleMap googlemap = new ExtGoogleMap
                    {
                        Name = "googlemap" + num
                    };
                    maincanvas.Children.Add(googlemap);
                    break;

                case "comp_mapSet":
                    ExtGoogleMapSet googlemapSet = new ExtGoogleMapSet
                    {
                        Name = "googlemapSet" + num
                    };
                    maincanvas.Children.Add(googlemapSet);
                    break;


                case "comp_piechart":

                    ChartImage PieChartImg = new ChartImage(new Uri(@"/Resources/Temp20181206/Pie.png", UriKind.RelativeOrAbsolute))
                    {
                        Name = "piechart" + num,
                        Width = 250,
                        Height = 250
                    };

                    Canvas.SetLeft(PieChartImg, point.X);
                    Canvas.SetTop(PieChartImg, point.Y);

                    PieChartImg.CanvasLeftPositionValue = point.X;
                    PieChartImg.CanvasTopPositionValue = point.Y;

                    maincanvas.Children.Add(PieChartImg);

                    break;

                case "comp_doughnutchart":

                    ChartImage DoughnutChartImg = new ChartImage(new Uri(@"/Resources/Temp20181206/Doughnut.png", UriKind.RelativeOrAbsolute))
                    {
                        Name = "doughnutchart" + num,
                        Width = 250,
                        Height = 250
                    };

                    Canvas.SetLeft(DoughnutChartImg, point.X);
                    Canvas.SetTop(DoughnutChartImg, point.Y);

                    DoughnutChartImg.CanvasLeftPositionValue = point.X;
                    DoughnutChartImg.CanvasTopPositionValue = point.Y;

                    maincanvas.Children.Add(DoughnutChartImg);

                    break;

                case "comp_ganttchart":

                    ChartImage GanttChartImg = new ChartImage(new Uri(@"/Resources/ComponentIcon/GaugechartImg.png", UriKind.RelativeOrAbsolute))
                    {
                        Name = "ganttchart" + num,
                        Width = 250,
                        Height = 250
                    };

                    Canvas.SetLeft(GanttChartImg, point.X);
                    Canvas.SetTop(GanttChartImg, point.Y);

                    GanttChartImg.CanvasLeftPositionValue = point.X;
                    GanttChartImg.CanvasTopPositionValue = point.Y;

                    maincanvas.Children.Add(GanttChartImg);

                    break;

                case "comp_gaugechart":

                    ChartImage chartImg = new ChartImage(new Uri(@"/Resources/Temp20181206/gauge.PNG", UriKind.RelativeOrAbsolute))
                    {
                        Name = "gaugechart" + num,
                        Width = 250,
                        Height = 250
                    };

                    Canvas.SetLeft(chartImg, point.X);
                    Canvas.SetTop(chartImg, point.Y);

                    chartImg.CanvasLeftPositionValue = point.X;
                    chartImg.CanvasTopPositionValue = point.Y;

                    maincanvas.Children.Add(chartImg);
                    break;

                case "comp_shipstate":
                    TemplateShipStateMonitoring monitor = new TemplateShipStateMonitoring()
                    {
                        Name = "shipmonitor" + num
                    };
                    Canvas.SetLeft(monitor, point.X);
                    Canvas.SetTop(monitor, point.Y);

                    monitor.CanvasLeftPositionValue = point.X;
                    monitor.CanvasTopPositionValue = point.Y;

                    maincanvas.Children.Add(monitor);                   

                    break;

                default:
                    return;
            }
        }

        private void maincanvas_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            clickedObj = e.Source as UserControl;
            propertyobjectname.Text = "Property - " + e.Source.ToString();
            propertygrid.Children.Clear();

            string strUIName = GetType().GetProperty("Name").GetValue(e.Source).ToString();
            
            if (strUIName.Contains("btn"))
            {
                SetPropertyUI(0, 0, "Name", 0);
                SetPropertyUI(1, 0, "Tag", 0);
                SetPropertyUI(2, 0, "Content", 0);
                SetPropertyUI(3, 0, "TextAlignment", 0);

                SetPropertyUI(0, 1, "HorizontalAlignment", 0);
                SetPropertyUI(1, 1, "VerticalAlignment", 0);
                SetPropertyUI(2, 1, "Position X", 0);
                SetPropertyUI(3, 1, "Position Y", 0);

                SetPropertyUI(0, 2, "Width", 0);
                SetPropertyUI(1, 2, "Height", 0);
                SetPropertyUI(2, 2, "zIndex", 0);
                SetPropertyUI(3, 2, "AddEvent", 4);

                SetPropertyUI(0, 3, "Delete Comp", 3);
            }

            else if (strUIName.Contains("radio"))
            {
                SetPropertyUI(0, 0, "Name", 0);
                SetPropertyUI(1, 0, "Tag", 0);
                SetPropertyUI(2, 0, "Content", 0);
                SetPropertyUI(3, 0, "TextAlignment", 0);

                SetPropertyUI(0, 1, "HorizontalAlignment", 0);
                SetPropertyUI(1, 1, "VerticalAlignment", 0);
                SetPropertyUI(2, 1, "Position X", 0);
                SetPropertyUI(3, 1, "Position Y", 0);

                SetPropertyUI(0, 2, "Width", 0);
                SetPropertyUI(1, 2, "Height", 0);
                SetPropertyUI(2, 2, "zIndex", 0);
                SetPropertyUI(3, 2, "BLANK", 0);

                SetPropertyUI(0, 3, "RadioButton Data Mapping", 4);
                SetPropertyUI(1, 3, "Delete Comp", 3);
            }

            else if (strUIName.Contains("label"))
            {
                SetPropertyUI(0, 0, "Name", 0);
                SetPropertyUI(1, 0, "Tag", 0);
                SetPropertyUI(2, 0, "Content", 0);
                SetPropertyUI(3, 0, "TextAlignment", 0);

                SetPropertyUI(0, 1, "HorizontalAlignment", 0);
                SetPropertyUI(1, 1, "VerticalAlignment", 0);
                SetPropertyUI(2, 1, "Position X", 0);
                SetPropertyUI(3, 1, "Position Y", 0);

                SetPropertyUI(0, 2, "Width", 0);
                SetPropertyUI(1, 2, "Height", 0);
                SetPropertyUI(2, 2, "zIndex", 0);
                SetPropertyUI(3, 2, "BLANK", 0);

                SetPropertyUI(0, 3, "Label Data Mapping", 4);
                SetPropertyUI(1, 3, "Delete Comp", 3);
            }

            else if (strUIName.Contains("textbox"))
            {
                SetPropertyUI(0, 0, "Name", 0);
                // 0 : TextBox
                SetPropertyUI(1, 0, "Tag", 0);
                SetPropertyUI(2, 0, "Content", 0);
                SetPropertyUI(3, 0, "TextAlignment", 0);

                SetPropertyUI(0, 1, "HorizontalAlignment", 0);
                SetPropertyUI(1, 1, "VerticalAlignment", 0);
                SetPropertyUI(2, 1, "Position X", 0);
                SetPropertyUI(3, 1, "Position Y", 0);
                // 5 : ComboBox

                SetPropertyUI(0, 2, "Width", 0);
                SetPropertyUI(1, 2, "Height", 0);
                SetPropertyUI(2, 2, "zIndex", 0);
                SetPropertyUI(3, 2, "BLANK", 0);

                SetPropertyUI(0, 3, "Textbox Data Mapping", 4);
                SetPropertyUI(1, 3, "Delete Comp", 3);
                SetPropertyUI(2, 3, "Font Size", 0);
                SetPropertyUI(3, 3, "Font Color", 5);
            }

            else if (strUIName.Contains("textblock"))
            {
                SetPropertyUI(0, 0, "Name", 0);
                // 0 : TextBox
                SetPropertyUI(1, 0, "Tag", 0);
                SetPropertyUI(2, 0, "Content", 0);
                SetPropertyUI(3, 0, "TextAlignment", 0);

                SetPropertyUI(0, 1, "HorizontalAlignment", 0);
                SetPropertyUI(1, 1, "VerticalAlignment", 0);
                SetPropertyUI(2, 1, "Position X", 0);
                SetPropertyUI(3, 1, "Position Y", 0);
                // 5 : ComboBox

                SetPropertyUI(0, 2, "Width", 0);
                SetPropertyUI(1, 2, "Height", 0);
                SetPropertyUI(2, 2, "zIndex", 0);
                SetPropertyUI(3, 2, "BLANK", 0);

                SetPropertyUI(0, 3, "Delete Comp", 3);
                SetPropertyUI(1, 3, "Font Size", 0);
                SetPropertyUI(2, 3, "Font Color", 5);
            }

            else if (strUIName.Contains("image") || strUIName.Contains("etri") || strUIName.Contains("wininfo") || strUIName.Contains("emarine"))
            {
                SetPropertyUI(0, 0, "Name", 0);
                SetPropertyUI(1, 0, "Tag", 0);
                SetPropertyUI(2, 0, "Content", 0);
                SetPropertyUI(3, 0, "TextAlignment", 0);

                SetPropertyUI(0, 1, "HorizontalAlignment", 0);
                SetPropertyUI(1, 1, "VerticalAlignment", 0);
                SetPropertyUI(2, 1, "Position X", 0);
                SetPropertyUI(3, 1, "Position Y", 0);

                SetPropertyUI(0, 2, "Width", 0);
                SetPropertyUI(1, 2, "Height", 0);
                SetPropertyUI(2, 2, "zIndex", 0);
                SetPropertyUI(3, 2, "Source", 3);

                SetPropertyUI(0, 3, "Delete Comp", 3);
            }

            else if (strUIName.Contains("treeview"))
            {
                SetPropertyUI(0, 0, "Name", 0);
                SetPropertyUI(1, 0, "Tag", 0);
                SetPropertyUI(2, 0, "Content", 0);
                SetPropertyUI(3, 0, "TextAlignment", 0);

                SetPropertyUI(0, 1, "HorizontalAlignment", 0);
                SetPropertyUI(1, 1, "VerticalAlignment", 0);
                SetPropertyUI(2, 1, "Position X", 0);
                SetPropertyUI(3, 1, "Position Y", 0);

                SetPropertyUI(0, 2, "Width", 0);
                SetPropertyUI(1, 2, "Height", 0);
                SetPropertyUI(2, 2, "zIndex", 0);
                SetPropertyUI(3, 2, "DataBinding", 3);

                SetPropertyUI(0, 3, "Delete Comp", 3);
            }

            else if (strUIName.Contains("listview"))
            {
                SetPropertyUI(0, 0, "Name", 0);
                SetPropertyUI(1, 0, "Tag", 0);
                SetPropertyUI(2, 0, "Content", 0);
                SetPropertyUI(3, 0, "TextAlignment", 0);

                SetPropertyUI(0, 1, "HorizontalAlignment", 0);
                SetPropertyUI(1, 1, "VerticalAlignment", 0);
                SetPropertyUI(2, 1, "Position X", 0);
                SetPropertyUI(3, 1, "Position Y", 0);

                SetPropertyUI(0, 2, "Width", 0);
                SetPropertyUI(1, 2, "Height", 0);
                SetPropertyUI(2, 2, "zIndex", 0);
                SetPropertyUI(3, 2, "BLANK", 0);

                SetPropertyUI(0, 3, "Delete Comp", 3);
            }

            else if (strUIName.Contains("listbox"))
            {
                SetPropertyUI(0, 0, "Name", 0);
                SetPropertyUI(1, 0, "Tag", 0);
                SetPropertyUI(2, 0, "Content", 0);
                SetPropertyUI(3, 0, "TextAlignment", 0);

                SetPropertyUI(0, 1, "HorizontalAlignment", 0);
                SetPropertyUI(1, 1, "VerticalAlignment", 0);
                SetPropertyUI(2, 1, "Position X", 0);
                SetPropertyUI(3, 1, "Position Y", 0);

                SetPropertyUI(0, 2, "Width", 0);
                SetPropertyUI(1, 2, "Height", 0);
                SetPropertyUI(2, 2, "zIndex", 0);
                SetPropertyUI(3, 2, "BLANK", 0);

                SetPropertyUI(0, 3, "Delete Comp", 3);
            }

            else if (strUIName.Contains("combobox"))
            {
                SetPropertyUI(0, 0, "Name", 0);
                SetPropertyUI(1, 0, "Tag", 0);
                SetPropertyUI(2, 0, "Content", 0);
                SetPropertyUI(3, 0, "TextAlignment", 0);

                SetPropertyUI(0, 1, "HorizontalAlignment", 0);
                SetPropertyUI(1, 1, "VerticalAlignment", 0);
                SetPropertyUI(2, 1, "Position X", 0);
                SetPropertyUI(3, 1, "Position Y", 0);

                SetPropertyUI(0, 2, "Width", 0);
                SetPropertyUI(1, 2, "Height", 0);
                SetPropertyUI(2, 2, "zIndex", 0);
                SetPropertyUI(3, 2, "BLANK", 0);

                SetPropertyUI(0, 3, "Delete Comp", 3);
            }

            else if (strUIName.Contains("gridview"))
            {
                SetPropertyUI(0, 0, "Name", 0);
                SetPropertyUI(1, 0, "Tag", 0);
                SetPropertyUI(2, 0, "Content", 0);
                SetPropertyUI(3, 0, "TextAlignment", 0);

                SetPropertyUI(0, 1, "HorizontalAlignment", 0);
                SetPropertyUI(1, 1, "VerticalAlignment", 0);
                SetPropertyUI(2, 1, "Position X", 0);
                SetPropertyUI(3, 1, "Position Y", 0);

                SetPropertyUI(0, 2, "Width", 0);
                SetPropertyUI(1, 2, "Height", 0);
                SetPropertyUI(2, 2, "zIndex", 0);
                SetPropertyUI(3, 2, "BLANK", 0);

                SetPropertyUI(0, 3, "Delete Comp", 3);
            }

            else if (strUIName.Contains("googlemap"))
            {
                SetPropertyUI(0, 0, "Name", 0);
                SetPropertyUI(1, 0, "Tag", 0);
                SetPropertyUI(2, 0, "Content", 0);
                SetPropertyUI(3, 0, "TextAlignment", 0);

                SetPropertyUI(0, 1, "HorizontalAlignment", 0);
                SetPropertyUI(1, 1, "VerticalAlignment", 0);
                SetPropertyUI(2, 1, "Position X", 0);
                SetPropertyUI(3, 1, "Position Y", 0);

                SetPropertyUI(0, 2, "Width", 0);
                SetPropertyUI(1, 2, "Height", 0);
                SetPropertyUI(2, 2, "zIndex", 0);
                SetPropertyUI(3, 2, "BLANK", 0);

                SetPropertyUI(0, 3, "GoogleMap Data Mapping", 4);
                SetPropertyUI(1, 3, "Delete Comp", 3);
            }

            else if (strUIName.Contains("googlemapSet"))
            {
                SetPropertyUI(0, 0, "Name", 0);
                SetPropertyUI(1, 0, "Tag", 0);
                SetPropertyUI(2, 0, "Content", 0);
                SetPropertyUI(3, 0, "TextAlignment", 0);

                SetPropertyUI(0, 1, "HorizontalAlignment", 0);
                SetPropertyUI(1, 1, "VerticalAlignment", 0);
                SetPropertyUI(2, 1, "Position X", 0);
                SetPropertyUI(3, 1, "Position Y", 0);

                SetPropertyUI(0, 2, "Width", 0);
                SetPropertyUI(1, 2, "Height", 0);
                SetPropertyUI(2, 2, "zIndex", 0);
                SetPropertyUI(3, 2, "BLANK", 0);

                SetPropertyUI(0, 3, "Delete Comp", 3);
            }

            else if (strUIName.Contains("tabcontrol"))
            {
                SetPropertyUI(0, 0, "Name", 0);
                SetPropertyUI(1, 0, "Tag", 0);
                SetPropertyUI(2, 0, "Content", 0);
                SetPropertyUI(3, 0, "TextAlignment", 0);

                SetPropertyUI(0, 1, "HorizontalAlignment", 0);
                SetPropertyUI(1, 1, "VerticalAlignment", 0);
                SetPropertyUI(2, 1, "Position X", 0);
                SetPropertyUI(3, 1, "Position Y", 0);

                SetPropertyUI(0, 2, "Width", 0);
                SetPropertyUI(1, 2, "Height", 0);
                SetPropertyUI(2, 2, "zIndex", 0);
                SetPropertyUI(3, 2, "BLANK", 0);

                SetPropertyUI(0, 3, "Delete Comp", 3);
            }

            else if (strUIName.Contains("checkbox"))
            {
                SetPropertyUI(0, 0, "Name", 0);
                SetPropertyUI(1, 0, "Tag", 0);
                SetPropertyUI(2, 0, "Content", 0);
                SetPropertyUI(3, 0, "TextAlignment", 0);

                SetPropertyUI(0, 1, "HorizontalAlignment", 0);
                SetPropertyUI(1, 1, "VerticalAlignment", 0);
                SetPropertyUI(2, 1, "Position X", 0);
                SetPropertyUI(3, 1, "Position Y", 0);

                SetPropertyUI(0, 2, "Width", 0);
                SetPropertyUI(1, 2, "Height", 0);
                SetPropertyUI(2, 2, "zIndex", 0);
                SetPropertyUI(3, 2, "BLANK", 0);

                SetPropertyUI(0, 3, "Delete Comp", 3);
            }

            else if (strUIName.Contains("stackpanel"))
            {
                SetPropertyUI(0, 0, "Name", 0);
                SetPropertyUI(1, 0, "Tag", 0);
                SetPropertyUI(2, 0, "Content", 0);
                SetPropertyUI(3, 0, "TextAlignment", 0);

                SetPropertyUI(0, 1, "HorizontalAlignment", 0);
                SetPropertyUI(1, 1, "VerticalAlignment", 0);
                SetPropertyUI(2, 1, "Position X", 0);
                SetPropertyUI(3, 1, "Position Y", 0);

                SetPropertyUI(0, 2, "Width", 0);
                SetPropertyUI(1, 2, "Height", 0);
                SetPropertyUI(2, 2, "zIndex", 0);
                SetPropertyUI(3, 2, "BLANK", 0);

                SetPropertyUI(0, 3, "Delete Comp", 3);
            }

            else if (strUIName.Contains("dockpanel"))
            {
                SetPropertyUI(0, 0, "Name", 0);
                SetPropertyUI(1, 0, "Tag", 0);
                SetPropertyUI(2, 0, "Content", 0);
                SetPropertyUI(3, 0, "TextAlignment", 0);

                SetPropertyUI(0, 1, "HorizontalAlignment", 0);
                SetPropertyUI(1, 1, "VerticalAlignment", 0);
                SetPropertyUI(2, 1, "Position X", 0);
                SetPropertyUI(3, 1, "Position Y", 0);

                SetPropertyUI(0, 2, "Width", 0);
                SetPropertyUI(1, 2, "Height", 0);
                SetPropertyUI(2, 2, "zIndex", 0);
                SetPropertyUI(3, 2, "BLANK", 0);

                SetPropertyUI(0, 3, "Delete Comp", 3);
            }

            else if (strUIName.Contains("wrappanel"))
            {
                SetPropertyUI(0, 0, "Name", 0);
                SetPropertyUI(1, 0, "Tag", 0);
                SetPropertyUI(2, 0, "Content", 0);
                SetPropertyUI(3, 0, "TextAlignment", 0);

                SetPropertyUI(0, 1, "HorizontalAlignment", 0);
                SetPropertyUI(1, 1, "VerticalAlignment", 0);
                SetPropertyUI(2, 1, "Position X", 0);
                SetPropertyUI(3, 1, "Position Y", 0);

                SetPropertyUI(0, 2, "Width", 0);
                SetPropertyUI(1, 2, "Height", 0);
                SetPropertyUI(2, 2, "zIndex", 0);
                SetPropertyUI(3, 2, "BLANK", 0);

                SetPropertyUI(0, 3, "Delete Comp", 3);
            }

            else if (strUIName.Contains("gaugechart"))
            {
                SetPropertyUI(0, 0, "Name", 0);
                SetPropertyUI(1, 0, "Tag", 0);
                SetPropertyUI(2, 0, "Content", 0);
                SetPropertyUI(3, 0, "TextAlignment", 0);

                SetPropertyUI(0, 1, "HorizontalAlignment", 0);
                SetPropertyUI(1, 1, "VerticalAlignment", 0);
                SetPropertyUI(2, 1, "Position X", 0);
                SetPropertyUI(3, 1, "Position Y", 0);

                SetPropertyUI(0, 2, "Width", 0);
                SetPropertyUI(1, 2, "Height", 0);
                SetPropertyUI(2, 2, "zIndex", 0);
                SetPropertyUI(3, 2, "DataBinding", 3);

                SetPropertyUI(0, 3, "Delete Comp", 3);
            }

            else if (strUIName.Contains("barchart"))
            {
                SetPropertyUI(0, 0, "Name", 0);
                SetPropertyUI(1, 0, "Tag", 0);
                SetPropertyUI(2, 0, "Content", 0);
                SetPropertyUI(3, 0, "TextAlignment", 0);

                SetPropertyUI(0, 1, "HorizontalAlignment", 0);
                SetPropertyUI(1, 1, "VerticalAlignment", 0);
                SetPropertyUI(2, 1, "Position X", 0);
                SetPropertyUI(3, 1, "Position Y", 0);

                SetPropertyUI(0, 2, "Width", 0);
                SetPropertyUI(1, 2, "Height", 0);
                SetPropertyUI(2, 2, "zIndex", 0);
                SetPropertyUI(3, 2, "DataBinding", 3);

                SetPropertyUI(0, 3, "Delete Comp", 3);
            }

            else if (strUIName.Contains("piechart"))
            {
                SetPropertyUI(0, 0, "Name", 0);
                SetPropertyUI(1, 0, "Tag", 0);
                SetPropertyUI(2, 0, "Content", 0);
                SetPropertyUI(3, 0, "TextAlignment", 0);

                SetPropertyUI(0, 1, "HorizontalAlignment", 0);
                SetPropertyUI(1, 1, "VerticalAlignment", 0);
                SetPropertyUI(2, 1, "Position X", 0);
                SetPropertyUI(3, 1, "Position Y", 0);

                SetPropertyUI(0, 2, "Width", 0);
                SetPropertyUI(1, 2, "Height", 0);
                SetPropertyUI(2, 2, "zIndex", 0);
                SetPropertyUI(3, 2, "DataBinding", 3);

                SetPropertyUI(0, 3, "Delete Comp", 3);
            }

            else if (strUIName.Contains("doughnutchart"))
            {
                SetPropertyUI(0, 0, "Name", 0);
                SetPropertyUI(1, 0, "Tag", 0);
                SetPropertyUI(2, 0, "Content", 0);
                SetPropertyUI(3, 0, "TextAlignment", 0);

                SetPropertyUI(0, 1, "HorizontalAlignment", 0);
                SetPropertyUI(1, 1, "VerticalAlignment", 0);
                SetPropertyUI(2, 1, "Position X", 0);
                SetPropertyUI(3, 1, "Position Y", 0);

                SetPropertyUI(0, 2, "Width", 0);
                SetPropertyUI(1, 2, "Height", 0);
                SetPropertyUI(2, 2, "zIndex", 0);
                SetPropertyUI(3, 2, "DataBinding", 3);

                SetPropertyUI(0, 3, "Delete Comp", 3);
            }

            else if (strUIName.Contains("gaugechart"))
            {
                SetPropertyUI(0, 0, "Name", 0);
                SetPropertyUI(1, 0, "Tag", 0);
                SetPropertyUI(2, 0, "Content", 0);
                SetPropertyUI(3, 0, "TextAlignment", 0);

                SetPropertyUI(0, 1, "HorizontalAlignment", 0);
                SetPropertyUI(1, 1, "VerticalAlignment", 0);
                SetPropertyUI(2, 1, "Position X", 0);
                SetPropertyUI(3, 1, "Position Y", 0);

                SetPropertyUI(0, 2, "Width", 0);
                SetPropertyUI(1, 2, "Height", 0);
                SetPropertyUI(2, 2, "zIndex", 0);
                SetPropertyUI(3, 2, "DataBinding", 3);

                SetPropertyUI(0, 3, "Delete Comp", 3);
            }
        }

        private void SetPropertyUI(int row, int column, string txt, int UItype)
        {
            if(UItype == 0)
                // TextBox
            {                 
                Grid newItems = new Grid();
                Grid.SetRow(newItems, row);
                Grid.SetColumn(newItems, column);
                newItems.ShowGridLines = true;


                ColumnDefinition column1 = new ColumnDefinition();
                ColumnDefinition column2 = new ColumnDefinition();
                column1.Width = new System.Windows.GridLength(3, System.Windows.GridUnitType.Star);
                column2.Width = new System.Windows.GridLength(2, System.Windows.GridUnitType.Star);

                newItems.ColumnDefinitions.Add(column1);
                newItems.ColumnDefinitions.Add(column2);

                TextBlock tbk = new TextBlock();
                tbk.Text = txt;
                tbk.FontSize = 11;
                tbk.TextAlignment = TextAlignment.Center;
                tbk.HorizontalAlignment = HorizontalAlignment.Stretch;
                tbk.VerticalAlignment = VerticalAlignment.Center;

                Grid.SetRow(tbk, 0);
                Grid.SetColumn(tbk, 0);

                TextBox tbx = new TextBox();
                tbx.HorizontalAlignment = HorizontalAlignment.Stretch;
                tbx.VerticalAlignment = VerticalAlignment.Center;

                Grid.SetRow(tbx, 0);
                Grid.SetColumn(tbx, 1);

                if (txt.Equals("Name"))
                {
                    tbx.TextChanged += ChangeName;
                }
                else if (txt.Equals("Width"))
                {
                    if (clickedObj.ToString().Contains("TreeView"))
                        tbx.TextChanged += ChangeWidthListComponent;
                    else
                        tbx.TextChanged += ChangeWidth;

                    tbx.PreviewTextInput += NumberValidationTextBox;
                }
                else if (txt.Equals("Height"))
                {
                    if (clickedObj.ToString().Contains("TreeView"))
                        tbx.TextChanged += ChangeHeightListComponent;
                    else
                        tbx.TextChanged += ChangeHeight;
                    tbx.PreviewTextInput += NumberValidationTextBox;
                }
                else if (txt.Equals("Position X"))
                {
                    tbx.TextChanged += ChangePositionX;
                    tbx.PreviewTextInput += NumberValidationTextBox;
                }
                else if (txt.Equals("Position Y"))
                {
                    tbx.TextChanged += ChangePositionY;
                    tbx.PreviewTextInput += NumberValidationTextBox;
                }
                else if (txt.Equals("Content"))
                {
                    tbx.TextChanged += ChangeContent;
                }
                else if (txt.Equals("zIndex"))
                {
                    tbx.TextChanged += ChangeZIndex;
                    tbx.PreviewTextInput += NumberValidationTextBox;
                }
                else if(txt.Equals("Font Size"))
                {
                    tbx.TextChanged += ChangeFontSize;
                    tbx.PreviewTextInput += NumberValidationTextBox;
                }

                newItems.Children.Add(tbk);
                newItems.Children.Add(tbx);

                propertygrid.Children.Add(newItems);
            }
            else if(UItype == 1)
                // ComboBox
            {
                Grid newItems = new Grid();
                Grid.SetRow(newItems, row);
                Grid.SetColumn(newItems, column);
                newItems.ShowGridLines = true;

                ColumnDefinition column1 = new ColumnDefinition();
                ColumnDefinition column2 = new ColumnDefinition();
                column1.Width = new GridLength(3, GridUnitType.Star);
                column2.Width = new GridLength(2, GridUnitType.Star);

                newItems.ColumnDefinitions.Add(column1);
                newItems.ColumnDefinitions.Add(column2);

                TextBlock tbk = new TextBlock();
                tbk.Text = txt;
                tbk.FontSize = 11;
                tbk.TextAlignment = TextAlignment.Center;
                tbk.HorizontalAlignment = HorizontalAlignment.Stretch;
                tbk.VerticalAlignment = VerticalAlignment.Center;
                Grid.SetRow(tbk, 0);
                Grid.SetColumn(tbk, 0);

                ComboBox combo1 = new ComboBox();
                combo1.HorizontalAlignment = HorizontalAlignment.Stretch;
                combo1.VerticalAlignment = VerticalAlignment.Center;
                Grid.SetRow(combo1, 0);
                Grid.SetColumn(combo1, 1);
                
            }
            else if(UItype == 3)
                //Button
            {
                Grid newItems = new Grid();
                Grid.SetRow(newItems, row);
                Grid.SetColumn(newItems, column);
                newItems.ShowGridLines = true;

                ColumnDefinition column1 = new ColumnDefinition();
                ColumnDefinition column2 = new ColumnDefinition();
                column1.Width = new System.Windows.GridLength(3, System.Windows.GridUnitType.Star);
                column2.Width = new System.Windows.GridLength(2, System.Windows.GridUnitType.Star);

                newItems.ColumnDefinitions.Add(column1);
                newItems.ColumnDefinitions.Add(column2);

                TextBlock txtBlock1 = new TextBlock();
                txtBlock1.Text = txt;
                txtBlock1.FontSize = 12;
                txtBlock1.TextAlignment = System.Windows.TextAlignment.Center;
                txtBlock1.HorizontalAlignment = System.Windows.HorizontalAlignment.Stretch;
                txtBlock1.VerticalAlignment = System.Windows.VerticalAlignment.Center;
                Grid.SetRow(txtBlock1, 0);
                Grid.SetColumn(txtBlock1, 0);
                

                Button btn = new Button();

                if (txt.Equals("DataBinding"))
                {
                    btn.Content = "DataBinding";
                    btn.Click += ClickEvent_DataBinding;
                }
                else if(txt.Equals("Delete Comp"))
                {
                    btn.Content = "Delete Comp";
                    btn.Click += ClickEvent_DeleteComponent;
                }
                else
                {
                    btn.Content = "...";
                    btn.Click += ClickEvent_ImageSourceOpen;
                }
                Grid.SetRow(btn, 0);
                Grid.SetColumn(btn, 1);

                newItems.Children.Add(txtBlock1);
                newItems.Children.Add(btn);

                propertygrid.Children.Add(newItems);
            }
            else if (UItype == 4)
            {
                // Popup create Button
                Grid newItems = new Grid();
                Grid.SetRow(newItems, row);
                Grid.SetColumn(newItems, column);
                newItems.ShowGridLines = true;

                ColumnDefinition column1 = new ColumnDefinition();
                ColumnDefinition column2 = new ColumnDefinition();
                column1.Width = new System.Windows.GridLength(3, System.Windows.GridUnitType.Star);
                column2.Width = new System.Windows.GridLength(2, System.Windows.GridUnitType.Star);

                newItems.ColumnDefinitions.Add(column1);
                newItems.ColumnDefinitions.Add(column2);

                TextBlock txtBlock1 = new TextBlock();
                txtBlock1.Text = txt;
                txtBlock1.FontSize = 12;
                txtBlock1.TextAlignment = System.Windows.TextAlignment.Center;
                txtBlock1.HorizontalAlignment = System.Windows.HorizontalAlignment.Stretch;
                txtBlock1.VerticalAlignment = System.Windows.VerticalAlignment.Center;
                Grid.SetRow(txtBlock1, 0);
                Grid.SetColumn(txtBlock1, 0);


                Button btn = new Button();
                btn.Content = txt;
                if (clickedObj.Name.Contains("button") || clickedObj.Name.Contains("btn"))
                    btn.Click += ClickEvent_MakeSkeletonCode;
                else
                    btn.Click += ClickEvent_DataMappingPopup;
                Grid.SetRow(btn, 0);
                Grid.SetColumn(btn, 1);

                newItems.Children.Add(txtBlock1);
                newItems.Children.Add(btn);

                propertygrid.Children.Add(newItems);
            }
            else if (UItype == 5)
            {
                // Popup create Button
                Grid newItems = new Grid();
                Grid.SetRow(newItems, row);
                Grid.SetColumn(newItems, column);
                newItems.ShowGridLines = true;

                ColumnDefinition column1 = new ColumnDefinition();
                ColumnDefinition column2 = new ColumnDefinition();
                column1.Width = new System.Windows.GridLength(3, System.Windows.GridUnitType.Star);
                column2.Width = new System.Windows.GridLength(2, System.Windows.GridUnitType.Star);

                newItems.ColumnDefinitions.Add(column1);
                newItems.ColumnDefinitions.Add(column2);

                TextBlock txtBlock1 = new TextBlock();
                txtBlock1.Text = txt;
                txtBlock1.FontSize = 12;
                txtBlock1.TextAlignment = System.Windows.TextAlignment.Center;
                txtBlock1.HorizontalAlignment = System.Windows.HorizontalAlignment.Stretch;
                txtBlock1.VerticalAlignment = System.Windows.VerticalAlignment.Center;
                Grid.SetRow(txtBlock1, 0);
                Grid.SetColumn(txtBlock1, 0);

                ComboBox combo = new ComboBox();
                combo.ItemsSource = typeof(Colors).GetProperties();
                
                Grid.SetRow(combo, 0);
                Grid.SetColumn(combo, 1);

                if (txt.Equals("Font Color"))
                {
                    combo.SelectionChanged += ChangeFontColor;
                }

                newItems.Children.Add(txtBlock1);
                newItems.Children.Add(combo); 

                propertygrid.Children.Add(newItems);
            }

        }

        private void ClickEvent_DeleteComponent(object sender, RoutedEventArgs e)
        {
            maincanvas.Children.Remove(clickedObj);
            propertygrid.Children.Clear();
        }

        private void ClickEvent_DataBinding(object sender, RoutedEventArgs e)
        {
            DataFileSelectWindow datawindow = new DataFileSelectWindow();
            datawindow.Show();
        }

        private void ChangeFontColor(object sender, SelectionChangedEventArgs e)
        {
            var cmb = sender as ComboBox;
            TextBlock obj = clickedObj.Content as TextBlock;

            Color selectedColor = (Color)(cmb.SelectedItem as PropertyInfo).GetValue(1, null);
            obj.Foreground = new SolidColorBrush(selectedColor);
        }

        private void ChangeFontSize(object sender, TextChangedEventArgs e)
        {
            var tb = sender as TextBox;
            if(tb.Text != string.Empty)
            {
                TextBlock obj = clickedObj.Content as TextBlock;
                obj.FontSize = int.Parse(tb.Text);
            }
        }

        private void ChangePositionY(object sender, TextChangedEventArgs e)
        {
            var tb = sender as TextBox;
            if(tb.Text != string.Empty)
            {
                Canvas.SetTop(clickedObj, double.Parse(tb.Text));
            }
        }

        private void ChangePositionX(object sender, TextChangedEventArgs e)
        {
            var tb = sender as TextBox;
            if(tb.Text != string.Empty)
            {
                Canvas.SetLeft(clickedObj, double.Parse(tb.Text));
            }
        }

        private void ChangeName(object sender, TextChangedEventArgs e)
        {
            var tb = sender as TextBox;
            if(tb.Text != string.Empty)
            {
                FrameworkElement obj = clickedObj.Content as FrameworkElement;
                obj.Name = tb.Text;
            }
        }

        private void ClickEvent_ImageSourceOpen(object sender, System.Windows.RoutedEventArgs e)
        {
            OpenFileDialog openDialog = new OpenFileDialog();
            Nullable<bool> result = openDialog.ShowDialog();

            openDialog.Filter = "Image files (*.jpg, *.jpeg, *.jpe, *.jfif, *.png) | *.jpg; *.jpeg; *.jpe; *.jfif; *.png";

            if (result == true)
            {
                Image img = clickedObj.Content as Image;
                img.Source = new BitmapImage(new Uri(openDialog.FileName, UriKind.RelativeOrAbsolute));
            }
        }

        // 2018-12-04 Skeleton Code
        private void ClickEvent_MakeSkeletonCode(object sender, System.Windows.RoutedEventArgs e)
        {
            // MessageBox.Show(StaticHelper.CodePath + @"\" + clickedObj.Name + ".cs");

            FrameworkElement target = clickedObj.Content as FrameworkElement;

            string a  = Path.Combine(StaticHelper.CodePath, target.Name + ".cs");
            Process process = new Process();
            process.StartInfo.FileName = a;
            process.Start();
        }

        private void ClickEvent_DataMappingPopup(object sender, System.Windows.RoutedEventArgs e)
        {
            CompDataMappingWindow datamapping = new CompDataMappingWindow(sender);
            datamapping.Show();
            datamapping.Topmost = true;            
        }

        private void ChangeZIndex(object sender, TextChangedEventArgs e)
        {
            var tb = sender as TextBox;
            if(tb.Text != string.Empty)
            {
                Canvas.SetZIndex(clickedObj, int.Parse(tb.Text));
            }
        }


        private void ChangeContent(object sender, TextChangedEventArgs e)
        {
            var tb = sender as TextBox;
            if(tb.Text != string.Empty)
            {
                if (clickedObj.Name.Contains("btn"))
                {
                    Button btn = clickedObj.Content as Button;
                    btn.Content = tb.Text;
                }
                else if (clickedObj.Name.Contains("label"))
                {
                    Label lbl = clickedObj.Content as Label;
                    lbl.Content = tb.Text;
                }
                else if (clickedObj.Name.Contains("textblock"))
                {
                    TextBlock tbk = clickedObj.Content as TextBlock;
                    tbk.Text = tb.Text;
                }
                else if (clickedObj.Name.Contains("radio"))
                {
                    RadioButton radio = clickedObj.Content as RadioButton;
                    radio.Content = tb.Text;
                }
            }
        }

        private void ChangeWidth(object sender, TextChangedEventArgs e)
        {
            var tb = sender as TextBox;
            if (tb.Text != string.Empty || tb.Text != "")
            {
                FrameworkElement uiElement = clickedObj.Content as FrameworkElement;
                uiElement.Width = int.Parse(tb.Text);
            }
        }
        private void ChangeWidthListComponent(object sender, TextChangedEventArgs e)
        {
            var tb = sender as TextBox;
            if (tb.Text != string.Empty || tb.Text != "")
            {
                FrameworkElement uiElement = clickedObj as FrameworkElement;
                uiElement.Width = int.Parse(tb.Text);
            }
        }

        private void ChangeHeight(object sender, TextChangedEventArgs e)
        {
            var tb = sender as TextBox;
            if (tb.Text != string.Empty || tb.Text != "")
            {
                FrameworkElement uiElement = clickedObj.Content as FrameworkElement;
                uiElement.Height = int.Parse(tb.Text);
            }
        }

        private void ChangeHeightListComponent(object sender, TextChangedEventArgs e)
        {
            var tb = sender as TextBox;
            if (tb.Text != string.Empty || tb.Text != "")
            {
                FrameworkElement uiElement = clickedObj as FrameworkElement;
                uiElement.Height = int.Parse(tb.Text);
            }
        }

        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            // Regular Expression
            e.Handled = regex.IsMatch(e.Text);
        }

        private void Project_open_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            FileStream fs = null;
            Nullable<bool> result = ofd.ShowDialog();

            if (result == true)
            {
                string filePath = ofd.FileName;
                try
                {
                    fs = File.Open(filePath, FileMode.Open, FileAccess.Read);
                    StackPanel stkpnl = XamlReader.Load(fs) as StackPanel;
                    mainscrollviewer.Content = stkpnl;

                    Canvas maincanvas = null;

                    foreach (FrameworkElement element in stkpnl.Children)
                    {
                        if (element.Name.Equals("maincanvas"))
                        {
                            maincanvas = element as Canvas;
                            break;
                        }
                    }
                    MessageBox.Show("1");
                    if(maincanvas != null)
                    {
                        MessageBox.Show("2");
                        foreach (UserControl uc in maincanvas.Children)
                        {
                            MessageBox.Show("3");
                            MessageBox.Show(uc.Name);
                            if (uc.Name.Contains("treeview"))
                            {
                                MessageBox.Show("4");
                                UITreeView tv = uc as UITreeView;
                                tv.BindingData();
                                tv.InitializeComponent();
                            }
                        }
                    }

                }
                catch (Exception err)
                {
                    System.Windows.MessageBox.Show(err.StackTrace);
                    System.Windows.MessageBox.Show(err.Source);
                    System.Windows.MessageBox.Show(err.InnerException.ToString());

                    return;
                }
                finally
                {
                    fs.Close();
                }
            }
        }

        private void Project_save_Click(object sender, RoutedEventArgs e)
        {
            if (mainscrollviewer.Content != null)
            {
                IOHelper ioHelper = new IOHelper();

                foreach(UserControl uc in maincanvas.Children)
                {
                    ioHelper.MakeComponentFiles(uc);
                }
                // UnBinding();
                Project_Save();
            }
            else
            {
                MessageBox.Show("프로젝트를 먼저 생성해주세요.");
                return;
            }
        }

        private void UnBinding()
        {
            foreach (UserControl uc in maincanvas.Children)
            {
                if (uc.DataContext != null)
                    uc.DataContext = null;
            }
        }

        private void Project_Save()
        {
            FileStream fs = null;

            try
            {
                fs = File.Open(StaticHelper.ProjectPath + @"\" + StaticHelper.Projectname + @"\" + StaticHelper.Projectname + ".xaml", FileMode.Create);
                XamlWriter.Save(mainscrollviewer.Content, fs);
            }
            catch (Exception err)
            {
                Console.WriteLine("Error!! : " + err.StackTrace);
                fs.Close();
            }
            finally
            {
                fs.Close();
                MessageBox.Show("저장 완료");
            }
        }

        private void Project_new_Click(object sender, RoutedEventArgs e)
        {
            if (mainscrollviewer.Content == null)
            {
                Project_New();
            }
            else
            {
                if(MessageBox.Show("저장하시겠습니까?", "Warning", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes)
                {
                    Project_Save();
                    Project_New();
                }
                else
                {
                    Project_Delete();
                    Project_New();
                }
            }
        }

        private void Project_New()
        {
            mainscrollviewer.HorizontalScrollBarVisibility = ScrollBarVisibility.Visible;
            mainscrollviewer.VerticalScrollBarVisibility = ScrollBarVisibility.Visible;

            StackPanel stkpnl = new StackPanel();

            WrapPanel wrappnl = new WrapPanel();
            wrappnl.Background = Brushes.DarkGray;

            Image img = new Image();
            img.Source = new BitmapImage(new Uri(@"/Resources/Image/marinewiz_icon_basic_001.png", UriKind.RelativeOrAbsolute));
            img.Width = 25; img.Height = 25;

            TextBlock tbk = new TextBlock();
            tbk.Name = "temptitle";
            tbk.Text = "  " + StaticHelper.Projectname;
            tbk.HorizontalAlignment = HorizontalAlignment.Center;
            tbk.VerticalAlignment = VerticalAlignment.Center;
            tbk.TextAlignment = TextAlignment.Center;
            tbk.FontSize = 14;

            wrappnl.Children.Add(img);
            wrappnl.Children.Add(tbk);

            stkpnl.Children.Add(wrappnl);

            Canvas canvas = new Canvas();
            canvas.Name = "maincanvas";
            canvas.AllowDrop = true;
            canvas.Drop += Maincanvas_Drop;
            canvas.MouseRightButtonDown += maincanvas_MouseRightButtonDown;

            VisualBrush brush = new VisualBrush();
            brush.TileMode = TileMode.Tile;
            brush.Viewport = new Rect(0, 0, 25, 25);
            brush.ViewportUnits = BrushMappingMode.Absolute;
            brush.Viewbox = new Rect(0, 0, 25, 25);
            brush.ViewboxUnits = BrushMappingMode.Absolute;

            Rectangle rect = new Rectangle();
            rect.Width = 30;
            rect.Height = 30;
            rect.Stroke = Brushes.WhiteSmoke;
            rect.StrokeThickness = 0.25;
            rect.StrokeDashArray = new DoubleCollection() { 5, 3 };

            brush.Visual = rect;
            canvas.Background = brush;

            stkpnl.Children.Add(canvas);

            mainscrollviewer.Content = stkpnl;


            ProjectDefineWindow definWindow = new ProjectDefineWindow();
            definWindow.Show();
            definWindow.Topmost = true;

            return;
        }

        private void Project_delete_Click(object sender, RoutedEventArgs e)
        {
            if(mainscrollviewer.Content != null)
            {
                Project_Delete();
            }
        }

        private void Project_Delete()
        {
            mainscrollviewer.HorizontalScrollBarVisibility = ScrollBarVisibility.Hidden;
            mainscrollviewer.VerticalScrollBarVisibility = ScrollBarVisibility.Hidden;

            mainscrollviewer.Content = null;
        }

        private void Temp_Delete(object sender, RoutedEventArgs e)
        {
            maincanvas.Children.Remove(clickedObj);
        }

        private void main_menu_first_file_exit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.MainWindow.Close();
        }
        
        private string FileDataPath = string.Empty;

        private void btn_adddata_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Xml Document (.xml)|*.xml";

            string strTemp = string.Empty;
            string nameTemp = string.Empty;
            Nullable<bool> result = ofd.ShowDialog();

            if (result == true)
            {
                strTemp = ofd.FileName;
            }
            
            WrapPanel wpnl = new WrapPanel();
            Image img = new Image();
            TextBlock tbk = new TextBlock();

            img.Width = 35; img.Height = 35; img.Source = new BitmapImage(new Uri(@"/Resources/Image/ComponentIcon/DataFileDataIcon.png", UriKind.RelativeOrAbsolute));
            tbk.Name = "tbk";
            tbk.HorizontalAlignment = HorizontalAlignment.Center; tbk.VerticalAlignment = VerticalAlignment.Center;
            tbk.Text = System.IO.Path.GetFileName(strTemp); tbk.FontSize = 20;

            wpnl.Children.Add(img);
            wpnl.Children.Add(tbk);
            wpnl.Tag = strTemp;
            wpnl.Uid = System.IO.Path.GetFileName(strTemp);
            wpnl.PreviewMouseDown += Component_PreviewMouseDown;
            //wpnl.MouseDown += Component_DataSelect;

            filedata.Items.Add(wpnl);
        }

        
        //project Export
        private void Project_Export_Click(object sender, RoutedEventArgs e)
        {
            #region Legacy
            /*
            string dummyFileName = "Save Directory";
            
            try
            {
                SaveFileDialog sf = new SaveFileDialog();
                // Feed the dummy name to the save dialog
                sf.FileName = dummyFileName;

                if (sf.ShowDialog() == true)
                {
                    // Now here's our save folder
                    string savePath = System.IO.Path.GetDirectoryName(sf.FileName);

                    //MessageBox.Show(savePath + @"\" + "save.xaml");

                    // 익스포트 폴더 및 파일 생성
                    //String SourcePath = "C:\\Users\\ea2ym\\Desktop\\조선해양\\SourcePath" + @"\";
                    //String DestinationPath = savePath + @"\";

                    //CopyFolder(SourcePath, DestinationPath);
                    //Console.ReadLine();

                    MessageBox.Show("maincanvas.Children Count :: " + maincanvas.Children.Count);

                    try
                    {
                        foreach(UserControl uc in maincanvas.Children)
                        {
                            if (uc.GetType().ToString().Contains("ChartImage"))
                            {
                                if (uc.Name.Contains("gaugechart"))
                                    // Export GaugeChart
                                {
                                    BuildWindow saveWindow = new BuildWindow();
                                    Canvas canvas = saveWindow.buildercanvas;

                                    ExtGaugeChart gauge = new ExtGaugeChart();
                                    canvas.Children.Add(gauge);

                                    FileStream fs = null;
                                    try
                                    {

                                        StringBuilder outStr = new StringBuilder();
                                        XmlWriterSettings settings = new XmlWriterSettings();

                                        settings.Indent = true;
                                        settings.OmitXmlDeclaration = true;

                                        XamlDesignerSerializationManager dsm = new XamlDesignerSerializationManager(XmlWriter.Create(outStr, settings));
                                        dsm.XamlWriterMode = XamlWriterMode.Expression;

                                        XamlWriter.Save(canvas, dsm);

                                        MessageBox.Show(outStr.ToString());


                                        fs = File.Open(@"C:\Users\Toz\Desktop\t\Save.xaml", FileMode.Create);
                                        XamlWriter.Save(canvas, fs);

                                    }
                                    catch(Exception err)
                                    {
                                        MessageBox.Show("FileStream Error InnerException :: " + err.InnerException);
                                        MessageBox.Show("FileStream Error StackTrace :: " + err.StackTrace);
                                        MessageBox.Show("FileStream Error Message :: " + err.Message);
                                        fs.Close();
                                        saveWindow.Close();
                                        return;
                                    }
                                    finally
                                    {
                                        fs.Close();
                                        saveWindow.Close();
                                    }
                                }
                            }
                        }
                    }
                    catch (Exception err)
                    {
                        MessageBox.Show("foreach Exception Message :: " + err.Message);
                        MessageBox.Show("foreach Exception StackTrace :: " + err.StackTrace);
                        MessageBox.Show("foreach Exception InnerException :: " + err.InnerException);
                    }
                }
            }
            catch (Exception err)
            {
                MessageBox.Show("SaveFileDialog Exception Message :: " + err.Message);
                return;
            }
            finally
            {
                MessageBox.Show("내보내기 완료");
            }
            return;*/
            #endregion Legacy

            try
            {
                SaveFileDialog sfd = new SaveFileDialog();
                sfd.ShowDialog();

                ExportHelper exportHelp = new ExportHelper();
                exportHelp.MakeXAMLByType();

                string path = Path.Combine(StaticHelper.ProjectPath, StaticHelper.Projectname);

                CopyFolder(path, sfd.FileName);
            }
            catch(Exception err)
            {

            }
            finally
            {

            }
        } 

        /// dummy 폴더 복사
        static public void CopyFolder(string sourceFolder, string destFolder)
        {
            if (!Directory.Exists(destFolder))
                Directory.CreateDirectory(destFolder);
            string[] files = Directory.GetFiles(sourceFolder);
            foreach (string file in files)
            {
                string name = Path.GetFileName(file);
                string dest = Path.Combine(destFolder, name);
                try
                {
                    File.Copy(file, dest);
                }
                catch (Exception ex)
                {
                    //MessageBox.Show(ex.Message);
                }
            }
            string[] folders = Directory.GetDirectories(sourceFolder);
            foreach (string folder in folders)
            {
                string name = Path.GetFileName(folder);
                string dest = Path.Combine(destFolder, name);

                try
                {
                    CopyFolder(folder, dest);
                }
                catch (Exception ex)
                {
                    //MessageBox.Show(ex.Message);
                }
            }
        }

        /// <summary>
        /// Set Tag
        /// </summary>
        public void Component_DataSelect()
        {
            Uri uri = new Uri(StaticHelper.CurrentFileDataPath, UriKind.RelativeOrAbsolute);
            clickedObj.Tag = uri;
          
        }

        public void LoadSaveProjectByStartWindow(string path)
        {

        }

        private void main_menu_second_add_Click(object sender, RoutedEventArgs e)
        {

        }

        private void main_menu_open_mainwindow_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainwindow = new MainWindow();
            Application.Current.MainWindow = mainwindow;
            mainwindow.Show();
            this.Close();
        }

        public void SetComponentContentByBindingData()
        {
            try
            {
                (clickedObj.Content as Label).Content = StaticHelper.TempString;
            }
            catch { return; }
            
        }

        private void Import_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Xaml files (*.xaml) | *.xaml;";

            Nullable<bool> result = ofd.ShowDialog();

            if (result == true)
            {
                string filePath = ofd.FileName;
                try
                {
                    string path = ofd.FileName;

                }
                catch
                {

                }
            }
        }
    }
}
