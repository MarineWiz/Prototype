﻿using MahApps.Metro.Controls;
using MARINEWIZ1._0.Helper;
using System;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Xml;
using System.Xml.Linq;

namespace MARINEWIZ1._0.View.Windows
{
    /// <summary>
    /// ProjectSettingWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class ProjectSettingWindow : MetroWindow
    {

        string strSelectedType = string.Empty;

        /// <summary>
        /// Project Type Select
        /// </summary>
        public ProjectSettingWindow()
        {
            InitializeComponent();
            DefaultSetting();
        }

        private void DefaultSetting()
        {
            tbx_projectname.Text = "Project Name";
            tbx_path.Text = System.AppDomain.CurrentDomain.BaseDirectory;
        }

        private void ConfirmButton_Click(object sender, RoutedEventArgs e)
        {
            if (GetType().GetProperty("Name").GetValue(sender).Equals("btn_ok"))
            {
                if (tbx_projectname.Text == string.Empty)
                {
                    System.Windows.MessageBox.Show("프로젝트명을 입력해주세요.");
                    return;
                }
                else
                {
                    if (strSelectedType != string.Empty)
                    {
                        switch (strSelectedType)
                        {
                            case "ship_lstitem":
                                // 프로젝트 생성시 각 경로 설정.
                                StaticHelper.Projectname = tbx_projectname.Text;
                                StaticHelper.ProjectPath = tbx_path.Text;

                                StaticHelper.CodePath = Path.Combine(tbx_path.Text, tbx_projectname.Text, "Codes");
                                StaticHelper.XamlPath = Path.Combine(tbx_path.Text, tbx_projectname.Text, "Xaml");

                                //WritePathToXml();
                                MakeProjectDir();
                                break;

                            case "":

                                break;

                            default:
                                return;
                        }
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("프로젝트를 선택해주세요.");
                        return;
                    }
                }
            }
            else if (GetType().GetProperty("Name").GetValue(sender).Equals("btn_cancel"))
            {
                this.Close();
                return;
            }
        }

        private void btn_find_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.Forms.FolderBrowserDialog dlg = new System.Windows.Forms.FolderBrowserDialog();
            dlg.ShowDialog();
            tbx_path.Text = dlg.SelectedPath;
        }

        private void tbx_projectname_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^a-zA-Z0-9]+");
            // Regular Expression
            e.Handled = regex.IsMatch(e.Text);
        }

        private void MakeProjectDir()
        {
            string strProject = string.Empty;

            strProject = System.IO.Path.Combine(tbx_path.Text, tbx_projectname.Text);

            Directory.CreateDirectory(tbx_path.Text);

            string binDir = System.IO.Path.Combine(strProject, "bin");
            string sourceDir = System.IO.Path.Combine(strProject, "Codes");
            string xamlDir = System.IO.Path.Combine(strProject, "Xaml");
            string resourceDir = System.IO.Path.Combine(strProject, "Resources");

            /// 각 Directory 생성 (bin, Source, Xaml, Resource
            Directory.CreateDirectory(binDir);
            Directory.CreateDirectory(sourceDir);
            Directory.CreateDirectory(xamlDir);
            Directory.CreateDirectory(resourceDir);

            IOHelper ioHelper = new IOHelper();

            /*
             * 기본 UI Component Interface상속
             */

            // Chart

            // Chart

            // Container
            ioHelper.MakeDefaultClassFile(sourceDir, "DockPanel");
            ioHelper.MakeDefaultClassFile(sourceDir, "StackPanel");
            ioHelper.MakeDefaultClassFile(sourceDir, "WrapPanel");
            ioHelper.MakeDefaultClassFile(sourceDir, "TabControl;");
            // Container

            // Normal
            ioHelper.MakeDefaultClassFile(sourceDir, "Label");
            ioHelper.MakeDefaultClassFile(sourceDir, "TextBox");
            ioHelper.MakeDefaultClassFile(sourceDir, "TextBlock");
            ioHelper.MakeDefaultClassFile(sourceDir, "Button");
            ioHelper.MakeDefaultClassFile(sourceDir, "RadioButton");
            ioHelper.MakeDefaultClassFile(sourceDir, "CheckBox");
            ioHelper.MakeDefaultClassFile(sourceDir, "ComboBox");
            ioHelper.MakeDefaultClassFile(sourceDir, "TreeView");
            ioHelper.MakeDefaultClassFile(sourceDir, "ListView");
            ioHelper.MakeDefaultClassFile(sourceDir, "Image");
            //Normal

            // Expand
            // ioHelper.MakeDefaultClassFile(sourceDir, "GoogleMap");
            // Expand


            StartWindow startwindow = new StartWindow();
            Application.Current.MainWindow.Close();
            Application.Current.MainWindow = startwindow;
            // startwindow.Topmost = true;
            startwindow.Show();

            return;
        }

        private void tvi_Selected(object sender, RoutedEventArgs e)
        {
            foreach (ListBoxItem lstItemBorder in setting_lstbx.Items)
            {
                lstItemBorder.Visibility = Visibility.Collapsed;
            }

            if (GetType().GetProperty("Name").GetValue(sender).Equals("tvi_setting_ship"))
            {
                ship_lstitem.Visibility = Visibility.Visible;
                ship_lstitem2.Visibility = Visibility.Visible;
                ship_lstitem3.Visibility = Visibility.Visible;
            }
            else if (GetType().GetProperty("Name").GetValue(sender).Equals("tvi_setting_shipyard"))
            {
                shipyard_lstitem.Visibility = Visibility.Visible;
            }
            else if (GetType().GetProperty("Name").GetValue(sender).Equals("tvi_setting_data"))
            {
                shipdata_lstitem.Visibility = Visibility.Visible;
            }
            else
                return;
        }

        private void lstitem_Selected(object sender, RoutedEventArgs e)
        {
            strSelectedType = GetType().GetProperty("Name").GetValue(sender).ToString();
        }
        /* Func :: WritePathToXml
        private void WritePathToXml()
        {
            XmlDocument xDoc = new XmlDocument();

            string RootPath = @"C:\Users\Toz\Desktop\조선해양SDK\MARINEWIZ1.0_20181128\MARINEWIZ1.0\Resources\File\Database_ProjectPath.xml";

            // TODO : 경로 자동으로 받아올 수 있게 수정해줘야 함

            xDoc.Load(RootPath);

            XmlElement project = xDoc.CreateElement("proj");
            XmlElement name = xDoc.CreateElement("name");
            XmlElement path = xDoc.CreateElement("path");

            name.InnerText = StaticHelper.Projectname;
            path.InnerText = StaticHelper.ProjectPath;

            project.AppendChild(name);
            project.AppendChild(path);

            xDoc.DocumentElement.AppendChild(project);
            xDoc.Save(RootPath);
        }
        */
    }
}
