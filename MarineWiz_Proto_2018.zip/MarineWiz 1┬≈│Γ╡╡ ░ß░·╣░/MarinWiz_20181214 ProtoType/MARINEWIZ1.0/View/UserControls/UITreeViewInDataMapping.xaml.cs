﻿using MARINEWIZ1._0.Helper;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml;

namespace MARINEWIZ1._0.View.UserControls
{
    /// <summary>
    /// UITreeView.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class UITreeViewInDataMapping : UserControl
    {
        TreeView tv;

        public UITreeViewInDataMapping()
        {
            InitializeComponent();
            tv = this.Content as TreeView;

            tv.SelectedItemChanged += FindXmlDataValue;
            
            // AddEventHandler();
        }
        


        private void FindXmlDataValue(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            try
            {
                string strName = ((XmlNode)(sender as TreeView).SelectedItem).OuterXml;
                string strValue = string.Empty;

                char c = '\"';

                string[] resultTexts = strName.Split(c);

                string resultText = resultTexts[3];

                if (resultText == string.Empty)
                    resultText = "NaN";

                StaticHelper.TempString = resultText;
              
            }
            catch { return; }
        }

        public void BindingData(string strPath)
        {
            ViewModel.VM_XmlProvider xmlProvider = new ViewModel.VM_XmlProvider(strPath);
            
            TreeView tv = this.Content as TreeView;
            tv.DataContext = xmlProvider.XmlData;
        }

    }
}
