﻿using MARINEWIZ1._0.ViewModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.DataVisualization;
using System.Windows.Controls.DataVisualization.Charting;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MARINEWIZ1._0.View.ExternalControls
{
    /// <summary>
    /// ExtDotLineChart.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class ExtDotLineChart : UserControl
    {
        //Chart ChartProperty = new Chart();
        //List<KeyValuePair<string, int>> ParsingDataList = new List<KeyValuePair<string, int>>();

        /// <summary>
        /// 생성자
        /// </summary>
        public ExtDotLineChart()
        {
            InitializeComponent();

            Chart ChartProperty = new Chart();

            this.Content = ChartProperty;


            //Init();
            //showColumnChart();
            // ParsingData();
        }

        private void ParsingData()
        {

        }
        

        private void showColumnChart()
        {
            List<KeyValuePair<string, int>> valueList = new List<KeyValuePair<string, int>>();

            valueList.Add(new KeyValuePair<string, int>("value 1", 120));
            valueList.Add(new KeyValuePair<string, int>("value 2", 30));
            valueList.Add(new KeyValuePair<string, int>("value 3", 70));
            valueList.Add(new KeyValuePair<string, int>("value 4", 100));
            valueList.Add(new KeyValuePair<string, int>("value 5", 50));
            valueList.Add(new KeyValuePair<string, int>("value 6", 80));
            valueList.Add(new KeyValuePair<string, int>("value 7", 140));

            //Setting data for line chart
            //ChartProperty.DataContext = valueList;
        }

    }
}

