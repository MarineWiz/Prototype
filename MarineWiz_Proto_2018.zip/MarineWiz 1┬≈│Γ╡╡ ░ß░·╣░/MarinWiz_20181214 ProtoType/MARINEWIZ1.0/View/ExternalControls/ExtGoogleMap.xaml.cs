﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace MARINEWIZ1._0.View.ExternalControls
{
    /// <summary>
    /// ExtGoogleMap.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class ExtGoogleMap : UserControl
    {
        String sURL = AppDomain.CurrentDomain.BaseDirectory + "html/map.html";
        //String sURL = "MarineWiz1.0/html/map.html";

        Double Lat = 35.523287;
        Double Long = 129.438377;

        Double[] LatArray_temp = { 35.523287, 35.524287, 35.525287, 35.526287, 35.527287 };
        Double[] LongArray_temp = { 129.438377, 129.439377, 129.440377, 129.441377, 129.442377 };

        Double[] LatArray_worker = { 35.520287, 35.521287, 35.522287, 35.523287, 35.524287 };
        Double[] LongArray_worker = { 129.438377, 129.439377, 129.440377, 129.441377, 129.442377 };

        Double[] LatArray_crane = { 35.523287, 35.524287, 35.525287, 35.526287, 35.527287 };
        Double[] LongArray_crane = { 129.435377, 129.436377, 129.437377, 129.438377, 129.439377 };

        Double[] LatArray_freight = { 35.523287, 35.524287, 35.525287, 35.526287, 35.527287 };
        Double[] LongArray_freight = { 129.438377, 129.439377, 129.440377, 129.441377, 129.442377 };

        public ExtGoogleMap()
        {
            InitializeComponent();
            AddEventHandler();
        }

        private double inCanvasLeft = 0.0d;
        public double CanvasLeftPositionValue
        {
            get { return inCanvasLeft; }
            set { inCanvasLeft = value; }
        }
        private double inCanvasTop = 0.0d;
        public double CanvasTopPositionValue
        {
            get { return inCanvasTop; }
            set { inCanvasTop = value; }
        }

        protected bool isDragging;
        private Point clickPosition;

        private void AddEventHandler()
        {
            this.MouseDoubleClick += new MouseButtonEventHandler(Control_MouseLeftButtonDown);
            this.MouseLeftButtonUp += new MouseButtonEventHandler(Control_MouseLeftButtonUp);
            this.MouseMove += new MouseEventHandler(Control_MouseMove);
        }

        private void Control_MouseMove(object sender, MouseEventArgs e)
        {
            var draggableControl = sender as UserControl;

            if (isDragging && draggableControl != null)
            {
                Point currentPosition = e.GetPosition(this.Parent as UIElement);
                var transform = draggableControl.RenderTransform as TranslateTransform;

                if (transform == null)
                {
                    transform = new TranslateTransform();
                    draggableControl.RenderTransform = transform;
                }

                if (Math.Abs((int)currentPosition.X) % 25 == 0)
                {
                    transform.X = currentPosition.X - clickPosition.X - CanvasLeftPositionValue;
                    transform.X -= (int)(transform.X % 25);
                }
                if (Math.Abs((int)currentPosition.Y) % 25 == 0)
                {
                    transform.Y = currentPosition.Y - clickPosition.Y - CanvasTopPositionValue;
                    transform.Y -= (int)(transform.Y % 25);
                }
            }
        }

        private void Control_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            isDragging = false;
            var draggable = sender as UserControl;
            draggable.ReleaseMouseCapture();
        }

        private void Control_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            isDragging = true;
            var draggableControl = sender as UserControl;
            clickPosition = e.GetPosition(this);
            draggableControl.CaptureMouse();
        }

        private void SetupObjectForScripting(object sender, RoutedEventArgs e)
        {
            Uri uri = new Uri(sURL);
            webBrowser1.Navigate(uri);
            ((WebBrowser)sender).ObjectForScripting = new HtmlInteropInternalTestClass();
        }
    }               
}
