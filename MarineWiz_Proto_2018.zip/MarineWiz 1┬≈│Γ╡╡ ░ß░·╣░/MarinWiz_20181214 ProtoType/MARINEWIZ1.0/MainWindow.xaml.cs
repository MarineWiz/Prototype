﻿using MahApps.Metro.Controls;
using MARINEWIZ1._0.Helper;
using MARINEWIZ1._0.View.Windows;
using MARINEWIZ1._0.ViewModel;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml;

namespace MARINEWIZ1._0
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MainWindow : MetroWindow
    {
        /// <summary>
        /// 시작 Window
        /// TODO : 모든 Window 하나로 통합.
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Hyperlink_RequestNavigate(object sender, RequestNavigateEventArgs e)
        {
            MessageBox.Show("기능추가예정");
        }

        private void start_newproject_Selected(object sender, RoutedEventArgs e)
        {
            ProjectSettingWindow window = new ProjectSettingWindow();
            window.Topmost = true;
            window.Show();
        }

        private void main_menu_first_file_exit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.MainWindow.Close();
        }

        private void main_menu_first_file_project_open_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            Nullable<bool> result = ofd.ShowDialog();

            if (result == true)
            {
                string path = ofd.FileName;

                StartWindow mainwindow = new StartWindow();
                Application.Current.MainWindow = mainwindow;
                mainwindow.LoadSaveProjectByStartWindow(path);
                StaticHelper.StartSwt = true;
                mainwindow.Show();

                this.Close();
            }
        }

        private void startprojectlv_Loaded(object sender, RoutedEventArgs e)
        {
            
        }

        private void main_menu_first_do_builder_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Xaml Document (.xaml)|*.xaml";

            Nullable<bool> result = ofd.ShowDialog();

            if (result == true)
            {
                string path = ofd.FileName;

                StaticHelper.builderPath = path;

                MessageBox.Show(StaticHelper.builderPath);

                BuildWindow mainwindow = new BuildWindow();
                Application.Current.MainWindow = mainwindow;
                
                mainwindow.Show();

                this.Close();
            }
        }
    }
}
