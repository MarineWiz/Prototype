﻿using MahApps.Metro.Controls;
using MARINEWIZ1._0.Helper;
using MARINEWIZ1._0.View.ExternalControls;
using MARINEWIZ1._0.View.UserControls;
using MARINEWIZ1._0.View.Windows;
using MARINEWIZ1._0.ViewModel;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml;

namespace MARINEWIZ1._0
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MainWindow : MetroWindow
    {
        /// <summary>
        /// Constructor MainWindow
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();
            ChildObjectsDataBinding();
        }

        private void ChildObjectsDataBinding()
        {
            try
            {
                foreach (UserControl uc in maincanvas.Children)
                {
                    // MessageBox.Show(uc.GetType().ToString());

                    if (uc.GetType().ToString().Contains("UITreeView"))
                    {
                        UITreeView tv = uc as UITreeView;
                        tv.BindingData(uc.Tag.ToString());
                    }
                    else if (uc.GetType().ToString().Contains("ExtGaugeChart"))
                    {
                        ExtGaugeChart gauge = uc as ExtGaugeChart;
                        gauge.BindingToViewModel(uc.Tag.ToString());
                    }
                    else if (uc.GetType().ToString().Contains("UIImage"))
                    {
                        UIImage img = uc as UIImage;
                        Image i = img.Content as Image;
                        i.Width = img.Width;
                        i.Height = img.Height;
                        img.SetImage(uc.Tag.ToString());
                    }
                    else if (uc.GetType().ToString().Contains("ExtBarChart"))
                    {
                        ExtBarChart bar = uc as ExtBarChart;
                        bar.BindingToViewModel(uc.Tag.ToString());
                    }
                    else if (uc.GetType().ToString().Contains("ExtPieChart"))
                    {
                        ExtPieChart pie = uc as ExtPieChart;
                        pie.BindingToViewModel(uc.Tag.ToString());
                    }
                    else if (uc.GetType().ToString().Contains("UITextBlock"))
                    {
                        UITextBlock uitbk = uc as UITextBlock;
                        TextBlock tbk = uitbk.Content as TextBlock;
                        tbk.Text = uitbk.Tag.ToString();
                        tbk.Foreground = uitbk.Foreground;

                        if (uc.Name.Contains("t60"))
                        {
                            tbk.Width = 250;
                            tbk.Height = 250;
                            tbk.FontSize = 60;
                        }
                        else if (uc.Name.Contains("t36"))
                        {
                            tbk.Width = 200;
                            tbk.Height = 200;
                            tbk.FontSize = 36;
                        }
                        else if (uc.Name.Contains("t24"))
                        {
                            tbk.FontSize = 24;
                        }
                    }
                }
            }
            catch
            {
                
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }
        
    }
}
