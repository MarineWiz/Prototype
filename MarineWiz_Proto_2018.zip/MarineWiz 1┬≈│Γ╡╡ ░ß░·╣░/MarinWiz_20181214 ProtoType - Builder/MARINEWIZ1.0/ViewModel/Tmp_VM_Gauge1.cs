﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MARINEWIZ1._0.ViewModel
{
    class Tmp_VM_Gauge1
    {
    }
}
