﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace MARINEWIZ1._0.ViewModel
{
    public class Tmp_VM_Doughnut
    {
        /*
        public DelegateCommand AddSeriesCommand { get; set; }

        public Tmp_VM_Doughnut()
        {
            AddSeriesCommand = new DelegateCommand(x => AddSeries());
        }


        int newSeriesCounter = 1;
        private void AddSeries()
        {
            ObservableCollection<TestClass> data = new ObservableCollection<TestClass>();

            data.Add(new TestClass() { Category = "Globalization", Number = 5 });
            data.Add(new TestClass() { Category = "Features", Number = 10 });
            data.Add(new TestClass() { Category = "ContentTypes", Number = 15 });
            data.Add(new TestClass() { Category = "Correctness", Number = 20 });
            data.Add(new TestClass() { Category = "Naming", Number = 15 });
            data.Add(new TestClass() { Category = "Best Practices", Number = 10 });

            Series.Add(new SeriesData() { SeriesDisplayName = "New Series " + newSeriesCounter.ToString(), Items = data });

            newSeriesCounter++;
        }

        private object selectedItem = null;
        public object SelectedItem
        {
            get
            {
                return selectedItem;
            }
            set
            {
                selectedItem = value;
                NotifyPropertyChanged("SelectedItem");
            }
        }

        public ObservableCollection<SeriesData> Series
        {
            get;
            set;
        }

        private void NotifyPropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged.Invoke(this, new PropertyChangedEventArgs(property));
            }
        }
        public event PropertyChangedEventHandler PropertyChanged;
    }
    */
        //public class DelegateCommand : ICommand
        //{
        //    private readonly Predicate<object> _canExecute;
        //    private readonly Action<object> _execute;

        //    public event EventHandler CanExecuteChanged;

        //    public DelegateCommand(Action<object> execute)
        //        : this(execute, null)
        //    {

        //    }

        //    public DelegateCommand(Action<object> execute,
        //                   Predicate<object> canExecute)
        //    {
        //        _execute = execute;
        //        _canExecute = canExecute;
        //    }

        //    public bool CanExecute(object parameter)
        //    {
        //        if (_canExecute == null)
        //        {
        //            return true;
        //        }

        //        return _canExecute(parameter);
        //    }

        //    public void Execute(object parameter)
        //    {
        //        _execute(parameter);
        //    }

        //    public void RaiseCanExecuteChanged()
        //    {
        //        if (CanExecuteChanged != null)
        //        {
        //            CanExecuteChanged(this, EventArgs.Empty);
        //        }
        //    }
        //}
    }
}
