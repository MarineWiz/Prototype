﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MARINEWIZ1._0.Helper
{
    static public class StaticHelper
    {
        static public string builderPath = string.Empty;
        static public string ProjectPath = string.Empty;
        static public string CodePath = string.Empty;
        static public string XamlPath = string.Empty;
        static public string Projectname = string.Empty;
        static public string CurrentFileDataPath = string.Empty;
        static public bool StartSwt = false;
    }
}
