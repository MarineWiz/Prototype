﻿using MahApps.Metro.Controls;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace MARINEWIZ1._0.Helper
{
    class ExportHelper
    {
        public ExportHelper()
        {

        }

        public void MakeTempXAML(string strTreePath, double nTreeLeft, double nTreeTop, string strChartPath, double nChartLeft, double nChartTop)
        {
            FileStream fs = null;
            StreamWriter sw = null;

            try
            {
                fs = new FileStream(StaticHelper.ProjectPath + @"\Export.xaml", FileMode.OpenOrCreate);
                sw = new StreamWriter(fs, Encoding.UTF8);

                sw.WriteLine("" +
                    "<control:MetroWindow" +
                    "\n    xmlns = \"http://schemas.microsoft.com/winfx/2006/xaml/presentation\"" +
                    "\n    xmlns:x = \"http://schemas.microsoft.com/winfx/2006/xaml\"" +
                    "\n    xmlns:d = \"http://schemas.microsoft.com/expression/blend/2008\"" +
                    "\n    xmlns:mc = \"http://schemas.openxmlformats.org/markup-compatibility/2006\"" +
                    "\n    xmlns:control = \"http://metro.mahapps.com/winfx/xaml/controls\" " +
                    "\n    xmlns:system = \"clr-namespace:System;assembly=mscorlib\"" +
                    "\n    xmlns:UserControls=\"clr-namespace:System;assembly=mscorlib\""+
                    "\n    x:Class = \"MARINEWIZ1._0.MainWindow\"" +
                    "\n    mc:Ignorable = \"d\"" +
                    "\n    Title = \"Builder 전용 - MarineWiz\"" +
                    "\n    Height = \"800\" Width = \"1000\"" +
                    "\n    WindowStartupLocation = \"CenterOwner\"" +
                    ">" +

                    "<Canvas Name = \"maincanvas\"" +  " AllowDrop = \"True\"" + " " + ">" +
                    "\n <external:ExtGaugeChart Tag= \"" + strChartPath + "\" Canvas.Left=\"" + nChartLeft + "\" Canvas.Top=\"" + nChartTop + "\"/>" +
                    "\n <marinewizvuc:UITreeView Width=\"250\" Height=\"500\" Tag= \"" + strTreePath + "\" Canvas.Left=\"" + nTreeLeft + "\" Canvas.Top=\"" + nTreeTop + "\"/>" +
                    "</Canvas >" +
                    "</control:MetroWindow > ");
            }
            catch (Exception err)
            {
                MessageBox.Show("InnerException :: " + err.InnerException);
                MessageBox.Show("StackTrace :: " + err.StackTrace);
                MessageBox.Show("ErrorMessage :: " + err.Message);

                sw.Close();
                fs.Close();
            }
            finally
            {
                sw.Close();
                fs.Close();
            }
            
        }


    }
}
