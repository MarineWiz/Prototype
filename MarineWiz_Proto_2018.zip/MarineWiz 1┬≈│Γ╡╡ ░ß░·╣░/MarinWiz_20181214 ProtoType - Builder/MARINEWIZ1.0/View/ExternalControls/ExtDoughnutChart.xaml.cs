﻿using De.TorstenMandelkow.MetroChart;
using MARINEWIZ1._0.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MARINEWIZ1._0.View.ExternalControls
{
    /// <summary>
    /// ExtDoughnutChart.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class ExtDoughnutChart : UserControl
    {
        public ExtDoughnutChart()
        {
            InitializeComponent();
            //AddEventHandler();            
        }

        public void DoDataBinding()
        {
            //TestPageViewModel viewModel = new TestPageViewModel();
            //this.DataContext = viewModel;

            //// this.Tag <= 얘가 경로고, 경로에서 xml읽어서 파싱해서 뿌려라.

            //DoughnutChart chart = this.Content as DoughnutChart;
            //chart.Foreground = Brushes.Black;
            //chart.ChartTitleVisibility = Visibility.Collapsed;
            //chart.InnerRadiusRatio = 0.3;
            //chart.HorizontalContentAlignment = HorizontalAlignment.Center;
            //chart.MaxDataPointValue = 100;
        }






        protected bool isDragging;
        private Point clickPosition;

        private void AddEventHandler()
        {
            this.MouseDoubleClick += new MouseButtonEventHandler(Control_MouseLeftButtonDown);
            this.MouseLeftButtonUp += new MouseButtonEventHandler(Control_MouseLeftButtonUp);
            this.MouseMove += new MouseEventHandler(Control_MouseMove);
        }

        private void Control_MouseMove(object sender, MouseEventArgs e)
        {
            var draggableControl = sender as UserControl;

            if (isDragging && draggableControl != null)
            {
                Point currentPosition = e.GetPosition(this.Parent as UIElement);
                var transform = draggableControl.RenderTransform as TranslateTransform;

                if (transform == null)
                {
                    transform = new TranslateTransform();
                    draggableControl.RenderTransform = transform;
                }

                if (Math.Abs((int)currentPosition.X) % 25 == 0)
                {
                    transform.X = currentPosition.X - clickPosition.X;
                    transform.X -= (int)(transform.X % 25);
                }
                if (Math.Abs((int)currentPosition.Y) % 25 == 0)
                {
                    transform.Y = currentPosition.Y - clickPosition.Y;
                    transform.Y -= (int)(transform.Y % 25);
                }
            }
        }

        private void Control_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            isDragging = false;
            var draggable = sender as UserControl;
            draggable.ReleaseMouseCapture();
        }

        private void Control_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            isDragging = true;
            var draggableControl = sender as UserControl;
            clickPosition = e.GetPosition(this);
            draggableControl.CaptureMouse();
        }
    }
}
