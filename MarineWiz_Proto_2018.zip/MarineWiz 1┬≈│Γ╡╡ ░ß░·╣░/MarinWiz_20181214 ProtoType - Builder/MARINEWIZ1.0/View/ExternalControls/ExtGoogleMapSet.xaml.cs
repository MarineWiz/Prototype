﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace MARINEWIZ1._0.View.ExternalControls
{
    /// <summary>
    /// ExtGoogleMap.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class ExtGoogleMapSet : UserControl
    {
        String sURL = AppDomain.CurrentDomain.BaseDirectory + "html/map.html";
        //String sURL = "MarineWiz1.0/html/map.html";

        Double Lat = 35.523287;
        Double Long = 129.438377;

        // 샘플 IoT 센싱 GPS 위치 데이터 S
        Double[] LatArray_temp = { 35.523287, 35.519219, 35.521372, 35.535509, 35.531999 };
        Double[] LongArray_temp = { 129.438377, 129.441393, 129.446283, 129.442682, 129.449649 };

        Double[] LatArray_worker = { 35.520287, 35.517531, 35.518471, 35.520850, 35.527780 };
        Double[] LongArray_worker = { 129.438377, 129.437131, 129.442544, 129.443374, 129.452903 };

        Double[] LatArray_crane = { 35.523287, 35.519219, 35.521372, 35.531509, 35.531999 };
        Double[] LongArray_crane = { 129.438377, 129.441393, 129.446283, 129.442682, 129.449649 };

        Double[] LatArray_freight = { 35.520287, 35.517531, 35.518471, 35.520850, 35.527780 };
        Double[] LongArray_freight = { 129.438377, 129.437131, 129.442544, 129.443374, 129.452903 };
        // 샘플 IoT 센싱 GPS 위치 데이터 E

        public ExtGoogleMapSet()
        {
            InitializeComponent();
            AddEventHandler();
        }

        protected bool isDragging;
        private Point clickPosition;

        private void AddEventHandler()
        {
            this.MouseDoubleClick += new MouseButtonEventHandler(Control_MouseLeftButtonDown);
            this.MouseLeftButtonUp += new MouseButtonEventHandler(Control_MouseLeftButtonUp);
            this.MouseMove += new MouseEventHandler(Control_MouseMove);
        }

        private void Control_MouseMove(object sender, MouseEventArgs e)
        {
            var draggableControl = sender as UserControl;

            if (isDragging && draggableControl != null)
            {
                Point currentPosition = e.GetPosition(this.Parent as UIElement);
                var transform = draggableControl.RenderTransform as TranslateTransform;

                if (transform == null)
                {
                    transform = new TranslateTransform();
                    draggableControl.RenderTransform = transform;
                }

                if (Math.Abs((int)currentPosition.X) % 25 == 0)
                {
                    transform.X = currentPosition.X - clickPosition.X;
                    transform.X -= (int)(transform.X % 25);
                }
                if (Math.Abs((int)currentPosition.Y) % 25 == 0)
                {
                    transform.Y = currentPosition.Y - clickPosition.Y;
                    transform.Y -= (int)(transform.Y % 25);
                }
            }
        }

        private void Control_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            isDragging = false;
            var draggable = sender as UserControl;
            draggable.ReleaseMouseCapture();
        }

        private void Control_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            isDragging = true;
            var draggableControl = sender as UserControl;
            clickPosition = e.GetPosition(this);
            draggableControl.CaptureMouse();
        }

        private void DockPanel_Loaded(object sender, RoutedEventArgs e)
        {
            Uri uri = new Uri(sURL);
            webBrowser1.Navigate(uri);
        }

        private void setupObjectForScripting(object sender, RoutedEventArgs e)
        {
            ((WebBrowser)sender).ObjectForScripting = new HtmlInteropInternalTestClass();
        }

        // 온도 라디오 버튼 클릭 이벤트
        private void TempBtn_Checked(object sender, RoutedEventArgs e)
        {
            webBrowser1.InvokeScript("initialize", new Object[] { Lat, Long });
            for (int i = 0; i < 5; i++)
            {
                webBrowser1.InvokeScript("addMarker", new Object[] { LatArray_temp[i], LongArray_temp[i], tbName.Text, tbDirection.Text, "marker_001.png" });
            }
        }

        // 작업자 라디오 버튼 클릭 이벤트
        private void WorkerBtn_Checked(object sender, RoutedEventArgs e)
        {
            webBrowser1.InvokeScript("initialize", new Object[] { Lat, Long });
            for (int i = 0; i < 5; i++)
            {
                webBrowser1.InvokeScript("addMarker", new Object[] { LatArray_worker[i], LongArray_worker[i], tbName.Text, tbDirection.Text, "marker_002.png" });
            }
        }

        // 크레인 라디오 버튼 클릭 이벤트
        private void CraneBtn_Checked(object sender, RoutedEventArgs e)
        {
            webBrowser1.InvokeScript("initialize", new Object[] { Lat, Long });
            for (int i = 0; i < 5; i++)
            {
                webBrowser1.InvokeScript("addMarker", new Object[] { LatArray_crane[i], LongArray_crane[i], tbName.Text, tbDirection.Text, "marker_003.png" });
            }
        }

        // 화물 라디오 버튼 클릭 이벤트
        private void FreightBtn_Checked(object sender, RoutedEventArgs e)
        {
            webBrowser1.InvokeScript("initialize", new Object[] { Lat, Long });
            for (int i = 0; i < 5; i++)
            {
                webBrowser1.InvokeScript("addMarker", new Object[] { LatArray_freight[i], LongArray_freight[i], tbName.Text, tbDirection.Text, "marker_004.png" });
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Lat = Convert.ToDouble(this.tbName.Text);
            Long = Convert.ToDouble(this.tbDirection.Text);
            webBrowser1.InvokeScript("initialize", new Object[] { Lat, Long });
        }
    }

    // Object used for communication from JS -> WPF
    [System.Runtime.InteropServices.ComVisibleAttribute(true)]
    public class HtmlInteropInternalTestClass
    {
        public void endDragMarkerCS(Decimal Lat, Decimal Lng)
        {
            //((Windows.StartWindow)Application.Current.MainWindow).tbLocation.Text = Math.Round(Lat, 5) + "," + Math.Round(Lng, 5);
        }
    }
}
