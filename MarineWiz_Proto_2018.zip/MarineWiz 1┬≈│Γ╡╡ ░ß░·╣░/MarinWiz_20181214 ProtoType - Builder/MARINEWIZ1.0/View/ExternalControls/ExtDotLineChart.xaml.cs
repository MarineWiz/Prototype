﻿using MARINEWIZ1._0.ViewModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.DataVisualization;
using System.Windows.Controls.DataVisualization.Charting;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MARINEWIZ1._0.View.ExternalControls
{
    /// <summary>
    /// ExtDotLineChart.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class ExtDotLineChart : UserControl
    {
        //Chart ChartProperty = new Chart();
        //List<KeyValuePair<string, int>> ParsingDataList = new List<KeyValuePair<string, int>>();

        /// <summary>
        /// 생성자
        /// </summary>
        public ExtDotLineChart()
        {
            InitializeComponent();

            Chart ChartProperty = new Chart();

            this.Content = ChartProperty;


            //Init();
            //showColumnChart();
            // ParsingData();
        }
        /// <summary>
        /// Xaml 내용 구성
        /// </summary>
        //private void Init()
        //{
        //    //차트 카테고리 지울때 사용
        //    //Setter setter = new Setter();
        //    //setter.Property = WidthProperty;
        //    //setter.Value = 0;

        //    //Legend legend = new Legend();

        //    //Style style = new Style();
        //    //style.TargetType = legend.Style;
        //    Tmp_VM_DotLine vm = new Tmp_VM_DotLine();
        //    DataContext = vm;

            
        //    ChartProperty.Foreground = Brushes.Black;
        //    ChartProperty.Name = "linechart";
        //    ChartProperty.HorizontalAlignment = HorizontalAlignment.Stretch;
        //    ChartProperty.VerticalAlignment = VerticalAlignment.Stretch;

        //    Binding binding = new Binding("DataProperty");
        //    binding.Source = vm;


        //    LineSeries lineSeries = new LineSeries
        //    {
        //        Foreground = Brushes.Black,
        //        DependentValuePath = "",
        //        IndependentValuePath = "",
        //        IsSelectionEnabled = true,
        //        HorizontalAlignment = HorizontalAlignment.Stretch,
        //        VerticalAlignment = VerticalAlignment.Stretch,
        //        //  ItemsSource = 
        //    };

        //    ChartProperty.LegendStyle = Style;

        //    this.Content = ChartProperty;
        //}


        //private void ParsingData()
        //{
        //    Tmp_VM_DotLine d = new Tmp_VM_DotLine();

        //    string path = @"C:\Users\Toz\Desktop\조선해양SDK\MARINEWIZ1.0_20181128\MARINEWIZ1.0\Resources\File\SDK sample.xml";

        //    FileStream fs = File.OpenRead(path);
        //    //ParsingDataList = d.DoReaderXmlDataAsync(fs);
        //}



        private void showColumnChart()
        {
            List<KeyValuePair<string, int>> valueList = new List<KeyValuePair<string, int>>();

            valueList.Add(new KeyValuePair<string, int>("value 1", 120));
            valueList.Add(new KeyValuePair<string, int>("value 2", 30));
            valueList.Add(new KeyValuePair<string, int>("value 3", 70));
            valueList.Add(new KeyValuePair<string, int>("value 4", 100));
            valueList.Add(new KeyValuePair<string, int>("value 5", 50));
            valueList.Add(new KeyValuePair<string, int>("value 6", 80));
            valueList.Add(new KeyValuePair<string, int>("value 7", 140));

            //Setting data for line chart
            //ChartProperty.DataContext = valueList;
        }

    }
}

