﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MARINEWIZ1._0.View.UserControls
{
    /// <summary>
    /// ChartImage.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class ChartImage : UserControl
    {
        /// Check Drag
        protected bool isDragging;
        private Point clickPosition;
        private Transform aaaa;

#pragma warning disable CS1591 // 공개된 형식 또는 멤버에 대한 XML 주석이 없습니다.
        public double OffsetX { get; set; }
#pragma warning restore CS1591 // 공개된 형식 또는 멤버에 대한 XML 주석이 없습니다.
        public double OffsetY { get; set; }

        /// <summary>
        /// Chart Component를 Image화 시키는 Class
        /// </summary>
        /// <param name="uri">Image Resource Uri</param>
        public ChartImage(Uri uri)
        {
            InitializeComponent();
            //AddEventHandler();
            SetChildComponent(uri);
        }

        private void SetChildComponent(Uri uri)
        {
            Image img = new Image()
            {
                Source = new BitmapImage(uri),
                Stretch = Stretch.Fill,
            };
            this.Content = img;
        }
        
        private void AddEventHandler()
        {
            this.MouseLeftButtonDown += new MouseButtonEventHandler(Control_MouseLeftButtonDown);
            this.MouseLeftButtonUp += new MouseButtonEventHandler(Control_MouseLeftButtonUp);
            this.MouseMove += new MouseEventHandler(Control_MouseMove);
        }

        private void Control_MouseMove(object sender, MouseEventArgs e)
        {
            var draggableControl = sender as UserControl;

            if (isDragging && draggableControl != null)
            {
                Point currentPosition = e.GetPosition(this.Parent as UIElement);

                var transform = draggableControl.RenderTransform as TranslateTransform;
                
                if (transform == null)
                {
                    transform = new TranslateTransform();
                    draggableControl.RenderTransform = transform;
                }

                if (Math.Abs((int)currentPosition.X) % 25 == 0)
                {
                    transform.X = currentPosition.X - clickPosition.X;
                    transform.X -= (int)(transform.X % 25);
                }
                if (Math.Abs((int)currentPosition.Y) % 25 == 0)
                {
                    transform.Y = currentPosition.Y - clickPosition.Y;
                    transform.Y -= (int)(transform.Y % 25);
                }

                OffsetX = transform.Value.OffsetX;
                OffsetY = transform.Value.OffsetY;
            }
        }



        private void Control_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            isDragging = false;
            var draggable = sender as UserControl;
            draggable.ReleaseMouseCapture();
        }

        private void Control_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            isDragging = true;
            var draggableControl = sender as UserControl;
            clickPosition = e.GetPosition(this);
            draggableControl.CaptureMouse();
        }
    }
}
