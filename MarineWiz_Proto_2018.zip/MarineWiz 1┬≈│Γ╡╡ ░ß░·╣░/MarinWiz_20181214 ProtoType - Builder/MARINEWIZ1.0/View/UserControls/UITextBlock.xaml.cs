﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace MARINEWIZ1._0.View.UserControls
{
    /// <summary>
    /// UITextBlock.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class UITextBlock : UserControl
    {
        public UITextBlock()
        {
            InitializeComponent();
            //AddEventHandler();
        }

        protected bool isDragging;
        private Point clickPosition;

        private void AddEventHandler()
        {
            this.MouseDoubleClick += new MouseButtonEventHandler(Control_MouseLeftButtonDown);
            this.MouseLeftButtonUp += new MouseButtonEventHandler(Control_MouseLeftButtonUp);
            this.MouseMove += new MouseEventHandler(Control_MouseMove);
        }

        private void Control_MouseMove(object sender, MouseEventArgs e)
        {
            var draggableControl = sender as UserControl;

            if (isDragging && draggableControl != null)
            {
                Point currentPosition = e.GetPosition(this.Parent as UIElement);
                var transform = draggableControl.RenderTransform as TranslateTransform;

                if (transform == null)
                {
                    transform = new TranslateTransform();
                    draggableControl.RenderTransform = transform;
                }

                if (Math.Abs((int)currentPosition.X) % 25 == 0)
                {
                    transform.X = currentPosition.X - clickPosition.X;
                    transform.X -= (int)(transform.X % 25);
                }
                if (Math.Abs((int)currentPosition.Y) % 25 == 0)
                {
                    transform.Y = currentPosition.Y - clickPosition.Y;
                    transform.Y -= (int)(transform.Y % 25);
                }
            }
        }

        private void Control_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            isDragging = false;
            var draggable = sender as UserControl;
            draggable.ReleaseMouseCapture();
        }

        private void Control_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            isDragging = true;
            var draggableControl = sender as UserControl;
            clickPosition = e.GetPosition(this);
            draggableControl.CaptureMouse();
        }
    }
}
