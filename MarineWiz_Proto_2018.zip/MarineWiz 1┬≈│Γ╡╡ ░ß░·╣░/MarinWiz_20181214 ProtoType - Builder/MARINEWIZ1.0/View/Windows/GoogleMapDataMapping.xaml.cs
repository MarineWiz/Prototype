﻿using System.Windows;

namespace MARINEWIZ1._0.View.Windows
{
    /// <summary>
    /// Window1.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class GoogleMapDataMapping : Window
    {
        public GoogleMapDataMapping()
        {
            InitializeComponent();
            //this.Title = "DataBinding";
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
