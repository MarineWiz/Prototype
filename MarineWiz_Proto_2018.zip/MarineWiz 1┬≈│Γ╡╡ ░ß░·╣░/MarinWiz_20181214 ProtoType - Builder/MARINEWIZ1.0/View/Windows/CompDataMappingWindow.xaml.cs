﻿using MahApps.Metro.Controls;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MARINEWIZ1._0.View.Windows
{
    /// <summary>
    /// DataFileSelectWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class CompDataMappingWindow : MetroWindow
    {
        TreeViewItem change_item = new TreeViewItem();
        String sender_type;
        Object chagne_obj = new Object();
        String selected_name1;
        String selected_name2;

        public CompDataMappingWindow(Object sender)
        {
            InitializeComponent();
            // SetList();

            sender_type = GetType().GetProperty("Content").GetValue(sender).ToString();
            ///MessageBox.Show(sender_type);
        }

        //private void SetList()
        //{
        //    StartWindow mainwindow = Application.Current.MainWindow as StartWindow;

        //    TreeViewItem rootItem = mainwindow.datatreeviewrootitme;

        //    if (rootItem.Items.Count > 2)
        //    {
        //        for (int i = 2; i < rootItem.Items.Count; ++i)
        //        {
        //            object obj = new object();
        //            obj = rootItem.Items.GetItemAt(i);
        //            leftlistview.Items.Add(obj);
        //        }
        //    }
        //}

        private void TreeView_Loaded(object sender, RoutedEventArgs e)
        {
            if(sender_type.Equals("Label Data Mapping"))
            {
                TreeViewItem item = new TreeViewItem();
                item.Header = "라벨";
                item.ItemsSource = new string[] { "Text" };

                // ... Get TreeView reference and add both items.
                var tree = sender as TreeView;
                tree.Items.Add(item);
            }
            else if (sender_type.Equals("RadioButton Data Mapping"))
            {
                TreeViewItem item = new TreeViewItem();
                item.Header = "라디오버튼";
                item.ItemsSource = new string[] { "Value" };

                // ... Get TreeView reference and add both items.
                var tree = sender as TreeView;
                tree.Items.Add(item);
            }
            else if (sender_type.Equals("GoogleMap Data Mapping"))
            {
                TreeViewItem item = new TreeViewItem();
                item.Header = "GPS 좌표";
                item.ItemsSource = new string[] { "위도", "경도" };

                TreeViewItem item2 = new TreeViewItem();
                item2.Header = "Data Type";
                item2.ItemsSource = new string[] { "온도", "작업자", "크레인", "화물" };

                var tree = sender as TreeView;
                tree.Items.Add(item);
                tree.Items.Add(item2);
            }
            else
            {
                // ... Create a TreeViewItem.
                TreeViewItem item = new TreeViewItem();
                item.Header = "라벨";
                item.ItemsSource = new string[] { "Text", "val1", "val2" };

                // ... Create a second TreeViewItem.
                TreeViewItem item2 = new TreeViewItem();
                item2.Header = "라벨2";
                item2.ItemsSource = new string[] { "Text", "val1", "val2" };

                // ... Get TreeView reference and add both items.
                var tree = sender as TreeView;
                tree.Items.Add(item);
                tree.Items.Add(item2);
            }
            
        }

        private void TreeView_SelectedItemChanged(object sender,
            RoutedPropertyChangedEventArgs<object> e)
        {
            var tree = sender as TreeView;

            
            // ... Determine type of SelectedItem.
            if (tree.SelectedItem is TreeViewItem)
            {
                // ... Handle a TreeViewItem.
                var item = tree.SelectedItem as TreeViewItem;
                //this.Title = "Selected header: " + item.Header.ToString();
                //item.Header = "change";
                change_item = item;
                //selected_name1 = item.Header.ToString();
            }
            else if (tree.SelectedItem is string)
            {
                // ... Handle a string.
                //this.Title = "Selected: " + tree.SelectedItem.ToString();
                
                selected_name1 = tree.SelectedItem.ToString();
            }
        }

        private void TreeView_Loaded2(object sender, RoutedEventArgs e)
        {
            // ... Create a TreeViewItem.
            TreeViewItem item = new TreeViewItem();
            item.Header = "데이터베이스";
            item.ItemsSource = new string[] { "DB Connect1", "DB Connect2", "DB Connect3" };

            // ... Create a second TreeViewItem.
            TreeViewItem item2 = new TreeViewItem();
            item2.Header = "파일데이터";
            item2.ItemsSource = new string[] { "File Data1", "File Data2", "File Data3" };

            TreeViewItem item3 = new TreeViewItem();
            item3.Header = "GIS Map Data";
            item3.ItemsSource = new string[] { "위도 Data", "경도 Data" };

            TreeViewItem item4 = new TreeViewItem();
            item4.Header = "IoT Device Data";
            item4.ItemsSource = new string[] { "온도 Data", "작업자 Data", "크레인 Data", "화물 Data" };

            // ... Get TreeView reference and add both items.
            var tree = sender as TreeView;
            tree.Items.Add(item);
            tree.Items.Add(item2);
            tree.Items.Add(item3);
            tree.Items.Add(item4);
        }

        private void TreeView_SelectedItemChanged2(object sender,
            RoutedPropertyChangedEventArgs<object> e)
        {
            var tree = sender as TreeView;

            // ... Determine type of SelectedItem.
            if (tree.SelectedItem is TreeViewItem)
            {
                // ... Handle a TreeViewItem.
                var item = tree.SelectedItem as TreeViewItem;
                //change_item = item;
            }
            else if (tree.SelectedItem is string)
            {
                // ... Handle a string.
                selected_name2 = tree.SelectedItem.ToString();                
            }
        }

        // 확인 버튼 이벤트
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        // Connect 버튼 이벤트
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            IEnumerator enu = change_item.ItemsSource.GetEnumerator();
            int n_count = 0;

            while(enu.MoveNext())
            {
                if (enu.Current.Equals(selected_name1))
                    break;
                n_count = n_count + 1;
            }

            // 컴포넌트 라벨 Case
            if (sender_type.Equals("Label Data Mapping"))
            {
                change_item.ItemsSource = new string[] { selected_name1 + " - " + selected_name2 };
            }
            else if (sender_type.Equals("RadioButton Data Mapping"))
            {
                change_item.ItemsSource = new string[] { selected_name1 + " - " + selected_name2 };
            }
            else if (sender_type.Equals("GoogleMap Data Mapping"))
            {
                String ms = change_item.Items.GetItemAt(0).ToString();
                if (n_count == 0)
                {
                    if(change_item.Header.Equals("GPS 좌표"))
                        change_item.ItemsSource = new string[] { selected_name1 + " - " + selected_name2, change_item.Items.GetItemAt(1).ToString() };
                    else if(change_item.Header.Equals("Data Type"))
                        change_item.ItemsSource = new string[] { selected_name1 + " - " + selected_name2, change_item.Items.GetItemAt(1).ToString(), change_item.Items.GetItemAt(2).ToString(), change_item.Items.GetItemAt(3).ToString() };
                }
                else if (n_count == 1)
                {
                    if (change_item.Header.Equals("GPS 좌표"))                        
                        change_item.ItemsSource = new string[] { change_item.Items.GetItemAt(0).ToString(), selected_name1 + " - " + selected_name2 };
                    else if (change_item.Header.Equals("Data Type"))
                        change_item.ItemsSource = new string[] { change_item.Items.GetItemAt(0).ToString(), selected_name1 + " - " + selected_name2, change_item.Items.GetItemAt(2).ToString(), change_item.Items.GetItemAt(3).ToString() };
                }
                else if (n_count == 2)
                {
                    if (change_item.Header.Equals("Data Type"))
                        change_item.ItemsSource = new string[] { change_item.Items.GetItemAt(0).ToString(), change_item.Items.GetItemAt(1).ToString(), selected_name1 + " - " + selected_name2, change_item.Items.GetItemAt(3).ToString() };
                }
                else if (n_count == 3)
                {
                    if (change_item.Header.Equals("Data Type"))
                        change_item.ItemsSource = new string[] { change_item.Items.GetItemAt(0).ToString(), change_item.Items.GetItemAt(1).ToString(), change_item.Items.GetItemAt(2).ToString(), selected_name1 + " - " + selected_name2 };
                }
            }
            else
            {
                if (n_count == 0)
                {
                    change_item.ItemsSource = new string[] { selected_name1 + " - " + selected_name2, "val1", "val2" };
                }
                else if (n_count == 1)
                {
                    change_item.ItemsSource = new string[] { "Text", selected_name1 + " - " + selected_name2, "val2" };
                }
                else
                {
                    change_item.ItemsSource = new string[] { "Text", "val1", selected_name1 + " - " + selected_name2 };
                }
            }
        }

        // DisConnect 버튼 이벤트
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {

        }
    }
}
