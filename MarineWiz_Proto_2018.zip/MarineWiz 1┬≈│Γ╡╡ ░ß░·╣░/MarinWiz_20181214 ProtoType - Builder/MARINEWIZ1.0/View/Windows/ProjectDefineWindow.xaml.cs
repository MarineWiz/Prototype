﻿using MahApps.Metro.Controls;
using MARINEWIZ1._0.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MARINEWIZ1._0.View.Windows
{
    /// <summary>
    /// ProjectDefineWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class ProjectDefineWindow : MetroWindow
    {
        public ProjectDefineWindow()
        {
            if (StaticHelper.StartSwt == true)
                return;
            InitializeComponent();
            DefaultSetting();
        }

        private void DefaultSetting()
        {
            tbx_project_name.Text = StaticHelper.Projectname;
            tbx_path.Text = StaticHelper.CodePath;
        }

        public void DefineWindowSize()
        {
            Canvas canvas = UIHelper.FindChild<Canvas>(Application.Current.MainWindow, "maincanvas");
            
            if (tbx_window_width.Text == string.Empty || tbx_window_height.Text == string.Empty)
            {
                MessageBox.Show("기본 값으로 설정됩니다.", "Warning");
                canvas.Width = 1920;
                canvas.Height = 1080;
            }
            else
            {
                canvas.Width = int.Parse(tbx_window_width.Text);
                canvas.Height = int.Parse(tbx_window_height.Text);
            }
            this.Close();
            return;
        }

        public void NotDefineWindowSize()
        {
            Canvas canvas = UIHelper.FindChild<Canvas>(Application.Current.MainWindow, "maincanvas");

            MessageBox.Show("기본 값으로 설정됩니다.", "Warning");
            canvas.Width = 1920;
            canvas.Height = 1080;

            this.Close();
            return;
        }

        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            // Regular Expression
            e.Handled = regex.IsMatch(e.Text);
        }


        /// <summary>
        /// Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void btn_ok_Click(object sender, RoutedEventArgs e)
        {
            DefineWindowSize();
        }
    }
}
