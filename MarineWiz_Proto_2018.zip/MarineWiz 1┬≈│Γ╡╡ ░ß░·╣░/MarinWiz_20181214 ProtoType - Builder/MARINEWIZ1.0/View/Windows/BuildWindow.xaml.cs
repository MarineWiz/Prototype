﻿using MahApps.Metro.Controls;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MARINEWIZ1._0.View.Windows
{
    /// <summary>
    /// BuildWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class BuildWindow : MetroWindow
    {
        /// <summary>
        /// 빌드전용 Window 화면
        /// </summary>
        public BuildWindow()
        {
            InitializeComponent();
//            OpenToBuildProject();
        }
        /// <summary>
        /// 빌드 프로젝트 불러오는것.
        /// </summary>
        public void OpenToBuildProject()
        {
            FileStream fs = null;
            try
            {
                MessageBox.Show(Helper.StaticHelper.builderPath);
                fs = File.Open(Helper.StaticHelper.builderPath, FileMode.Open, FileAccess.Read);
                StackPanel stkpanel = XamlReader.Load(fs) as StackPanel;

                buildercanvas.Children.Add(stkpanel);

            }
            catch(Exception err)
            {
                MessageBox.Show(err.Message);
                fs.Close();
                return;
            }
            finally
            {
                fs.Close();
            }
        }

        private void btn_dobuild_Click(object sender, RoutedEventArgs e)
        {
            // TODO : .exe파일 만들어야함...
        }
    }
}
